# Key status (v0.3.3)

This list comes from reading the code, not from running the app on a phone. If a key does not behave as described, note the app and the key and report it.

## Works in every app (typed through InputConnection)
Letters, digits, punctuation, symbols and popups, Space, Enter (action or new line), Backspace (hold repeats, swipe left deletes words), Shift / Caps Lock, auto-capitalization, double-space period, emoji, the Symbols panel, clipboard paste, Select all / Copy / Cut / Paste (editor actions), suggestions, autocorrect and Hinglish conversion.

## Works inside ProKey itself (no app support needed)
Fn (shows or hides F1-F12), Ins (overwrite mode: typed characters replace the next one; the key lights up), Caps, ABC / PC, ?123 pages, language switch, sticky Shift / Ctrl / Alt / Win highlighting, key preview, themes, toolbar and quick-action bar.

## Works only where the app handles key events
Arrows, Home, End, Del, Tab, PgUp, PgDn, Esc, F1-F12, and Ctrl / Alt / Shift combinations (for example Shift+arrows selects text and Ctrl+Backspace deletes a word in normal text boxes). Undo and Redo use the editor action first and fall back to Ctrl+Z / Ctrl+Y. Most ordinary Android apps ignore F-keys and Esc; terminals, remote-desktop and some web apps use them.

## Cannot be done by a keyboard on Android
- Print Screen takes no screenshot (the key shows a hint; use the phone shortcut).
- Win only adds the Meta flag to the next key event; it has no system effect.
- A keyboard cannot press real system keys such as Home, Back or Recent apps.

## Depends on the phone
- Mic needs a speech-recognition app (normally Google). Without it you get a short message.
- Key sound needs "Touch sounds" turned on in system settings. Vibration needs vibration hardware.

## Not built yet
Numeric keypad in portrait; emoji suggestions while typing; several key-sound styles; extra key shapes beyond the corner-radius slider; downloadable language packs.

## Changed in v0.4.1
- Toolbar: Clipboard, Undo, Redo, Symbols, Tab, Mic (Emoji is only in the bottom row). Emoji search shows what you type. Suggestions are better ranked.

## Changed in v0.4.0
- One-handed mode (left/right), landscape split keyboard, experimental floating keyboard. See README.

## Changed in v0.3.3
- Symbols panel (toolbar button with the Omega sign): currency, math, fractions, super/subscripts, Greek, arrows, special characters.
- Tab key in the mobile toolbar. Long-press the clipboard button for Select all / Copy / Cut / Paste in mobile mode.
- Ins now really works (overwrite mode).
- Key font size slider in Settings.
