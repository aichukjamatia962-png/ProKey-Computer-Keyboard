# Manual test checklist (core build)

Run on at least one OPPO/ColorOS phone, one other brand, and one emulator. Tick each when verified.

Activation
- [ ] Enable ProKey in Android keyboard list; select it from the picker
- [ ] Main screen status text updates (not enabled / not selected / ready)
- [ ] Long-press the Emoji key (where the globe was) to switch keyboards; settings key opens ProKey settings

Mobile mode (try Notes, a browser address bar, a chat app, a multi-line field)
- [ ] Every letter a-z and A-Z; every digit; every symbol on both `?123` pages
- [ ] Shift one-shot, double-tap caps lock, auto-capitalization at sentence start
- [ ] Backspace (tap and hold), Enter (newline vs Go/Search/Send), Space, double-space period
- [ ] Spacebar swipe moves the cursor; fast two-thumb typing drops no keys
- [ ] Number/phone fields open on the symbols page; password fields type correctly

PC mode
- [ ] Every key in compact (portrait) and full (landscape) layouts, with and without function row and numpad
- [ ] Ctrl+A/C/X/V, Ctrl+Z, Shift+arrows selection, Alt/Win flags in a terminal-type app
- [ ] F1-F12, Esc, Tab, Home, End, PgUp, PgDn, Ins, Del, arrows (note which apps react)
- [ ] Caps Lock, Fn toggle, ABC/PC switch

Settings and look
- [ ] All 15 themes readable (text vs key contrast), in portrait and landscape
- [ ] Height, spacing, radius sliders update the open keyboard live
- [ ] Key sound (with system touch sounds on), volume, vibration on/off and intensity
- [ ] Rotation while the keyboard is open

Release
- [ ] Install over an older build (upgrade), signature verifies, no INTERNET permission in the APK manifest

## v0.2.0 additions

Symbols and popups
- [ ] Symbols page 2/2 shows ₹ £ € ¥ ¢ ° % in the bottom row; math, punctuation and legal rows insert correctly
- [ ] Long-press `$ - . 0 = * /` `'` `"` and accented letters: popup appears, slide to choose, release inserts; release outside cancels; popups follow Shift
- [ ] Popup on top-row keys (number row off, toolbar off) is visible and usable

Toolbar, panels, voice
- [ ] Emoji panel: tabs, insert, recents, ABC back, backspace hold-repeat; flags and newer emojis render on your phone
- [ ] Clipboard: off by default; turn on, copy text in another app, it appears; tap to paste, pin, delete, Clear (keeps pinned); nothing saved from a password field
- [ ] Undo/Redo in a notes app and in a browser text box (editor action or Ctrl+Z/Y fallback)
- [ ] Mic: speech screen opens, text is typed after it closes; behaves on a phone without Google speech services

Typing feel
- [ ] Backspace swipe left deletes words (and a selection); normal backspace tap/hold still works
- [ ] Key preview shows with gold border; toggle it off in settings
- [ ] Spacebar swipe, auto-cap, double-space period unchanged

PC mode
- [ ] Corner hints on number/punctuation keys; they swap when Shift is active
- [ ] Tap Ctrl then C copies (gold highlight, resets after); double-tap Shift/Ctrl locks (bar shown), tap again unlocks
- [ ] Right Ctrl before the arrows works; quick-action bar buttons (turn it on in settings) work or fall back as documented

## v0.3.0 additions

Suggestions and autocorrect (use a normal text field, e.g. Notes)
- [ ] No separate suggestion bar and no extra height; suggestions appear in the toolbar row after the word list loads; never in password, number, URL and e-mail fields
- [ ] Typing "teh " becomes "the "; backspace right after restores "teh" and it is not corrected again
- [ ] "dont", "im", "i" are fixed to "don't", "I'm", "I"; names and ALL-CAPS words are left alone
- [ ] Tapping a suggestion replaces the current word and adds a space; the next-word bar appears after a space
- [ ] Learn: type a made-up word twice, it stops being corrected and shows in Personal dictionary; delete it there; "Clear everything" works
- [ ] Nothing is learned in a password field or with Learn new words off
- [ ] Low-end phone: no typing lag while the word list loads or while suggestions refresh

Hindi
- [ ] Enable Hindi languages in settings; long-press the spacebar switches language; spacebar shows the language name
- [ ] Hinglish: kya, hindi, namaste, dhanyavad, mera, bharat give sensible options; space converts; backspace reverts
- [ ] InScript: check every key against a reference InScript chart; Shift symbols match the corner hints; matras and conjuncts (क्ष, ज्ञ, त्र) render
- [ ] Autocapitalization does not fire in InScript mode

Emoji search and theme editor
- [ ] Emoji search: type "love", "fire", "pizza"; results insert; close returns to the emoji panel
- [ ] Theme editor: color pickers, gradient, border, opacity, background image (large photo, portrait and landscape), Apply, Save as, Delete, Reset; keyboard updates immediately after Apply
- [ ] Saved/custom theme survives restarting the phone

## v0.3.1 PC layout

- [ ] Quick-action bar shows exactly Undo, Redo, Cut, Copy, Paste, Sel All (no Find)
- [ ] Nav row shows Esc, Ins, Del, Home, End, PgUp, PgDn, PrtSc (no Menu), in portrait; landscape bottom row has no Menu
- [ ] Only one Ctrl and one Shift anywhere; Shift on the left of the Z row, Ctrl on the left of the bottom row
- [ ] Every row ends flush at the right edge; no gaps; keys line up in portrait and landscape, with and without the F row, quick bar and numpad
- [ ] Tap Ctrl then C copies; double-tap Shift or Ctrl locks (gold with a bar)

## v0.3.2 suggestions in the toolbar row

- [ ] Idle or empty field: the original toolbar (emoji, clipboard, undo, redo, mic) is shown
- [ ] Start typing a word: the toolbar buttons are replaced by three suggestion buttons; tapping one replaces the word
- [ ] Stop typing for about 2.5 seconds: the toolbar returns; clear the field: toolbar returns at once
- [ ] Turn off Top toolbar in settings: no suggestion strip (autocorrect still works), and no extra height
- [ ] Bottom row: Emoji key opens the emoji panel; long-press switches keyboards; spacebar long-press switches language (Hindi enabled)
- [ ] Two-thumb typing while the toolbar swaps does not drop keys or leave a button stuck

## v0.3.3

- [ ] Toolbar shows Emoji, Clipboard, Undo, Redo, Omega, Tab, Mic; Omega opens the Symbols panel (7 tabs); tapping a symbol inserts it; ABC returns
- [ ] Long-press the clipboard button: All / Copy / Cut / Paste popup works in Notes and a browser text box; a plain tap still opens clipboard history
- [ ] Tab moves focus in a form field
- [ ] PC mode: tap Ins (key lights up), type over existing text, it replaces characters; tap Ins again to go back to normal typing
- [ ] Settings > Key font size changes the key labels live
- [ ] Walk through docs/KEY_STATUS.md and mark any key whose behavior differs

## v0.4.0 one-handed, split, floating

One-handed
- [ ] Settings > One-handed mode > Right hand: keys sit on the right, free strip on the left shows the swap arrow and Full; every key still types correctly, including the toolbar and suggestions
- [ ] Swap arrow moves the keyboard to the other side; Full returns to full width; long-press the gear toggles one-handed mode
- [ ] Width slider (60-90%) updates live; popups and key preview stay on screen; no effect in landscape

Split (landscape)
- [ ] Letters, number row, symbols and Hindi rows show two halves with an even gap; both spacebar halves type a space; toolbar row is full width; keys line up row to row

Floating (experimental, try on a spare field first)
- [ ] Turn on: keyboard shrinks, handle appears on top, app is not pushed up, taps outside the keyboard reach the app
- [ ] Drag the handle: keyboard moves and stays within the screen; position is remembered after closing and reopening
- [ ] Dock returns to the normal keyboard; rotate the phone while floating; emoji, clipboard and symbol panels work inside the floating window
- [ ] If anything is stuck or invisible: ProKey app > Keyboard settings > turn Floating off

## v0.4.1

Emoji
- [ ] Toolbar has no Emoji button; the bottom-row Emoji key opens the panel
- [ ] First tab (clock) shows what you used recently, then popular emojis
- [ ] Search: tap the magnifier, the box shows "Type here..."; type "love", "fire", "dil", "chai": the text appears with a caret and matching emojis show; tap one to insert; try gibberish for the "No emoji found" note; X returns to the panel
- [ ] If typed letters do NOT appear in the search box, note the phone and app and report it

Suggestions (Notes app, English)
- [ ] "teh " -> "the ", "wrok " -> "work ", "adn " -> "and "; "hel" suggests help/hello/held; after "thank " you see "you"
- [ ] Words you type often move up in the suggestions; "Clear everything" resets that
- [ ] Hinglish: dil, pyar, mausam, safar, shaadi give Devanagari

## v0.4.2 clipboard

- [ ] Each entry shows copy, pin and delete icons; the hint line under "Clipboard" explains them
- [ ] Copy: tap the copy icon, then paste in another app (long-press > Paste): the entry arrives; the entry stays in the list
- [ ] Tapping the entry itself types it into the field; pin keeps it after Clear; delete removes it
- [ ] Icons render as proper emoji on your phone (page, pushpin, wastebasket)
