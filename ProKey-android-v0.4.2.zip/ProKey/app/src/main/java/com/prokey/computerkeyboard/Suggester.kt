package com.prokey.computerkeyboard

import kotlin.math.abs

/** Builds suggestions, next-word predictions and autocorrect choices. Pure logic, no Android UI. */
class Suggester(
    private val dict: WordDict,
    private val personal: PersonalDict,
    private val next: NextWords,
    private val hindi: HindiDict,
) {
    class Result(val items: List<String>, val auto: String?)

    private val contractions = mapOf(
        "i" to "I", "im" to "I'm", "ive" to "I've", "dont" to "don't", "cant" to "can't", "wont" to "won't",
        "didnt" to "didn't", "isnt" to "isn't", "wasnt" to "wasn't", "doesnt" to "doesn't",
        "couldnt" to "couldn't", "wouldnt" to "wouldn't", "shouldnt" to "shouldn't", "havent" to "haven't",
        "hasnt" to "hasn't", "arent" to "aren't", "werent" to "weren't", "youre" to "you're",
        "theyre" to "they're", "thats" to "that's", "whats" to "what's",
    )

    // QWERTY geometry, to tell a slip of the finger (neighbouring key) from a random wrong letter
    private val keyPos = HashMap<Char, Pair<Float, Float>>().also { m ->
        val rows = listOf("qwertyuiop" to 0f, "asdfghjkl" to 0.5f, "zxcvbnm" to 1.0f)
        for ((r, row) in rows.withIndex()) {
            for ((c, ch) in row.first.withIndex()) m[ch] = Pair(c + row.second, r.toFloat())
        }
    }

    private fun near(a: Char, b: Char): Boolean {
        val p = keyPos[a] ?: return false
        val q = keyPos[b] ?: return false
        return abs(p.first - q.first) <= 1.1f && abs(p.second - q.second) <= 1f
    }

    /** Edit distance, lowered for neighbouring-key slips and swapped letters (lower = more likely typo). */
    private fun typoCost(w: String, c: String, dist: Int): Float {
        var cost = dist.toFloat()
        if (w.length == c.length) {
            var subs = 0
            var nearSubs = 0
            for (i in w.indices) {
                if (w[i] != c[i]) {
                    subs++
                    if (near(w[i], c[i])) nearSubs++
                }
            }
            if (subs == dist) cost -= 0.25f * nearSubs
            else if (subs == 2 && dist == 1) cost -= 0.4f // two letters swapped
        }
        return cost
    }

    /** Match the capitalization the user typed. */
    private fun recase(prefix: String, s: String): String = when {
        prefix.length >= 2 && prefix.any { it.isLetter() } && prefix.all { !it.isLetter() || it.isUpperCase() } -> s.uppercase()
        prefix.isNotEmpty() && prefix[0].isUpperCase() -> s.replaceFirstChar { it.uppercase() }
        else -> s
    }

    private fun autoEligible(prefix: String, sentenceStart: Boolean): Boolean {
        if (prefix.length < 3 || prefix.any { !it.isLetter() || it.code > 127 }) return false
        if (prefix.drop(1).any { it.isUpperCase() }) return false
        return prefix[0].isLowerCase() || sentenceStart
    }

    private fun likelyAfter(prev: String?, personalOn: Boolean): List<String> {
        if (prev == null) return emptyList()
        val p = prev.lowercase()
        return next.get(p) + (if (personalOn) personal.next(p, 5) else emptyList())
    }

    fun nextWords(prev: String?, sentenceStart: Boolean, personalOn: Boolean): List<String> {
        val out = ArrayList<String>()
        likelyAfter(prev, personalOn).forEach { if (it !in out) out.add(it) }
        if (out.isEmpty()) out.addAll(if (sentenceStart || prev == null) listOf("I", "The", "It") else listOf("the", "to", "and"))
        val shown = out.take(3)
        return if (sentenceStart) shown.map { it.replaceFirstChar { c -> c.uppercase() } } else shown
    }

    fun suggestEn(prefix: String, prev: String?, sentenceStart: Boolean, autoOn: Boolean, personalOn: Boolean, nextOn: Boolean): Result {
        if (!dict.ready) return Result(emptyList(), null)
        if (prefix.isEmpty()) return if (nextOn) Result(nextWords(prev, sentenceStart, personalOn), null) else Result(emptyList(), null)
        if (prefix.any { it.isDigit() }) return Result(emptyList(), null)
        val lower = prefix.lowercase()
        val known = dict.isKnown(lower) || (personalOn && personal.known(lower))
        var auto: String? = null

        val contraction = contractions[lower]
        if (contraction != null && prefix.all { it.code < 128 }) {
            auto = if (contraction[0] == 'I') contraction else recase(prefix, contraction)
        } else if (!known && autoOn && autoEligible(prefix, sentenceStart)) {
            // Confident fix: a common word that is one slip away. Slips of the finger and swapped letters win.
            val best = dict.corrections(lower, if (lower.length >= 7) 2 else 1, true, 8)
                .withIndex()
                .map { Triple(it.value.first, typoCost(lower, it.value.first, it.value.second), it.index) }
                .minByOrNull { it.second + it.third * 0.03f }
            if (best != null && (best.second < 1f || lower.length >= 4)) {
                auto = recase(prefix, best.first)
            } else if (best == null && lower.length >= 6) {
                val any = dict.corrections(lower, 1, false, 2)
                if (any.size == 1) auto = recase(prefix, any[0].first)
            }
        }

        // completions: words you use often and words that fit the previous word come first
        val ctx = likelyAfter(prev, personalOn)
        val comps = ArrayList<String>()
        if (personalOn) personal.complete(lower, 2).forEach { comps.add(recase(prefix, it)) }
        dict.complete(lower, 8)
            .sortedWith(compareByDescending<String> { it in ctx }.thenByDescending { personal.useCount(it) })
            .forEach { comps.add(recase(prefix, it)) }

        val fixes = if (known || lower.length < 2) emptyList() else
            dict.corrections(lower, if (lower.length >= 4) 2 else 1, false, 10)
                .withIndex()
                .sortedBy { typoCost(lower, it.value.first, it.value.second) + it.index * 0.03f }
                .map { recase(prefix, it.value.first) }

        val literal = if (!known && prefix != auto) prefix else null
        val out = ArrayList<String>()
        fun add(s: String) { if (out.size < 3 && s !in out) out.add(s) }
        if (auto != null) {
            add(auto)
            literal?.let { add(it) }
            fixes.forEach { add(it) }
            comps.forEach { add(it) }
        } else if (known) {
            comps.forEach { if (it != prefix) add(it) }
        } else if (lower.length >= 3 && comps.isNotEmpty()) {
            // still typing a longer word: completions first
            comps.take(2).forEach { add(it) }
            literal?.let { add(it) }
            fixes.forEach { add(it) }
            comps.forEach { add(it) }
        } else {
            literal?.let { add(it) }
            fixes.forEach { add(it) }
            comps.forEach { add(it) }
        }
        return Result(out, auto)
    }

    fun suggestHi(prefix: String): Result {
        if (prefix.isEmpty() || !prefix.all { it.code < 128 }) return Result(emptyList(), null)
        val cands = hindi.candidates(prefix)
        if (cands.isEmpty()) return Result(listOf(prefix), null)
        return Result(cands + prefix, cands.first())
    }
}
