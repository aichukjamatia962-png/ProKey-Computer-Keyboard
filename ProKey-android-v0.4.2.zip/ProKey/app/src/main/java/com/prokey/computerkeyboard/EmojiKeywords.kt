package com.prokey.computerkeyboard

/** Search keywords for a subset of the bundled emojis (common ones). */
object EmojiKeywords {
    private val entries: List<Pair<String, List<String>>> = """
😀 grin smile happy
😃 smile happy joy
😄 smile laugh happy
😁 grin beam teeth
😆 laugh haha lol
😅 sweat nervous relief pasina
😂 laugh lol joy tears funny hasna hasi hansi mazak
🤣 rofl lol laughing funny hasna hasi
😊 blush smile happy shy muskan khush
😇 angel innocent halo masoom
🙂 smile slight
🙃 upside silly sarcasm
😉 wink flirt
😍 love heart eyes crush pyar dil
🥰 love adore hearts
😘 kiss love blow chumma pyar
😋 yum tasty delicious swadisht
😛 tongue playful
😜 wink tongue crazy mazaak
🤑 money rich
🤗 hug thanks
🤭 oops giggle secret
🤔 think hmm wonder soch
😐 neutral meh blank
🙄 eyeroll annoyed whatever
😬 grimace awkward
😮 wow surprised open
😲 shocked astonished
😳 embarrassed blush flushed
🥺 please pleading puppy cute please pyara
😢 sad cry tear rona udaas dukhi
😭 cry sob loud sad rona
😤 angry frustrated huff
😠 angry mad gussa
😡 angry rage red mad gussa
🤬 swear curse angry
😱 scream scared fear shock darr
😨 fear scared
😰 anxious nervous worried
😓 sweat tired worry
🤯 mind blown shocked
😴 sleep tired zzz neend sona
🤤 drool hungry
😷 mask sick
🤒 sick fever ill
🤕 hurt injured bandage
🤢 nausea sick green
🤮 vomit sick
😎 cool sunglasses mast
🤓 nerd geek smart
🥳 party celebrate birthday party jashn
👋 wave hello hi bye
👌 ok perfect fine
✌️ peace victory
🤞 luck fingers crossed hope
🤙 call me shaka
👈 left point
👉 right point
👆 up point
👇 down point
👍 thumbs up like yes good ok theek accha sahi
👎 thumbs down dislike no bad bura galat
✊ fist power
👊 punch fist bump
👏 clap applause congrats taali badhai
🙌 hooray celebrate praise waah
🤝 handshake deal agree haath milana
🙏 pray thanks please namaste dhanyavad shukriya namaste pranam
💪 strong muscle strength gym taakat
🧠 brain smart think
👀 eyes look watching
👅 tongue
👶 baby
👨 man
👩 woman
🙋 raise hand question
🤷 shrug dunno
🤦 facepalm
🐶 dog puppy pet kutta
🐱 cat kitten pet billi
🐭 mouse
🐰 rabbit bunny
🦊 fox
🐻 bear
🐼 panda
🐯 tiger sher
🦁 lion
🐮 cow gaay
🐷 pig
🐸 frog
🐵 monkey
🙈 monkey see no evil shy bandar
🐔 chicken
🐧 penguin
🐦 bird
🦅 eagle
🦉 owl night
🐴 horse
🦄 unicorn magic
🐝 bee honey
🦋 butterfly
🐢 turtle slow
🐍 snake
🐙 octopus
🐬 dolphin
🐳 whale
🐘 elephant haathi
🌵 cactus desert
🌲 tree pine
🌸 flower blossom cherry phool
🌹 rose flower love gulab
🌻 sunflower flower
🍎 apple fruit red seb
🍌 banana fruit kela
🍉 watermelon fruit summer tarbooz
🍇 grapes fruit angoor
🍓 strawberry fruit
🍒 cherry fruit
🥭 mango fruit aam
🍍 pineapple fruit
🍅 tomato
🍆 eggplant brinjal
🥕 carrot
🌽 corn
🍞 bread
🧀 cheese
🍗 chicken leg food
🍔 burger hamburger food
🍟 fries food
🍕 pizza food
🌭 hotdog food
🌮 taco food
🍜 noodles ramen soup
🍛 curry rice food khana
🍣 sushi
🍚 rice food chawal khana
🍦 icecream dessert
🍰 cake dessert
🎂 birthday cake celebrate janamdin
🍩 donut dessert
🍪 cookie biscuit
🍫 chocolate
🍬 candy sweet
☕ coffee tea hot drink chai
🍵 tea green drink chai
🍺 beer drink
🍷 wine drink
🥤 drink soda cup
🚗 car drive vehicle gaadi
🚕 taxi cab
🚌 bus
🚓 police car
🚑 ambulance
🚒 fire truck
🚚 truck delivery
🛵 scooter
🚲 bicycle bike
🚂 train rail
✈️ plane flight travel airport jahaz
🚀 rocket launch space
🚢 ship boat
⚓ anchor
🏠 home house ghar
🏢 office building
🏥 hospital
🏦 bank
🕌 mosque
⛪ church
🌅 sunrise morning
🌃 night city
🌈 rainbow
⚽ football soccer ball
🏀 basketball
🏈 american football
⚾ baseball
🎾 tennis
🏏 cricket cricket
⛳ golf
🏆 trophy winner champion jeet
🥇 gold medal first winner
🥈 silver medal second
🥉 bronze medal third
🎯 target dart goal
🎮 game controller gaming
🎲 dice game
💡 idea bulb light vichar
📱 phone mobile cell mobile
💻 laptop computer
⌨️ keyboard typing
📷 camera photo
🎥 video movie camera
📞 phone call
📺 tv television
⏰ alarm clock time ghadi samay
⌚ watch time
🔋 battery charge
🔌 plug power
💰 money bag cash paisa
💵 dollar money cash
💳 card credit payment
💎 diamond gem
🔧 wrench tool fix
🔨 hammer tool
⚙️ gear settings
🔑 key lock
🔒 lock secure private
🔓 unlock
📌 pin location
📎 paperclip attach
✂️ scissors cut
📝 note memo write
📚 books study read kitab padhai
📖 book read
✏️ pencil write
📅 calendar date
📊 chart graph stats
📈 chart up growth
📉 chart down decline
🛒 cart shopping
🎁 gift present tohfa
🎈 balloon party gubbare
🎉 party celebrate congrats tada badhai party jashn
🎊 confetti celebrate
🔔 bell notification ghanti
🔍 search find magnifier
📦 package box delivery
❤️ love heart red dil pyar mohabbat
🧡 orange heart
💛 yellow heart
💚 green heart
💙 blue heart
💜 purple heart
🖤 black heart
🤍 white heart
💔 broken heart sad dil toot
💕 love hearts two
💖 sparkling heart love
💘 cupid arrow love
💋 kiss lips
💯 hundred perfect score
✨ sparkles shine magic new
⭐ star favorite tara
🌟 star glow shine
💫 dizzy star
🔥 fire hot lit aag
💥 boom explosion
✔️ check tick done
✅ check done yes
❌ cross no wrong
❓ question
❗ exclamation important
⚡ lightning bolt fast power
☀️ sun sunny weather dhoop suraj
🌙 moon night chand
🇮🇳 india flag bharat hindustan
🇺🇸 usa america flag
🇬🇧 uk britain flag
🇨🇦 canada flag
🇦🇺 australia flag
🇩🇪 germany flag
🇫🇷 france flag
🇯🇵 japan flag
🇨🇳 china flag
🇧🇷 brazil flag
🇵🇰 pakistan flag
🇧🇩 bangladesh flag
🏁 finish race flag
🚩 red flag warning
""".trim().lines().mapNotNull { line ->
        val parts = line.trim().split(" ").filter { it.isNotEmpty() }
        if (parts.size < 2) null else parts[0] to parts.drop(1)
    }

    /** Emojis whose keywords start with (or contain) every word of [query]. Best matches first. */
    fun search(query: String, limit: Int = 40): List<String> {
        val words = query.lowercase().trim().split(" ").filter { it.isNotEmpty() }
        if (words.isEmpty()) return emptyList()
        val scored = ArrayList<Pair<Int, String>>()
        for ((emoji, kws) in entries) {
            var score = 0
            var ok = true
            for (q in words) {
                score += when {
                    kws.any { it == q } -> 3
                    kws.any { it.startsWith(q) } -> 2
                    kws.any { it.contains(q) } -> 1
                    else -> { ok = false; 0 }
                }
            }
            if (ok) scored.add(score to emoji)
        }
        return scored.sortedByDescending { it.first }.take(limit).map { EmojiData.fix(it.second) }
    }
}
