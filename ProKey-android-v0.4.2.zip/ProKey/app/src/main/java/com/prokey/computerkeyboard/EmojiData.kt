package com.prokey.computerkeyboard

/** A curated emoji set (older Unicode versions, so they render on most phones). */
object EmojiData {
    // Adds the emoji variation selector to bare symbol characters (heart, plane, scissors...).
    fun fix(e: String) = if (e.length == 1 && e[0].code in 0x2190..0x2BFF) e + "\uFE0F" else e

    private fun list(s: String) = s.trim().split(" ").filter { it.isNotEmpty() }.map { fix(it) }

    /** Shown in the first (recent) tab after anything you used recently, and as the default search results. */
    val popular: List<String> = list("😂 ❤ 👍 🙏 😍 😊 🔥 😭 🥰 😘 😁 🎉 👏 💪 😎 🤔 😢 🙌 ✨ 💯 😅 🤣 😉 😋 😴 🙂 🤗 😜 😇 🥳 🤝 👌 ✌ 🤞 🌹 💔 😱 🙈 😡 🎂")

    val categories: List<Pair<String, List<String>>> = listOf(
        "😀" to list("😀 😃 😄 😁 😆 😅 😂 🤣 😊 😇 🙂 🙃 😉 😌 😍 🥰 😘 😗 😙 😚 😋 😛 😜 🤪 😝 🤑 🤗 🤭 🤫 🤔 🤐 🤨 😐 😑 😶 😏 😒 🙄 😬 😮 😯 😲 😳 🥺 😢 😭 😤 😠 😡 🤬 😱 😨 😰 😥 😓 🤯 😴 🤤 😷 🤒 🤕 🤢 🤮 🥵 🥶 😎 🤓 🧐 🤠 🥳"),
        "👋" to list("👋 🤚 ✋ 👌 ✌ 🤞 🤟 🤘 🤙 👈 👉 👆 👇 ☝ 👍 👎 ✊ 👊 🤛 🤜 👏 🙌 👐 🤲 🤝 🙏 💪 🧠 👀 👅 👄 👶 👦 👧 👨 👩 👴 👵 🙋 🤷 🤦 💁 🙆 🙅 🙇"),
        "🐻" to list("🐶 🐱 🐭 🐹 🐰 🦊 🐻 🐼 🐨 🐯 🦁 🐮 🐷 🐸 🐵 🙈 🙉 🙊 🐔 🐧 🐦 🐤 🦆 🦅 🦉 🦇 🐺 🐗 🐴 🦄 🐝 🐛 🦋 🐌 🐞 🐜 🐢 🐍 🦎 🐙 🦑 🦀 🐠 🐟 🐬 🐳 🐋 🦈 🐊 🐘 🦒 🐪 🌵 🌲 🌳 🌴 🌸 🌹 🌻 🌼"),
        "🍔" to list("🍎 🍐 🍊 🍋 🍌 🍉 🍇 🍓 🍒 🍑 🥭 🍍 🥥 🥝 🍅 🥑 🍆 🥔 🥕 🌽 🥒 🥦 🍄 🥜 🍞 🥐 🧀 🍖 🍗 🥩 🍔 🍟 🍕 🌭 🥪 🌮 🌯 🍝 🍜 🍲 🍛 🍣 🍱 🍤 🍙 🍚 🍦 🍰 🎂 🍩 🍪 🍫 🍬 🍭 ☕ 🍵 🍺 🍷 🥤"),
        "🚗" to list("🚗 🚕 🚙 🚌 🚎 🚓 🚑 🚒 🚚 🚜 🛵 🚲 🛴 🚂 🚆 🚇 ✈ 🛫 🛬 🚀 🛸 🚁 ⛵ 🚤 🚢 ⚓ 🗽 🗼 🏰 🏯 🏠 🏢 🏥 🏦 🏨 ⛪ 🕌 🌅 🌄 🌇 🌃 🌉 🌈"),
        "⚽" to list("⚽ 🏀 🏈 ⚾ 🎾 🏐 🏉 🎱 🏓 🏸 🥅 🏒 🏏 ⛳ 🏹 🎣 🥊 🥋 🎽 🎿 🏂 🤸 🏆 🥇 🥈 🥉 🏅 🎯 🎮 🎲 🎳"),
        "💡" to list("💡 🔦 📱 💻 ⌨ 💾 📷 📹 🎥 📞 ☎ 📺 📻 ⏰ ⌚ 🔋 🔌 💰 💵 💳 💎 🔧 🔨 ⚙ 🔑 🔒 🔓 📌 📎 ✂ 📝 📚 📖 ✏ 📅 📊 📈 📉 🛒 🎁 🎈 🎉 🎊 🔔 🔍 📦"),
        "\u2764\uFE0F" to list("❤ 🧡 💛 💚 💙 💜 🖤 🤍 🤎 💔 ❣ 💕 💞 💓 💗 💖 💘 💝 💟 ♥ 💋 💯 ✨ ⭐ 🌟 💫 🔥 💥 ✔ ✅ ❌ ❓ ❗ ⚡ ☀ 🌙"),
        "🏁" to list("🇮🇳 🇺🇸 🇬🇧 🇨🇦 🇦🇺 🇩🇪 🇫🇷 🇮🇹 🇪🇸 🇯🇵 🇰🇷 🇨🇳 🇧🇷 🇷🇺 🇲🇽 🇿🇦 🇳🇬 🇪🇬 🇸🇦 🇦🇪 🇵🇰 🇧🇩 🇱🇰 🇳🇵 🇮🇩 🇹🇭 🇻🇳 🇸🇬 🇲🇾 🇵🇭 🇹🇷 🇳🇱 🇸🇪 🇨🇭 🇦🇷 🏁 🚩 🏴"),
    )
}
