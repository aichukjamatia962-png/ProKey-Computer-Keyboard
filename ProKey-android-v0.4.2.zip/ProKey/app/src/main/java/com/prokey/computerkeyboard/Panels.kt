package com.prokey.computerkeyboard

import android.annotation.SuppressLint
import android.content.Context
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Handler
import android.os.Looper
import android.text.TextUtils
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.widget.FrameLayout
import android.widget.HorizontalScrollView
import android.widget.LinearLayout
import android.widget.TextView
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView

private const val MATCH = ViewGroup.LayoutParams.MATCH_PARENT
private const val WRAP = ViewGroup.LayoutParams.WRAP_CONTENT

private fun lp(w: Int, h: Int, weight: Float = 0f) = LinearLayout.LayoutParams(w, h, weight)

private fun labelView(ctx: Context, text: String, theme: KbTheme, sizeSp: Float = 16f, bold: Boolean = false): TextView =
    TextView(ctx).apply {
        this.text = text
        textSize = sizeSp
        setTextColor(theme.text)
        gravity = Gravity.CENTER
        if (bold) setTypeface(null, Typeface.BOLD)
    }

private fun buttonView(ctx: Context, text: String, theme: KbTheme): TextView =
    labelView(ctx, text, theme, 15f, true).apply {
        background = GradientDrawable().apply {
            cornerRadius = 8f * ctx.resources.displayMetrics.density
            setColor(theme.keySpecial)
            if (theme.border != 0) setStroke(ctx.resources.displayMetrics.density.toInt().coerceAtLeast(1), theme.border)
        }
    }

/** Fires [action] on touch-down and repeats while held. */
@SuppressLint("ClickableViewAccessibility")
private fun repeatOnHold(v: View, action: () -> Unit) {
    val h = Handler(Looper.getMainLooper())
    val r = object : Runnable {
        override fun run() {
            action()
            h.postDelayed(this, 50L)
        }
    }
    v.setOnTouchListener { _, e ->
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                action()
                h.postDelayed(r, 400L)
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> h.removeCallbacks(r)
        }
        true
    }
}

/** Emoji picker: category tabs (recent first), scrollable grid, ABC and backspace. */
class EmojiPanel(
    context: Context,
    private val theme: KbTheme,
    prefs: Prefs,
    private val onEmoji: (String) -> Unit,
    onBack: () -> Unit,
    onDelete: () -> Unit,
    onSearch: () -> Unit,
) : LinearLayout(context) {

    private val dp = resources.displayMetrics.density
    private val adapter = EmojiAdapter()
    private val tabs = ArrayList<TextView>()
    private val cats: List<Pair<String, List<String>>>

    init {
        orientation = VERTICAL
        setBackgroundColor(theme.bg)
        cats = listOf("\uD83D\uDD58" to (prefs.emojiRecent() + EmojiData.popular).distinct().take(48)) + EmojiData.categories

        val tabRow = LinearLayout(context)
        for ((i, cat) in cats.withIndex()) {
            val tab = labelView(context, cat.first, theme, 20f).apply {
                setOnClickListener { select(i) }
            }
            tabs.add(tab)
            tabRow.addView(tab, lp((48 * dp).toInt(), MATCH))
        }
        val scroll = HorizontalScrollView(context).apply {
            isHorizontalScrollBarEnabled = false
            addView(tabRow)
        }
        addView(scroll, lp(MATCH, (40 * dp).toInt()))

        val spans = (resources.displayMetrics.widthPixels / (46 * dp)).toInt().coerceAtLeast(6)
        val grid = RecyclerView(context).apply {
            layoutManager = GridLayoutManager(context, spans)
            adapter = this@EmojiPanel.adapter
        }
        addView(grid, lp(MATCH, 0, 1f))

        val bottom = LinearLayout(context).apply {
            orientation = HORIZONTAL
            setPadding((6 * dp).toInt(), (4 * dp).toInt(), (6 * dp).toInt(), (4 * dp).toInt())
        }
        val abc = buttonView(context, "ABC", theme).apply { setOnClickListener { onBack() } }
        bottom.addView(abc, lp((80 * dp).toInt(), MATCH))
        val search = buttonView(context, "\uD83D\uDD0D", theme).apply { setOnClickListener { onSearch() } }
        bottom.addView(search, lp((60 * dp).toInt(), MATCH).apply { leftMargin = (6 * dp).toInt() })
        bottom.addView(View(context), lp(0, MATCH, 1f))
        val del = buttonView(context, "\u232B", theme)
        repeatOnHold(del) { onDelete() }
        bottom.addView(del, lp((80 * dp).toInt(), MATCH))
        addView(bottom, lp(MATCH, (46 * dp).toInt()))

        select(0)
    }

    private fun select(index: Int) {
        for ((i, t) in tabs.withIndex()) {
            t.alpha = if (i == index) 1f else 0.55f
            t.background = if (i == index) GradientDrawable().apply {
                cornerRadius = 8f * dp
                setColor(theme.key)
            } else null
        }
        adapter.items = cats[index].second
        adapter.notifyDataSetChanged()
    }

    private inner class EmojiAdapter : RecyclerView.Adapter<RecyclerView.ViewHolder>() {
        var items: List<String> = emptyList()

        override fun getItemCount() = items.size

        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RecyclerView.ViewHolder {
            val tv = TextView(parent.context).apply {
                textSize = 26f
                gravity = Gravity.CENTER
                layoutParams = RecyclerView.LayoutParams(MATCH, (46 * dp).toInt())
            }
            return object : RecyclerView.ViewHolder(tv) {}
        }

        override fun onBindViewHolder(holder: RecyclerView.ViewHolder, position: Int) {
            val e = items[position]
            (holder.itemView as TextView).text = e
            holder.itemView.setOnClickListener { onEmoji(e) }
        }
    }
}

/** Optional clipboard history: tap to paste, pin, delete, clear. Empty/off states explain themselves. */
class ClipboardPanel(
    context: Context,
    private val theme: KbTheme,
    private val prefs: Prefs,
    private val store: ClipStore,
    private val onPaste: (String) -> Unit,
    private val onCopy: (String) -> Unit,
    onBack: () -> Unit,
) : LinearLayout(context) {

    private val dp = resources.displayMetrics.density
    private val adapter = ClipAdapter()
    private val list = RecyclerView(context)
    private val message = labelView(context, "", theme, 14f)
    private val enableBtn = buttonView(context, "Turn on clipboard history", theme)

    init {
        orientation = VERTICAL
        setBackgroundColor(theme.bg)

        val top = LinearLayout(context).apply {
            orientation = HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding((10 * dp).toInt(), (4 * dp).toInt(), (6 * dp).toInt(), (4 * dp).toInt())
        }
        top.addView(labelView(context, "Clipboard", theme, 16f, true).apply { gravity = Gravity.START or Gravity.CENTER_VERTICAL }, lp(0, MATCH, 1f))
        val clear = buttonView(context, "Clear", theme).apply {
            setOnClickListener { store.clearUnpinned(); refresh() }
        }
        top.addView(clear, lp((72 * dp).toInt(), MATCH).apply { rightMargin = (6 * dp).toInt() })
        val abc = buttonView(context, "ABC", theme).apply { setOnClickListener { onBack() } }
        top.addView(abc, lp((72 * dp).toInt(), MATCH))
        addView(top, lp(MATCH, (44 * dp).toInt()))

        // one line that says what each icon does
        val hint = labelView(context, "Tap = paste     \uD83D\uDCC4 copy     \uD83D\uDCCC pin     \uD83D\uDDD1\uFE0F delete", theme, 12f)
        hint.alpha = 0.7f
        hint.gravity = Gravity.START or Gravity.CENTER_VERTICAL
        hint.setPadding((14 * dp).toInt(), 0, (8 * dp).toInt(), 0)
        addView(hint, lp(MATCH, (24 * dp).toInt()))

        list.layoutManager = LinearLayoutManager(context)
        list.adapter = adapter
        addView(list, lp(MATCH, 0, 1f))

        addView(message, lp(MATCH, WRAP).apply { topMargin = (16 * dp).toInt() })
        enableBtn.setOnClickListener { prefs.clipEnabled = true; refresh() }
        addView(enableBtn, lp((240 * dp).toInt(), (40 * dp).toInt()).apply {
            gravity = Gravity.CENTER_HORIZONTAL
            topMargin = (12 * dp).toInt()
        })
        refresh()
    }

    private fun refresh() {
        val items = store.items()
        adapter.items = items
        adapter.notifyDataSetChanged()
        val showList = items.isNotEmpty()
        list.visibility = if (showList) View.VISIBLE else View.GONE
        message.visibility = if (showList) View.GONE else View.VISIBLE
        enableBtn.visibility = if (!showList && !prefs.clipEnabled) View.VISIBLE else View.GONE
        if (!showList) {
            message.text = if (prefs.clipEnabled) {
                "Nothing saved yet.\nCopy some text and it will show up here."
            } else {
                "Clipboard history is off.\nWhen on, copied text is saved only on this phone."
            }
        }
    }

    private inner class ClipHolder(
        val row: LinearLayout, val text: TextView, val copy: TextView, val pin: TextView, val del: TextView,
    ) : RecyclerView.ViewHolder(row)

    private inner class ClipAdapter : RecyclerView.Adapter<ClipHolder>() {
        var items: List<ClipStore.Item> = emptyList()

        override fun getItemCount() = items.size

        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ClipHolder {
            val ctx = parent.context
            val row = LinearLayout(ctx).apply {
                orientation = HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                setPadding((12 * dp).toInt(), (6 * dp).toInt(), (4 * dp).toInt(), (6 * dp).toInt())
                background = GradientDrawable().apply {
                    cornerRadius = 10f * dp
                    setColor(theme.key)
                }
                layoutParams = RecyclerView.LayoutParams(MATCH, WRAP).apply {
                    setMargins((8 * dp).toInt(), (3 * dp).toInt(), (8 * dp).toInt(), (3 * dp).toInt())
                }
            }
            val text = TextView(ctx).apply {
                textSize = 14f
                setTextColor(theme.text)
                maxLines = 2
                ellipsize = TextUtils.TruncateAt.END
            }
            val copy = labelView(ctx, "\uD83D\uDCC4", theme, 18f)
            val pin = labelView(ctx, "\uD83D\uDCCC", theme, 18f)
            val del = labelView(ctx, "\uD83D\uDDD1\uFE0F", theme, 18f)
            row.addView(text, lp(0, WRAP, 1f))
            row.addView(copy, lp((42 * dp).toInt(), (42 * dp).toInt()))
            row.addView(pin, lp((42 * dp).toInt(), (42 * dp).toInt()))
            row.addView(del, lp((42 * dp).toInt(), (42 * dp).toInt()))
            return ClipHolder(row, text, copy, pin, del)
        }

        override fun onBindViewHolder(holder: ClipHolder, position: Int) {
            val item = items[position]
            holder.text.text = item.text
            holder.pin.alpha = if (item.pinned) 1f else 0.35f
            holder.copy.setOnClickListener { onCopy(item.text) }
            holder.row.setOnClickListener { onPaste(item.text) }
            holder.pin.setOnClickListener { store.setPinned(item.text, !item.pinned); refresh() }
            holder.del.setOnClickListener { store.remove(item.text); refresh() }
        }
    }
}

/** Emoji search: a search box showing what you typed (with a caret) and the matching emojis; the keyboard below types the query. */
class SearchPanel(
    context: Context,
    private val theme: KbTheme,
    private val onPick: (String) -> Unit,
    onClose: () -> Unit,
) : LinearLayout(context) {

    private val dp = resources.displayMetrics.density
    private val queryView = labelView(context, "", theme, 17f)
    private val emptyView = labelView(context, "", theme, 14f)
    private val resultAdapter = ResultAdapter()

    init {
        orientation = VERTICAL
        setBackgroundColor(theme.bg)
        val top = LinearLayout(context).apply {
            orientation = HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding((8 * dp).toInt(), (4 * dp).toInt(), (6 * dp).toInt(), (4 * dp).toInt())
        }
        // the search box
        queryView.gravity = Gravity.START or Gravity.CENTER_VERTICAL
        queryView.setPadding((12 * dp).toInt(), 0, (8 * dp).toInt(), 0)
        queryView.maxLines = 1
        queryView.background = GradientDrawable().apply {
            cornerRadius = 10f * dp
            setColor(theme.keySpecial or 0xFF000000.toInt())
            setStroke((1.5f * dp).toInt().coerceAtLeast(1), theme.accent)
        }
        top.addView(queryView, lp(0, MATCH, 1f).apply { rightMargin = (8 * dp).toInt() })
        val close = buttonView(context, "\u2715", theme).apply { setOnClickListener { onClose() } }
        top.addView(close, lp((52 * dp).toInt(), MATCH))
        addView(top, lp(MATCH, (44 * dp).toInt()))

        val list = RecyclerView(context).apply {
            layoutManager = LinearLayoutManager(context, LinearLayoutManager.HORIZONTAL, false)
            adapter = resultAdapter
        }
        val results = FrameLayout(context)
        results.addView(list, FrameLayout.LayoutParams(MATCH, MATCH))
        results.addView(emptyView, FrameLayout.LayoutParams(MATCH, MATCH))
        addView(results, lp(MATCH, (56 * dp).toInt()))
        setQuery("", emptyList(), false)
    }

    /** [results] are shown as typed; [noMatch] shows a "nothing found" note instead. */
    fun setQuery(q: String, results: List<String>, noMatch: Boolean) {
        if (q.isEmpty()) {
            queryView.text = "\uD83D\uDD0D  Type here: love, fire, pizza, dil..."
            queryView.alpha = 0.7f
        } else {
            queryView.text = "\uD83D\uDD0D  $q|"
            queryView.alpha = 1f
        }
        emptyView.text = if (noMatch) "No emoji found for \"${q.trim()}\"" else ""
        resultAdapter.items = results
        resultAdapter.notifyDataSetChanged()
    }

    private inner class ResultAdapter : RecyclerView.Adapter<RecyclerView.ViewHolder>() {
        var items: List<String> = emptyList()

        override fun getItemCount() = items.size

        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RecyclerView.ViewHolder {
            val tv = TextView(parent.context).apply {
                textSize = 28f
                gravity = Gravity.CENTER
                layoutParams = RecyclerView.LayoutParams((52 * dp).toInt(), MATCH)
            }
            return object : RecyclerView.ViewHolder(tv) {}
        }

        override fun onBindViewHolder(holder: RecyclerView.ViewHolder, position: Int) {
            val e = items[position]
            (holder.itemView as TextView).text = e
            holder.itemView.setOnClickListener { onPick(e) }
        }
    }
}

/** Symbols picker: category tabs, scrollable grid, ABC and backspace. */
class GlyphPanel(
    context: Context,
    private val theme: KbTheme,
    private val cats: List<Pair<String, List<String>>>,
    private val onPick: (String) -> Unit,
    onBack: () -> Unit,
    onDelete: () -> Unit,
) : LinearLayout(context) {

    private val dp = resources.displayMetrics.density
    private val glyphAdapter = GlyphAdapter()
    private val tabs = ArrayList<TextView>()

    init {
        orientation = VERTICAL
        setBackgroundColor(theme.bg)
        val tabRow = LinearLayout(context)
        for ((i, cat) in cats.withIndex()) {
            val tab = labelView(context, cat.first, theme, 18f).apply { setOnClickListener { select(i) } }
            tabs.add(tab)
            tabRow.addView(tab, lp((52 * dp).toInt(), MATCH))
        }
        val scroll = HorizontalScrollView(context).apply {
            isHorizontalScrollBarEnabled = false
            addView(tabRow)
        }
        addView(scroll, lp(MATCH, (40 * dp).toInt()))

        val spans = (resources.displayMetrics.widthPixels / (46 * dp)).toInt().coerceAtLeast(6)
        val grid = RecyclerView(context).apply {
            layoutManager = GridLayoutManager(context, spans)
            adapter = glyphAdapter
        }
        addView(grid, lp(MATCH, 0, 1f))

        val bottom = LinearLayout(context).apply {
            orientation = HORIZONTAL
            setPadding((6 * dp).toInt(), (4 * dp).toInt(), (6 * dp).toInt(), (4 * dp).toInt())
        }
        bottom.addView(buttonView(context, "ABC", theme).apply { setOnClickListener { onBack() } }, lp((80 * dp).toInt(), MATCH))
        bottom.addView(View(context), lp(0, MATCH, 1f))
        val del = buttonView(context, "\u232B", theme)
        repeatOnHold(del) { onDelete() }
        bottom.addView(del, lp((80 * dp).toInt(), MATCH))
        addView(bottom, lp(MATCH, (46 * dp).toInt()))
        select(0)
    }

    private fun select(index: Int) {
        for ((i, t) in tabs.withIndex()) {
            t.alpha = if (i == index) 1f else 0.55f
            t.background = if (i == index) GradientDrawable().apply {
                cornerRadius = 8f * dp
                setColor(theme.key)
            } else null
        }
        glyphAdapter.items = cats[index].second
        glyphAdapter.notifyDataSetChanged()
    }

    private inner class GlyphAdapter : RecyclerView.Adapter<RecyclerView.ViewHolder>() {
        var items: List<String> = emptyList()

        override fun getItemCount() = items.size

        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RecyclerView.ViewHolder {
            val tv = TextView(parent.context).apply {
                textSize = 22f
                setTextColor(theme.text)
                gravity = Gravity.CENTER
                layoutParams = RecyclerView.LayoutParams(MATCH, (46 * dp).toInt())
            }
            return object : RecyclerView.ViewHolder(tv) {}
        }

        override fun onBindViewHolder(holder: RecyclerView.ViewHolder, position: Int) {
            val g = items[position]
            (holder.itemView as TextView).text = g
            holder.itemView.setOnClickListener { onPick(g) }
        }
    }
}
