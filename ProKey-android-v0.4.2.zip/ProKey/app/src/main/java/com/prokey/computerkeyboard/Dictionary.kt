package com.prokey.computerkeyboard

import android.content.Context
import org.json.JSONObject
import java.io.File
import kotlin.math.abs

/** English word list (assets/en_words.txt: first line = number of common "head" words, then one word per line, most common first). */
class WordDict {
    private var w: Array<String> = emptyArray()   // alphabetical
    private var r: IntArray = IntArray(0)         // rank of each word (0 = most common)

    var headCount = 0
        private set

    @Volatile
    var ready = false
        private set

    private val rowA = IntArray(24)
    private val rowB = IntArray(24)
    private val rowC = IntArray(24)

    fun load(ctx: Context) {
        val lines = ArrayList<String>(140_000)
        var head = 0
        ctx.assets.open("en_words.txt").bufferedReader().use { br ->
            head = br.readLine().trim().toInt()
            while (true) {
                val l = br.readLine() ?: break
                if (l.isNotEmpty()) lines.add(l)
            }
        }
        val order = lines.indices.sortedBy { lines[it] }
        w = Array(lines.size) { lines[order[it]] }
        r = IntArray(lines.size) { order[it] }
        headCount = head
        ready = true
    }

    private fun lowerBound(s: String): Int {
        var lo = 0
        var hi = w.size
        while (lo < hi) {
            val mid = (lo + hi) ushr 1
            if (w[mid] < s) lo = mid + 1 else hi = mid
        }
        return lo
    }

    fun isKnown(word: String): Boolean {
        if (!ready) return false
        val i = lowerBound(word)
        return i < w.size && w[i] == word
    }

    /** Most common words starting with [prefix]. */
    fun complete(prefix: String, limit: Int): List<String> {
        if (!ready || prefix.isEmpty() || limit <= 0) return emptyList()
        val bestRank = IntArray(limit) { Int.MAX_VALUE }
        val bestIdx = IntArray(limit) { -1 }
        var i = lowerBound(prefix)
        while (i < w.size && w[i].startsWith(prefix)) {
            var worst = 0
            for (k in 1 until limit) if (bestRank[k] > bestRank[worst]) worst = k
            if (r[i] < bestRank[worst]) {
                bestRank[worst] = r[i]
                bestIdx[worst] = i
            }
            i++
        }
        return (0 until limit).filter { bestIdx[it] >= 0 }.sortedBy { bestRank[it] }.map { w[bestIdx[it]] }
    }

    /** Words within [maxDist] edits (substitution, insert, delete, transposition) sharing the first letter. */
    fun corrections(word: String, maxDist: Int, headOnly: Boolean, limit: Int): List<Pair<String, Int>> {
        if (!ready || word.isEmpty() || word.length > 20) return emptyList()
        val first = word[0]
        var i = lowerBound(first.toString())
        val found = ArrayList<Triple<Int, Int, String>>()
        while (i < w.size && w[i][0] == first) {
            val c = w[i]
            if (c != word && abs(c.length - word.length) <= maxDist && (!headOnly || r[i] < headCount)) {
                val d = osa(word, c)
                if (d <= maxDist) found.add(Triple(d, r[i], c))
            }
            i++
        }
        found.sortWith(compareBy({ it.first }, { it.second }))
        return found.take(limit).map { Pair(it.third, it.first) }
    }

    /** Optimal-string-alignment edit distance. */
    private fun osa(a: String, b: String): Int {
        val n = a.length
        val m = b.length
        if (n > 20 || m > 20) return 99
        var prev2 = rowA
        var prev = rowB
        var cur = rowC
        for (j in 0..m) prev[j] = j
        for (i in 1..n) {
            cur[0] = i
            for (j in 1..m) {
                val cost = if (a[i - 1] == b[j - 1]) 0 else 1
                var v = minOf(prev[j] + 1, cur[j - 1] + 1, prev[j - 1] + cost)
                if (i > 1 && j > 1 && a[i - 1] == b[j - 2] && a[i - 2] == b[j - 1]) v = minOf(v, prev2[j - 2] + 1)
                cur[j] = v
            }
            val t = prev2
            prev2 = prev
            prev = cur
            cur = t
        }
        return prev[m]
    }
}

/** Small bundled "word -> likely next words" seeds (assets/en_next.txt). */
class NextWords {
    private val map = HashMap<String, List<String>>()

    fun load(ctx: Context) {
        ctx.assets.open("en_next.txt").bufferedReader().useLines { lines ->
            for (line in lines) {
                val idx = line.indexOf(':')
                if (idx <= 0) continue
                val key = line.substring(0, idx).trim().lowercase()
                val words = line.substring(idx + 1).trim().split(" ").filter { it.isNotEmpty() }
                map[key] = ((map[key] ?: emptyList()) + words).distinct()
            }
        }
    }

    fun get(prev: String): List<String> = map[prev] ?: emptyList()
}

/**
 * The user's personal dictionary and learned word pairs. Stored only in this app's private storage
 * (filesDir/personal_dict.json, unencrypted), and only when "Learn new words" is on.
 */
class PersonalDict(ctx: Context) {
    private val file = File(ctx.applicationContext.filesDir, "personal_dict.json")
    private val words = HashMap<String, Int>()
    private val bigrams = HashMap<String, Int>()
    private val uses = HashMap<String, Int>()   // how often you type words that are in the main dictionary
    private var dirty = false

    @Volatile
    var ready = false
        private set

    @Synchronized
    fun load() {
        words.clear()
        bigrams.clear()
        uses.clear()
        if (file.exists()) {
            try {
                val o = JSONObject(file.readText())
                o.optJSONObject("w")?.let { j -> j.keys().forEach { k -> words[k] = j.getInt(k) } }
                o.optJSONObject("b")?.let { j -> j.keys().forEach { k -> bigrams[k] = j.getInt(k) } }
                o.optJSONObject("u")?.let { j -> j.keys().forEach { k -> uses[k] = j.getInt(k) } }
            } catch (e: Exception) {
                words.clear()
                bigrams.clear()
                uses.clear()
            }
        }
        dirty = false
        ready = true
    }

    @Synchronized
    fun flush() {
        if (!dirty) return
        val o = JSONObject()
        val jw = JSONObject()
        for ((k, v) in words) jw.put(k, v)
        val jb = JSONObject()
        for ((k, v) in bigrams) jb.put(k, v)
        val ju = JSONObject()
        for ((k, v) in uses) ju.put(k, v)
        o.put("w", jw).put("b", jb).put("u", ju)
        try {
            file.writeText(o.toString())
            dirty = false
        } catch (e: Exception) {
            // keep dirty; try again later
        }
    }

    /** A word becomes "known" after it was typed twice (or added explicitly). */
    @Synchronized
    fun known(word: String): Boolean = (words[word] ?: 0) >= 2

    @Synchronized
    fun complete(prefix: String, limit: Int): List<String> =
        words.filter { it.value >= 2 && it.key.length > prefix.length && it.key.startsWith(prefix) }
            .entries.sortedByDescending { it.value }.take(limit).map { it.key }

    @Synchronized
    fun useCount(word: String): Int = uses[word] ?: 0

    @Synchronized
    fun next(prev: String, limit: Int): List<String> {
        val p = "$prev "
        return bigrams.filter { it.key.startsWith(p) && it.value >= 2 }
            .entries.sortedByDescending { it.value }.take(limit).map { it.key.substring(p.length) }
    }

    /** Called when a word is finished. [wordKnownToDict] = it is in the bundled dictionary. */
    @Synchronized
    fun observe(word: String, prev: String?, wordKnownToDict: Boolean, pairs: Boolean) {
        if (word.length < 2 || word.length > 24) return
        if (!wordKnownToDict) {
            words[word] = (words[word] ?: 0) + 1
            dirty = true
        } else {
            uses[word] = (uses[word] ?: 0) + 1
            dirty = true
            if (uses.size > 3000) {
                val drop = uses.entries.sortedBy { it.value }.take(300).map { it.key }
                drop.forEach { uses.remove(it) }
            }
        }
        if (pairs && prev != null && prev.isNotEmpty() && prev.length <= 24) {
            val key = "$prev $word"
            bigrams[key] = (bigrams[key] ?: 0) + 1
            dirty = true
            if (bigrams.size > 1500) {
                val drop = bigrams.entries.sortedBy { it.value }.take(200).map { it.key }
                drop.forEach { bigrams.remove(it) }
            }
        }
        if (words.size > 5000) {
            val drop = words.entries.sortedBy { it.value }.take(500).map { it.key }
            drop.forEach { words.remove(it) }
        }
    }

    @Synchronized
    fun addExplicit(word: String) {
        if (word.isEmpty() || word.length > 24) return
        words[word] = maxOf(words[word] ?: 0, 5)
        dirty = true
    }

    @Synchronized
    fun remove(word: String) {
        words.remove(word)
        uses.remove(word)
        bigrams.keys.filter { it.startsWith("$word ") || it.endsWith(" $word") }.forEach { bigrams.remove(it) }
        dirty = true
    }

    @Synchronized
    fun clearAll() {
        words.clear()
        bigrams.clear()
        uses.clear()
        dirty = true
        flush()
    }

    @Synchronized
    fun allWords(): List<String> = words.filter { it.value >= 2 }.keys.sorted()
}
