# ProKey – Computer Keyboard (v0.2.0)

Native Android keyboard (InputMethodService, Kotlin). Package: `com.prokey.computerkeyboard` (keep it permanent after first release). Default look: Black & Gold.

**Status: source only. This project has NOT been compiled or run yet.** It was written without the Android SDK, Gradle or a device. Expect a few compile errors on first build, then test on real phones before trusting it. No APK exists until you build one.

## Get an APK

**Option A, GitHub (no local setup):** create a GitHub repo, push this folder, open the Actions tab. `.github/workflows/build.yml` builds the debug APK on every push and uploads it as the artifact `ProKey-debug-apk`. If the build fails, open the log and send me the first errors.

**Option B, Android Studio:** open this folder, let Gradle sync, then Build > Build APK(s), or `./gradlew assembleDebug` (run `gradle wrapper` once if `gradlew` is missing). Output: `app/build/outputs/apk/debug/app-debug.apk`. If Studio offers to upgrade AGP/Gradle/Kotlin, accept; versions here are conservative (AGP 8.7.3, Kotlin 2.0.21, Gradle 8.9, compileSdk 35).

Install with `adb install -r app-debug.apk` or copy the APK to the phone. Activate: ProKey > "1. Enable ProKey" > "2. Select ProKey". ProKey never switches itself to default.

The app has no native code, so one APK runs on 32-bit and 64-bit phones.

## Release signing

```
keytool -genkeypair -v -keystore prokey-release.jks -alias prokey -keyalg RSA -keysize 2048 -validity 10000
cp keystore.properties.example keystore.properties   # then edit with your values
./gradlew assembleRelease     # app/build/outputs/apk/release/app-release.apk
./gradlew bundleRelease       # AAB, for stores that take bundles
apksigner verify --print-certs app/build/outputs/apk/release/app-release.apk
```

`keystore.properties` and `*.jks` are git-ignored. Never commit them. Back up the keystore: losing it means you cannot update the app. Without `keystore.properties` the release build is unsigned and will not install.

## What is in v0.2.0

Mobile mode
- QWERTY, number row, Shift (tap / double-tap lock), `?123` with two symbol pages.
- Page 2/2: brackets, math (× ÷ ± ≠ ≈ ≤ ≥ √ π ∅), punctuation and legal (• … — – © ® ™ § ¶ ★), and a currency row starting with ₹ then £ € ¥ ¢ ° %. `~` and `` ` `` moved to the long-press of `'`.
- Long-press popups (slide to pick, release to insert): `$` ₹ € £ ¥ ¢ ₿, `-` – — _, `.` … ? ! , : ; / @, `0` ° ∅, `=` ≠ ≈ ≤ ≥, `*` × • ★, `/` ÷ \, plus `'` and `"` quotes, and accented letters for a c e i l n o s u y z. Popup letters follow Shift.
- Top toolbar (can be switched off): Emoji, Clipboard, Undo, Redo, Mic.
- Emoji panel: recent + 9 categories (a curated set of 428 emojis, no search yet).
- Clipboard history: OFF by default, enable it in the panel or in settings; pin, delete, clear, size limit; not recorded in password fields or for clips marked sensitive.
- Mic: opens your phone's speech-recognition screen and types the result. ProKey itself never uses the microphone.
- Spacebar swipe moves the cursor. Backspace swipe left deletes whole words. Auto-capitalization, double-space period.
- Key preview bubble with a theme-accent (gold in the default theme) border; haptics and key sound toggles.

PC mode
- Compact portrait and full landscape layouts with F-keys, nav keys, arrows, optional numpad.
- Dual-label keys: the Shift symbol is shown in the key's top corner (1 with !, ; with :, etc.) and swaps when Shift is active.
- Sticky modifiers: tap Shift/Ctrl/Alt/Win once = gold, applies to the next key, then resets. Double-tap = locked (gold with a bar) until tapped again.
- Right-side Ctrl before the arrows (spacebar slightly narrower).
- Optional top quick-action bar (settings > Quick-action bar): Undo, Redo, Cut, Copy, Paste, Select All, Find.

Also: 15 themes (default Gold Premium), height/spacing/corner sliders, sound and vibration controls, settings screen with a live "try it" field.

## Android limits and how keys behave

| Key | What happens |
|---|---|
| Letters, digits, punctuation, Space, Enter, Backspace | Handled through InputConnection. Works everywhere. |
| Arrows, Home, End, Del, Tab, Esc, Ins, PgUp/PgDn | Sent as KeyEvents. Work where the app handles them. |
| F1-F12 | Sent as KeyEvents. Most Android apps ignore them; useful in terminals, remote desktop, some web apps. |
| Ctrl+A/C/X/V | Executed directly on the focused editor. |
| Undo / Redo / Cut / Copy / Paste / Select All buttons | Use the editor's own action; if the app does not support it, ProKey sends Ctrl+Z / Ctrl+Y / Ctrl+X / Ctrl+C / Ctrl+V / Ctrl+A. |
| Find | Sends Ctrl+F. Works only where the app has that shortcut (e.g. browsers). |
| Other Ctrl/Alt/Shift combos | Sent as a KeyEvent with modifier flags; app must support the shortcut. |
| Win (Meta) | Adds the Meta flag to key events. No system-level effect. |
| Print Screen | A keyboard cannot take screenshots. Sends the event and shows a hint to use the phone shortcut. |
| Menu | Sends KEYCODE_MENU; most apps ignore it. |
| Fn | Shows/hides the F1-F12 row. |
| Mic | Needs a speech-recognition app (normally Google). Audio is processed by that app, not ProKey. |

## Not in this build yet

Word suggestions / autocorrect / next-word, personal dictionary, Hindi and transliteration, emoji and symbol search, custom theme editor (colors, background image, save/reset), one-handed / floating / split / left-right layouts, a Globe-long-press shortcut to emoji (emoji lives in the top toolbar instead), 512x512 PNG icon, store screenshots, OPPO submission package.

## Other notes

- `targetSdk` is 34 on purpose. Android 15 edge-to-edge changes affect IME windows; raise to 35 after testing on a device.
- Key sound uses Android touch sounds. If Touch sounds is off in system settings you will hear nothing.
- Key preview for keys in the very top row overlays that row (there is no window above the keyboard to draw into).
- Clipboard history, when on, is stored unencrypted in the app's private storage.
- ColorOS / Realme UI / One UI / HyperOS compatibility, battery and RAM behaviour are untested. See docs/TESTING.md.
