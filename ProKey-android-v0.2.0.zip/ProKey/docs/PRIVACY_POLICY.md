# ProKey – Computer Keyboard: Privacy Policy

Last updated: (set date before publishing)

ProKey is a keyboard. What you type stays on your device.

- ProKey does not collect, store, log or transmit anything you type, including passwords and one-time codes.
- ProKey has no INTERNET permission, no accounts, no advertising and no analytics or tracking SDKs.
- ProKey saves on your device only: your keyboard settings, a short list of recently used emojis, and, only if you turn the feature on, a clipboard history (default: off; you can pin, delete or clear entries, and set a size limit). Clipboard history is not recorded while a password field is active or for clipboard content that the copying app marks as sensitive. This data is kept in the app's private storage and is not encrypted.
- Voice typing: the microphone key opens your phone's speech-recognition app (for example Google). ProKey does not access the microphone and has no audio permission. The speech-recognition app may process audio, possibly on its servers, under its own privacy policy. ProKey only receives the resulting text and types it.
- ProKey requests the VIBRATE permission only to vibrate on key presses.
- This version has no word suggestions or personal dictionary. If a future version adds them, they will be stored only on your device and this policy will be updated before release.
- Uninstalling ProKey removes all of the data above. Settings > "Clear clipboard history and recent emojis" removes the clipboard and emoji data at any time.

Contact: (your email / support address)

Hosting: publish this text at a public URL (for example a GitHub Pages page or your own site) and use that URL in store listings.
