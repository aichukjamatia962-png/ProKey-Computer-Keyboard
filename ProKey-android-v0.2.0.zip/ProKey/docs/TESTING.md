# Manual test checklist (core build)

Run on at least one OPPO/ColorOS phone, one other brand, and one emulator. Tick each when verified.

Activation
- [ ] Enable ProKey in Android keyboard list; select it from the picker
- [ ] Main screen status text updates (not enabled / not selected / ready)
- [ ] Globe key switches to the next keyboard; settings key opens ProKey settings

Mobile mode (try Notes, a browser address bar, a chat app, a multi-line field)
- [ ] Every letter a-z and A-Z; every digit; every symbol on both `?123` pages
- [ ] Shift one-shot, double-tap caps lock, auto-capitalization at sentence start
- [ ] Backspace (tap and hold), Enter (newline vs Go/Search/Send), Space, double-space period
- [ ] Spacebar swipe moves the cursor; fast two-thumb typing drops no keys
- [ ] Number/phone fields open on the symbols page; password fields type correctly

PC mode
- [ ] Every key in compact (portrait) and full (landscape) layouts, with and without function row and numpad
- [ ] Ctrl+A/C/X/V, Ctrl+Z, Shift+arrows selection, Alt/Win flags in a terminal-type app
- [ ] F1-F12, Esc, Tab, Home, End, PgUp, PgDn, Ins, Del, arrows (note which apps react)
- [ ] Caps Lock, Fn toggle, ABC/PC switch

Settings and look
- [ ] All 15 themes readable (text vs key contrast), in portrait and landscape
- [ ] Height, spacing, radius sliders update the open keyboard live
- [ ] Key sound (with system touch sounds on), volume, vibration on/off and intensity
- [ ] Rotation while the keyboard is open

Release
- [ ] Install over an older build (upgrade), signature verifies, no INTERNET permission in the APK manifest

## v0.2.0 additions

Symbols and popups
- [ ] Symbols page 2/2 shows ₹ £ € ¥ ¢ ° % in the bottom row; math, punctuation and legal rows insert correctly
- [ ] Long-press `$ - . 0 = * /` `'` `"` and accented letters: popup appears, slide to choose, release inserts; release outside cancels; popups follow Shift
- [ ] Popup on top-row keys (number row off, toolbar off) is visible and usable

Toolbar, panels, voice
- [ ] Emoji panel: tabs, insert, recents, ABC back, backspace hold-repeat; flags and newer emojis render on your phone
- [ ] Clipboard: off by default; turn on, copy text in another app, it appears; tap to paste, pin, delete, Clear (keeps pinned); nothing saved from a password field
- [ ] Undo/Redo in a notes app and in a browser text box (editor action or Ctrl+Z/Y fallback)
- [ ] Mic: speech screen opens, text is typed after it closes; behaves on a phone without Google speech services

Typing feel
- [ ] Backspace swipe left deletes words (and a selection); normal backspace tap/hold still works
- [ ] Key preview shows with gold border; toggle it off in settings
- [ ] Spacebar swipe, auto-cap, double-space period unchanged

PC mode
- [ ] Corner hints on number/punctuation keys; they swap when Shift is active
- [ ] Tap Ctrl then C copies (gold highlight, resets after); double-tap Shift/Ctrl locks (bar shown), tap again unlocks
- [ ] Right Ctrl before the arrows works; quick-action bar buttons (turn it on in settings) work or fall back as documented
