package com.prokey.computerkeyboard

import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.content.res.Configuration
import android.inputmethodservice.InputMethodService
import android.media.AudioManager
import android.os.Build
import android.os.SystemClock
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager
import android.text.InputType
import android.view.KeyCharacterMap
import android.view.KeyEvent
import android.view.View
import android.view.ViewGroup
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputConnection
import android.view.inputmethod.InputMethodManager
import android.widget.FrameLayout
import android.widget.Toast
import androidx.preference.PreferenceManager
import kotlin.math.abs
import kotlin.math.max

/**
 * The real Android keyboard (InputMethodService). All text goes through InputConnection;
 * nothing the user types is stored, logged or transmitted.
 */
class ProKeyService : InputMethodService(), KeyboardView.Listener,
    SharedPreferences.OnSharedPreferenceChangeListener {

    private enum class PanelKind { EMOJI, CLIPBOARD }

    private lateinit var prefs: Prefs
    private lateinit var audio: AudioManager
    private lateinit var clipStore: ClipStore
    private var vibrator: Vibrator? = null
    private var clipManager: ClipboardManager? = null

    private val state = KbState()
    private var rootView: FrameLayout? = null
    private var keyboard: KeyboardView? = null
    private var panel: View? = null
    private var editorInfo: EditorInfo? = null
    private var sensitive = false
    private var symbols = false
    private var symbolPage = 0
    private var lastSpaceTime = 0L

    // cached feedback / typing prefs (read on every key press)
    private var soundOn = false
    private var soundVol = 0.5f
    private var vibOn = true
    private var vibLevel = 50
    private var autoCap = true
    private var doubleSpace = true

    private val clipListener = ClipboardManager.OnPrimaryClipChangedListener { captureClip() }

    // ---- lifecycle --------------------------------------------------------------------------

    override fun onCreate() {
        super.onCreate()
        PreferenceManager.setDefaultValues(this, R.xml.preferences, false)
        prefs = Prefs(this)
        clipStore = ClipStore(this)
        audio = getSystemService(Context.AUDIO_SERVICE) as AudioManager
        vibrator = findVibrator()
        loadCachedPrefs()
        prefs.sp.registerOnSharedPreferenceChangeListener(this)
        clipManager = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        clipManager?.addPrimaryClipChangedListener(clipListener)
    }

    override fun onDestroy() {
        clipManager?.removePrimaryClipChangedListener(clipListener)
        prefs.sp.unregisterOnSharedPreferenceChangeListener(this)
        super.onDestroy()
    }

    @Suppress("DEPRECATION")
    private fun findVibrator(): Vibrator? =
        if (Build.VERSION.SDK_INT >= 31) {
            (getSystemService(Context.VIBRATOR_MANAGER_SERVICE) as VibratorManager).defaultVibrator
        } else {
            getSystemService(Context.VIBRATOR_SERVICE) as Vibrator
        }

    private fun loadCachedPrefs() {
        soundOn = prefs.soundOn
        soundVol = prefs.soundVolume / 100f
        vibOn = prefs.vibrateOn
        vibLevel = prefs.vibrateLevel
        autoCap = prefs.autoCap
        doubleSpace = prefs.doubleSpace
    }

    override fun onSharedPreferenceChanged(sp: SharedPreferences?, key: String?) {
        loadCachedPrefs()
        rebuild()
    }

    override fun onEvaluateFullscreenMode(): Boolean = false

    override fun onCreateInputView(): View {
        val root = FrameLayout(this)
        val kb = KeyboardView(this)
        kb.listener = this
        kb.state = state
        root.addView(kb, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        rootView = root
        keyboard = kb
        panel = null
        rebuild()
        return root
    }

    override fun onConfigurationChanged(newConfig: Configuration) {
        super.onConfigurationChanged(newConfig)
        rebuild()
    }

    override fun onStartInputView(info: EditorInfo, restarting: Boolean) {
        super.onStartInputView(info, restarting)
        editorInfo = info
        sensitive = isSensitive(info)
        if (!restarting) {
            hidePanel()
            state.resetAll()
            val cls = info.inputType and InputType.TYPE_MASK_CLASS
            symbols = !prefs.pc &&
                (cls == InputType.TYPE_CLASS_NUMBER || cls == InputType.TYPE_CLASS_PHONE)
            symbolPage = 0
            lastSpaceTime = 0L
        }
        rebuild()
        updateAutoCap()
        keyboard?.invalidate()
        // Text from the mic key arrives while the speech screen is open; type it now.
        VoiceBridge.take()?.let { currentInputConnection?.commitText("$it ", 1) }
    }

    override fun onUpdateSelection(
        oldSelStart: Int, oldSelEnd: Int, newSelStart: Int, newSelEnd: Int,
        candidatesStart: Int, candidatesEnd: Int
    ) {
        super.onUpdateSelection(oldSelStart, oldSelEnd, newSelStart, newSelEnd, candidatesStart, candidatesEnd)
        updateAutoCap()
        keyboard?.invalidate()
    }

    private fun isSensitive(info: EditorInfo): Boolean {
        val cls = info.inputType and InputType.TYPE_MASK_CLASS
        val variation = info.inputType and InputType.TYPE_MASK_VARIATION
        return when (cls) {
            InputType.TYPE_CLASS_TEXT ->
                variation == InputType.TYPE_TEXT_VARIATION_PASSWORD ||
                    variation == InputType.TYPE_TEXT_VARIATION_VISIBLE_PASSWORD ||
                    variation == InputType.TYPE_TEXT_VARIATION_WEB_PASSWORD
            InputType.TYPE_CLASS_NUMBER -> variation == InputType.TYPE_NUMBER_VARIATION_PASSWORD
            else -> false
        }
    }

    private fun rebuild() {
        val v = keyboard ?: return
        val landscape = resources.configuration.orientation == Configuration.ORIENTATION_LANDSCAPE
        val pc = prefs.pc
        state.fnRow = prefs.functionRow
        if (!pc) state.caps = false
        val rows = when {
            pc -> Layouts.pc(state.fnRow, landscape, landscape && prefs.numpad, prefs.pcQuickbar)
            symbols -> Layouts.symbols(symbolPage, prefs.toolbar)
            else -> Layouts.mobile(prefs.numberRow, prefs.toolbar)
        }
        val baseDp = if (pc) (if (landscape) 34f else 40f) else (if (landscape) 38f else 46f)
        v.setup(
            rows,
            Themes.byId(prefs.theme),
            KeyboardView.Look(baseDp * prefs.heightPct / 100f, prefs.gap.toFloat(), prefs.radius.toFloat(), prefs.keyPreview)
        )
    }

    private fun updateAutoCap() {
        if (prefs.pc || !autoCap || state.shift.state != Mod.OFF) return
        val ei = editorInfo ?: return
        val ic = currentInputConnection ?: return
        if (ic.getCursorCapsMode(ei.inputType) != 0) state.shift.state = Mod.ONCE
    }

    // ---- panels (emoji / clipboard) ---------------------------------------------------------

    private fun showPanel(kind: PanelKind) {
        val root = rootView ?: return
        val kb = keyboard ?: return
        val minH = (220 * resources.displayMetrics.density).toInt()
        val h = max(kb.height, minH)
        hidePanel()
        val theme = Themes.byId(prefs.theme)
        val p: View = when (kind) {
            PanelKind.EMOJI -> EmojiPanel(this, theme, prefs, ::commitEmoji, ::hidePanel, ::panelBackspace)
            PanelKind.CLIPBOARD -> ClipboardPanel(this, theme, prefs, clipStore, ::pasteClip, ::hidePanel)
        }
        kb.visibility = View.GONE
        root.addView(p, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, h))
        panel = p
    }

    private fun hidePanel() {
        panel?.let { rootView?.removeView(it) }
        panel = null
        keyboard?.visibility = View.VISIBLE
    }

    private fun commitEmoji(e: String) {
        currentInputConnection?.commitText(e, 1)
        if (!sensitive) prefs.addEmojiRecent(e)
    }

    private fun pasteClip(text: String) {
        currentInputConnection?.commitText(text, 1)
    }

    private fun panelBackspace() {
        sendCode(KeyEvent.KEYCODE_DEL, false)
    }

    /** Records copied text only while clipboard history is on, never in password fields or flagged-sensitive clips. */
    private fun captureClip() {
        if (!prefs.clipEnabled || sensitive) return
        val clip = clipManager?.primaryClip ?: return
        if (clip.itemCount == 0) return
        if (clip.description.extras?.getBoolean("android.content.extra.IS_SENSITIVE", false) == true) return
        val text = clip.getItemAt(0).coerceToText(this)?.toString()?.trim() ?: return
        if (text.isEmpty() || text.length > 5000) return
        clipStore.add(text, prefs.clipMax)
    }

    // ---- feedback ---------------------------------------------------------------------------

    override fun onPress(key: Key) {
        if (vibOn) vibrate()
        if (soundOn && soundVol > 0f) {
            val fx = when (key.type) {
                KeyType.SPACE -> AudioManager.FX_KEYPRESS_SPACEBAR
                KeyType.BACKSPACE -> AudioManager.FX_KEYPRESS_DELETE
                KeyType.ENTER -> AudioManager.FX_KEYPRESS_RETURN
                else -> AudioManager.FX_KEYPRESS_STANDARD
            }
            audio.playSoundEffect(fx, soundVol)
        }
    }

    private fun vibrate() {
        val v = vibrator ?: return
        if (!v.hasVibrator()) return
        val effect = if (v.hasAmplitudeControl()) {
            VibrationEffect.createOneShot(14L, (vibLevel * 255 / 100).coerceIn(1, 255))
        } else {
            VibrationEffect.createOneShot((6 + vibLevel / 3).toLong(), VibrationEffect.DEFAULT_AMPLITUDE)
        }
        v.vibrate(effect)
    }

    // ---- key handling -----------------------------------------------------------------------

    override fun onKey(key: Key) {
        when (key.type) {
            KeyType.CHAR -> typeChar(key)
            KeyType.SPACE -> typeSpace()
            KeyType.ENTER -> typeEnter()
            KeyType.BACKSPACE -> sendCode(KeyEvent.KEYCODE_DEL, prefs.pc)
            KeyType.CODE -> {
                if (key.keyCode == KeyEvent.KEYCODE_SYSRQ) {
                    Toast.makeText(this, "Print Screen: use your phone screenshot shortcut", Toast.LENGTH_SHORT).show()
                }
                sendCode(key.keyCode, true)
            }
            KeyType.SHIFT -> state.shift.tap()
            KeyType.CAPS -> state.caps = !state.caps
            KeyType.CTRL -> state.ctrl.tap()
            KeyType.ALT -> state.alt.tap()
            KeyType.META -> state.meta.tap()
            KeyType.FN -> prefs.functionRow = !prefs.functionRow
            KeyType.SYMBOLS -> { symbols = !symbols; symbolPage = 0; rebuild() }
            KeyType.SYMBOL_PAGE -> { symbolPage = 1 - symbolPage; rebuild() }
            KeyType.MODE -> { symbols = false; prefs.layoutMode = if (prefs.pc) "mobile" else "pc" }
            KeyType.GLOBE -> switchKeyboard()
            KeyType.SETTINGS -> openSettings()
            KeyType.TOOL -> key.tool?.let { runTool(it) }
            KeyType.SPACER -> Unit
        }
        keyboard?.invalidate()
    }

    override fun onAlt(key: Key, text: String) {
        val ic = currentInputConnection ?: return
        ic.commitText(Alts.cased(key, text, state.shift.on), 1)
        state.shift.consume()
        keyboard?.invalidate()
    }

    override fun onSpaceSwipe(steps: Int) {
        val code = if (steps < 0) KeyEvent.KEYCODE_DPAD_LEFT else KeyEvent.KEYCODE_DPAD_RIGHT
        repeat(abs(steps)) { sendCode(code, false) }
    }

    /** Backspace swipe: delete the selection, or the previous word (plus any spaces after it). */
    override fun onWordDelete() {
        val ic = currentInputConnection ?: return
        if (!ic.getSelectedText(0).isNullOrEmpty()) {
            ic.commitText("", 1)
            return
        }
        val before = ic.getTextBeforeCursor(120, 0)?.toString() ?: return
        if (before.isEmpty()) return
        var i = before.length
        while (i > 0 && before[i - 1].isWhitespace()) i--
        while (i > 0 && !before[i - 1].isWhitespace()) i--
        val count = before.codePointCount(i, before.length)
        if (count > 0) ic.deleteSurroundingTextInCodePoints(count, 0)
    }

    private fun outputText(k: Key): String {
        val st = k.shiftText ?: return k.text
        val upper = if (k.isLetter) state.shift.on != state.caps else state.shift.on
        return if (upper) st else k.text
    }

    private fun typeChar(key: Key) {
        val ic = currentInputConnection ?: return
        if (prefs.pc && state.anyCtrlAltMeta() && key.keyCode != KeyEvent.KEYCODE_UNKNOWN) {
            val handled = state.ctrl.on && !state.alt.on && !state.meta.on && ctrlShortcut(ic, key.keyCode)
            if (handled) state.consumeMods() else sendCode(key.keyCode, true)
            return
        }
        ic.commitText(outputText(key), 1)
        state.shift.consume()
    }

    /** Ctrl+A/C/X/V go straight to the editor; everything else is sent as a Ctrl key event. */
    private fun ctrlShortcut(ic: InputConnection, code: Int): Boolean = when (code) {
        KeyEvent.KEYCODE_A -> ic.performContextMenuAction(android.R.id.selectAll)
        KeyEvent.KEYCODE_C -> ic.performContextMenuAction(android.R.id.copy)
        KeyEvent.KEYCODE_X -> ic.performContextMenuAction(android.R.id.cut)
        KeyEvent.KEYCODE_V -> ic.performContextMenuAction(android.R.id.paste)
        else -> false
    }

    // ---- toolbar / quick-action bar ---------------------------------------------------------

    private fun runTool(t: Tool) {
        when (t) {
            Tool.EMOJI -> showPanel(PanelKind.EMOJI)
            Tool.CLIPBOARD -> showPanel(PanelKind.CLIPBOARD)
            Tool.MIC -> startVoice()
            Tool.UNDO -> editAction(android.R.id.undo, KeyEvent.KEYCODE_Z)
            Tool.REDO -> editAction(android.R.id.redo, KeyEvent.KEYCODE_Y)
            Tool.CUT -> editAction(android.R.id.cut, KeyEvent.KEYCODE_X)
            Tool.COPY -> editAction(android.R.id.copy, KeyEvent.KEYCODE_C)
            Tool.PASTE -> editAction(android.R.id.paste, KeyEvent.KEYCODE_V)
            Tool.SELECT_ALL -> editAction(android.R.id.selectAll, KeyEvent.KEYCODE_A)
            Tool.FIND -> sendKey(KeyEvent.KEYCODE_F, CTRL_META)
        }
    }

    /** Runs the editor's own action; if the app does not support it, falls back to the Ctrl+key shortcut. */
    private fun editAction(menuId: Int, fallbackKey: Int) {
        val ic = currentInputConnection ?: return
        if (!ic.performContextMenuAction(menuId)) sendKey(fallbackKey, CTRL_META)
    }

    private fun startVoice() {
        val i = Intent(this, VoiceActivity::class.java)
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_NO_ANIMATION)
        startActivity(i)
    }

    // ---- space / enter / key events ---------------------------------------------------------

    private fun typeSpace() {
        val ic = currentInputConnection ?: return
        if (prefs.pc && state.anyCtrlAltMeta()) {
            sendCode(KeyEvent.KEYCODE_SPACE, true)
            return
        }
        val now = SystemClock.uptimeMillis()
        if (!prefs.pc && doubleSpace && now - lastSpaceTime < 500L) {
            val before = ic.getTextBeforeCursor(2, 0)
            if (before != null && before.length == 2 && before[1] == ' ' && before[0].isLetterOrDigit()) {
                ic.beginBatchEdit()
                ic.deleteSurroundingText(1, 0)
                ic.commitText(". ", 1)
                ic.endBatchEdit()
                lastSpaceTime = 0L
                return
            }
        }
        ic.commitText(" ", 1)
        lastSpaceTime = now
        state.shift.consume()
    }

    private fun typeEnter() {
        val ic = currentInputConnection ?: return
        if (prefs.pc && state.anyCtrlAltMeta()) {
            sendCode(KeyEvent.KEYCODE_ENTER, true)
            return
        }
        val opts = editorInfo?.imeOptions ?: 0
        val action = opts and EditorInfo.IME_MASK_ACTION
        val noEnterAction = (opts and EditorInfo.IME_FLAG_NO_ENTER_ACTION) != 0
        if (!noEnterAction && action != EditorInfo.IME_ACTION_NONE && action != EditorInfo.IME_ACTION_UNSPECIFIED) {
            ic.performEditorAction(action)
        } else {
            sendCode(KeyEvent.KEYCODE_ENTER, false)
        }
    }

    /** Sends a down+up KeyEvent with an explicit meta state. */
    private fun sendKey(code: Int, meta: Int) {
        val ic = currentInputConnection ?: return
        val t = SystemClock.uptimeMillis()
        val flags = KeyEvent.FLAG_SOFT_KEYBOARD or KeyEvent.FLAG_KEEP_TOUCH_MODE
        ic.sendKeyEvent(KeyEvent(t, t, KeyEvent.ACTION_DOWN, code, 0, meta, KeyCharacterMap.VIRTUAL_KEYBOARD, 0, flags))
        ic.sendKeyEvent(KeyEvent(t, t, KeyEvent.ACTION_UP, code, 0, meta, KeyCharacterMap.VIRTUAL_KEYBOARD, 0, flags))
    }

    /** With [withMods] the active Shift/Ctrl/Alt/Win state is attached and then consumed. */
    private fun sendCode(code: Int, withMods: Boolean) {
        sendKey(code, if (withMods) state.metaState() else 0)
        if (withMods) state.consumeMods()
    }

    private fun switchKeyboard() {
        val imm = getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager
        @Suppress("DEPRECATION")
        val switched = if (Build.VERSION.SDK_INT >= 28) {
            switchToNextInputMethod(false)
        } else {
            imm.switchToNextInputMethod(window.window?.attributes?.token, false)
        }
        if (!switched) imm.showInputMethodPicker()
    }

    private fun openSettings() {
        val i = Intent(this, SettingsActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        startActivity(i)
        requestHideSelf(0)
    }

    private companion object {
        const val CTRL_META = KeyEvent.META_CTRL_ON or KeyEvent.META_CTRL_LEFT_ON
    }
}
