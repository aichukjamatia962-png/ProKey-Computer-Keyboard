package com.prokey.computerkeyboard

import android.content.Context
import android.content.SharedPreferences
import androidx.preference.PreferenceManager

/** Thin wrapper over the app's default SharedPreferences. Defaults match res/xml/preferences.xml. */
class Prefs(context: Context) {
    private val appContext = context.applicationContext
    val sp: SharedPreferences = PreferenceManager.getDefaultSharedPreferences(context)

    // Recent emojis live in their own file so saving one does not trigger a keyboard rebuild.
    private val recents: SharedPreferences = appContext.getSharedPreferences("recents", Context.MODE_PRIVATE)

    var layoutMode: String
        get() = sp.getString(LAYOUT, "mobile") ?: "mobile"
        set(v) = sp.edit().putString(LAYOUT, v).apply()

    val pc: Boolean get() = layoutMode == "pc"
    val numberRow: Boolean get() = sp.getBoolean(NUMBER_ROW, true)
    var functionRow: Boolean
        get() = sp.getBoolean(FUNCTION_ROW, true)
        set(v) = sp.edit().putBoolean(FUNCTION_ROW, v).apply()
    val numpad: Boolean get() = sp.getBoolean(NUMPAD, false)
    val toolbar: Boolean get() = sp.getBoolean(TOOLBAR, true)
    val pcQuickbar: Boolean get() = sp.getBoolean(PC_QUICKBAR, false)
    val autoCap: Boolean get() = sp.getBoolean(AUTO_CAP, true)
    val doubleSpace: Boolean get() = sp.getBoolean(DOUBLE_SPACE, true)
    val theme: String get() = sp.getString(THEME, DEFAULT_THEME) ?: DEFAULT_THEME
    val heightPct: Int get() = sp.getInt(HEIGHT, 100)
    val gap: Int get() = sp.getInt(GAP, 3)
    val radius: Int get() = sp.getInt(RADIUS, 8)
    val keyPreview: Boolean get() = sp.getBoolean(KEY_PREVIEW, true)
    val soundOn: Boolean get() = sp.getBoolean(SOUND_ON, false)
    val soundVolume: Int get() = sp.getInt(SOUND_VOLUME, 50)
    val vibrateOn: Boolean get() = sp.getBoolean(VIBRATE_ON, true)
    val vibrateLevel: Int get() = sp.getInt(VIBRATE_LEVEL, 50)
    var clipEnabled: Boolean
        get() = sp.getBoolean(CLIP_ENABLED, false)
        set(v) = sp.edit().putBoolean(CLIP_ENABLED, v).apply()
    val clipMax: Int get() = sp.getInt(CLIP_MAX, 20)

    val suggestWords: Boolean get() = sp.getBoolean(SUGGEST_WORDS, true)
    val autoCorrect: Boolean get() = sp.getBoolean(AUTO_CORRECT, true)
    val nextWord: Boolean get() = sp.getBoolean(NEXT_WORD, true)
    val learnWords: Boolean get() = sp.getBoolean(LEARN_WORDS, true)

    /** Enabled typing languages in a fixed order; English is used if nothing valid is selected. */
    fun enabledLangs(): List<String> {
        val set = sp.getStringSet(LANGS, setOf("en")) ?: setOf("en")
        val ordered = ALL_LANGS.filter { it in set }
        return if (ordered.isEmpty()) listOf("en") else ordered
    }

    var currentLang: String
        get() = sp.getString(CURRENT_LANG, "en") ?: "en"
        set(v) = sp.edit().putString(CURRENT_LANG, v).apply()

    fun activeLang(): String = enabledLangs().let { if (currentLang in it) currentLang else it.first() }

    fun bumpThemeRev() = sp.edit().putInt(THEME_REV, sp.getInt(THEME_REV, 0) + 1).apply()
    fun bumpDictRev() = sp.edit().putInt(DICT_REV, sp.getInt(DICT_REV, 0) + 1).apply()

    fun emojiRecent(): List<String> =
        (recents.getString("emoji", "") ?: "").split(" ").filter { it.isNotEmpty() }

    fun addEmojiRecent(e: String) {
        val list = emojiRecent().toMutableList()
        list.remove(e)
        list.add(0, e)
        recents.edit().putString("emoji", list.take(24).joinToString(" ")).apply()
    }

    fun clearEmojiRecent() {
        recents.edit().clear().apply()
    }

    companion object {
        const val DEFAULT_THEME = "gold_premium"
        const val LAYOUT = "layout_mode"
        const val NUMBER_ROW = "number_row"
        const val FUNCTION_ROW = "function_row"
        const val NUMPAD = "numeric_keypad"
        const val TOOLBAR = "mobile_toolbar"
        const val PC_QUICKBAR = "pc_quickbar"
        const val AUTO_CAP = "auto_cap"
        const val DOUBLE_SPACE = "double_space"
        const val THEME = "theme"
        const val HEIGHT = "key_height"
        const val GAP = "key_gap"
        const val RADIUS = "key_radius"
        const val KEY_PREVIEW = "key_preview"
        const val SOUND_ON = "sound_on"
        const val SOUND_VOLUME = "sound_volume"
        const val VIBRATE_ON = "vibrate_on"
        const val VIBRATE_LEVEL = "vibrate_level"
        const val CLIP_ENABLED = "clipboard_enabled"
        const val CLIP_MAX = "clipboard_max"
        const val SUGGEST_WORDS = "suggest_words"
        const val AUTO_CORRECT = "auto_correct"
        const val NEXT_WORD = "next_word"
        const val LEARN_WORDS = "learn_words"
        const val LANGS = "languages"
        const val CURRENT_LANG = "current_language"
        const val THEME_REV = "theme_rev"
        const val DICT_REV = "dict_rev"
        val ALL_LANGS = listOf("en", "hi_tr", "hi_in")
    }
}
