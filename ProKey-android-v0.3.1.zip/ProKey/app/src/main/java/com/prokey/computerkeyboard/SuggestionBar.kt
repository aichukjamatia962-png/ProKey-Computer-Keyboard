package com.prokey.computerkeyboard

import android.content.Context
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.text.TextUtils
import android.view.Gravity
import android.view.ViewGroup
import android.widget.LinearLayout
import android.widget.TextView

/** Up to four tappable suggestion chips above the keyboard. */
class SuggestionBar(context: Context, private val onPick: (Int) -> Unit) : LinearLayout(context) {

    private val dp = resources.displayMetrics.density
    private val slots = Array(4) { TextView(context) }
    private var theme: KbTheme = Themes.all[0]
    private var highlight = -1

    init {
        orientation = HORIZONTAL
        setPadding((4 * dp).toInt(), (3 * dp).toInt(), (4 * dp).toInt(), (3 * dp).toInt())
        for ((i, s) in slots.withIndex()) {
            s.gravity = Gravity.CENTER
            s.textSize = 16f
            s.maxLines = 1
            s.ellipsize = TextUtils.TruncateAt.END
            s.setPadding((4 * dp).toInt(), 0, (4 * dp).toInt(), 0)
            s.setOnClickListener { onPick(i) }
            val lp = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, 1f)
            lp.setMargins((2 * dp).toInt(), 0, (2 * dp).toInt(), 0)
            addView(s, lp)
        }
    }

    fun applyTheme(t: KbTheme) {
        theme = t
        setBackgroundColor(t.bg)
        styleSlots()
    }

    private fun styleSlots() {
        for ((i, s) in slots.withIndex()) {
            val bg = GradientDrawable()
            bg.cornerRadius = 8f * dp
            bg.setColor(theme.key or 0xFF000000.toInt())
            s.background = bg
            s.setTextColor(if (i == highlight) theme.accent else theme.text)
            s.setTypeface(null, if (i == highlight) Typeface.BOLD else Typeface.NORMAL)
        }
    }

    fun show(items: List<String>, highlightIndex: Int) {
        highlight = highlightIndex
        styleSlots()
        for ((i, s) in slots.withIndex()) {
            if (i < items.size) {
                s.text = items[i]
                s.visibility = VISIBLE
            } else {
                s.text = ""
                s.visibility = GONE
            }
        }
    }
}
