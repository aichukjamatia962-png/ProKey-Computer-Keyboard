package com.prokey.computerkeyboard

import android.graphics.RectF
import android.view.KeyEvent as KE

enum class KeyType {
    CHAR, SPACE, ENTER, BACKSPACE, SHIFT, CAPS, CTRL, ALT, META, FN,
    CODE, SYMBOLS, SYMBOL_PAGE, MODE, GLOBE, SETTINGS, TOOL, SPACER
}

enum class Icon { NONE, SHIFT, BACKSPACE, ENTER }

enum class Tool { EMOJI, CLIPBOARD, UNDO, REDO, MIC, CUT, COPY, PASTE, SELECT_ALL, NEXT_IME }

class Key(
    val type: KeyType,
    val label: String = "",
    val weight: Float = 1f,
    val text: String = "",
    val shiftText: String? = null,
    val keyCode: Int = KE.KEYCODE_UNKNOWN,
    val icon: Icon = Icon.NONE,
    val repeat: Boolean = false,
    /** Long-press popup characters (mobile mode only). */
    val alts: List<String>? = null,
    val tool: Tool? = null,
    /** Display text for the Shift symbol when it differs from [shiftText] (e.g. a combining mark with a placeholder). */
    val shiftLabel: String? = null,
    /** Always show the Shift symbol as a corner hint (Hindi layout). */
    val forceHint: Boolean = false,
    /** Action fired by a long press on keys that have no popup characters. */
    val longTool: Tool? = null,
) {
    /** Filled in by KeyboardView when the layout is measured. */
    val rect = RectF()
    val isLetter: Boolean get() = type == KeyType.CHAR && text.length == 1 && text[0].isLetter()

    /** Number/punctuation keys that show their Shift symbol as a small corner hint (PC mode). */
    val hasHint: Boolean get() = type == KeyType.CHAR && shiftText != null && (forceHint || !isLetter)
}

/** Long-press popup characters. */
object Alts {
    private val map: Map<String, List<String>> = mapOf(
        "$" to listOf("₹", "€", "£", "¥", "¢", "₿"),
        "-" to listOf("\u2013", "\u2014", "_"),
        "." to listOf("\u2026", "?", "!", ",", ":", ";", "/", "@"),
        "0" to listOf("°", "∅"),
        "=" to listOf("≠", "≈", "≤", "≥"),
        "*" to listOf("×", "•", "★"),
        "/" to listOf("÷", "\\"),
        "'" to listOf("`", "~", "‘", "’"),
        "\"" to listOf("“", "”", "„", "«", "»"),
        "a" to listOf("à", "á", "â", "ä", "æ", "ã", "å", "ā"),
        "c" to listOf("ç", "ć", "č"),
        "e" to listOf("è", "é", "ê", "ë", "ē", "ę"),
        "i" to listOf("ì", "í", "î", "ï", "ī"),
        "l" to listOf("ł"),
        "n" to listOf("ñ", "ń"),
        "o" to listOf("ò", "ó", "ô", "ö", "œ", "õ", "ø", "ō"),
        "s" to listOf("ß", "ś", "š"),
        "u" to listOf("ù", "ú", "û", "ü", "ū"),
        "y" to listOf("ý", "ÿ"),
        "z" to listOf("ž", "ź", "ż"),
    )

    fun of(t: String): List<String>? = map[t]

    /** Popup characters follow Shift for letter keys. */
    fun cased(key: Key, s: String, shiftOn: Boolean): String =
        if (shiftOn && key.isLetter) (if (s == "ß") "\u1E9E" else s.uppercase()) else s
}

/** Pure layout definitions. Every call returns fresh Key objects (they carry their own screen rect). */
object Layouts {

    // ---- builders ---------------------------------------------------------------------------

    private fun ch(t: String, shift: String? = null, code: Int = KE.KEYCODE_UNKNOWN, w: Float = 1f, alts: List<String>? = null) =
        Key(KeyType.CHAR, t, w, t, shift, code, alts = alts)

    /** Mobile-mode character key with its long-press popup. */
    private fun mch(t: String, code: Int = KE.KEYCODE_UNKNOWN, w: Float = 1f) = ch(t, null, code, w, Alts.of(t))

    private fun letter(c: Char, withAlts: Boolean, w: Float = 1f) =
        ch(c.toString(), c.uppercaseChar().toString(), KE.KEYCODE_A + (c - 'a'), w, if (withAlts) Alts.of(c.toString()) else null)

    private fun letters(s: String, withAlts: Boolean = false, w: Float = 1f) = s.map { letter(it, withAlts, w) }

    private fun code(label: String, keyCode: Int, w: Float = 1f, repeat: Boolean = false) =
        Key(KeyType.CODE, label, w, keyCode = keyCode, repeat = repeat)

    private fun spacer(w: Float) = Key(KeyType.SPACER, weight = w)

    private fun special(type: KeyType, label: String = "", w: Float = 1f, icon: Icon = Icon.NONE, repeat: Boolean = false) =
        Key(type, label, w, icon = icon, repeat = repeat)

    private fun tool(label: String, t: Tool, w: Float = 1f) = Key(KeyType.TOOL, label, w, tool = t)

    private fun space(w: Float, label: String = "") = Key(KeyType.SPACE, label, w, " ", null, KE.KEYCODE_SPACE)

    private fun digits() = "1234567890".map { mch(it.toString(), KE.KEYCODE_0 + (it - '0')) }

    // ---- mobile -----------------------------------------------------------------------------

    private fun decorate(s: String): String {
        if (s.isEmpty()) return s
        val t = Character.getType(s[0])
        return if (t == Character.NON_SPACING_MARK.toInt() || t == Character.COMBINING_SPACING_MARK.toInt()) "\u25CC" + s else s
    }

    /** Hindi (InScript) key: base character, Shift character shown as a corner hint. */
    private fun hch(base: String, shift: String, code: Int = KE.KEYCODE_UNKNOWN, w: Float = 1f) =
        Key(KeyType.CHAR, decorate(base), w, base, shift, code, shiftLabel = decorate(shift), forceHint = true)

    private fun mobileToolbar() = listOf(
        tool("\uD83D\uDE00", Tool.EMOJI),      // emoji panel
        tool("\uD83D\uDCCB", Tool.CLIPBOARD),  // clipboard history
        tool("\u21A9", Tool.UNDO),
        tool("\u21AA", Tool.REDO),
        tool("\uD83C\uDFA4", Tool.MIC),        // voice typing
    )

    private fun mobileBottom(symLabel: String, spaceLabel: String, multiLang: Boolean, hindi: Boolean) = listOf(
        special(KeyType.SYMBOLS, symLabel, 1.2f),
        Key(KeyType.GLOBE, "\uD83C\uDF10", 0.9f, longTool = if (multiLang) Tool.NEXT_IME else null),
        special(KeyType.SETTINGS, "\u2699", 0.9f),
        if (hindi) hch(",", "\u0937", KE.KEYCODE_COMMA, 0.8f) else ch(",", null, KE.KEYCODE_COMMA, 0.8f),
        space(3.0f, spaceLabel),
        if (hindi) hch(".", "\u0964", KE.KEYCODE_PERIOD, 0.8f) else mch(".", KE.KEYCODE_PERIOD, 0.8f),
        special(KeyType.MODE, "PC", 1.0f),
        special(KeyType.ENTER, "", 1.4f, Icon.ENTER),
    )

    fun mobile(numberRow: Boolean, toolbar: Boolean, spaceLabel: String, multiLang: Boolean): List<List<Key>> {
        val rows = ArrayList<List<Key>>()
        if (toolbar) rows.add(mobileToolbar())
        if (numberRow) rows.add(digits())
        rows.add(letters("qwertyuiop", true))
        rows.add(listOf(spacer(0.5f)) + letters("asdfghjkl", true) + spacer(0.5f))
        rows.add(
            listOf(special(KeyType.SHIFT, "", 1.5f, Icon.SHIFT)) + letters("zxcvbnm", true) +
                special(KeyType.BACKSPACE, "", 1.5f, Icon.BACKSPACE, true)
        )
        rows.add(mobileBottom("?123", spaceLabel, multiLang, false))
        return rows
    }

    fun symbols(page: Int, toolbar: Boolean, spaceLabel: String, multiLang: Boolean): List<List<Key>> {
        val rows = ArrayList<List<Key>>()
        if (toolbar) rows.add(mobileToolbar())
        if (page == 0) {
            rows.add(digits())
            rows.add(listOf("@", "#", "$", "_", "&", "-", "+", "(", ")", "/").map { mch(it) })
            rows.add(
                listOf(special(KeyType.SYMBOL_PAGE, "1/2", 1.5f)) +
                    listOf("*", "\"", "'", ":", ";", "!", "?").map { mch(it) } +
                    special(KeyType.BACKSPACE, "", 1.5f, Icon.BACKSPACE, true)
            )
        } else {
            rows.add(listOf("[", "]", "{", "}", "<", ">", "=", "^", "\\", "|").map { mch(it) })
            rows.add(listOf("\u00D7", "\u00F7", "\u00B1", "\u2260", "\u2248", "\u2264", "\u2265", "\u221A", "\u03C0", "\u2205").map { mch(it) })
            rows.add(listOf("\u2022", "\u2026", "\u2014", "\u2013", "\u00A9", "\u00AE", "\u2122", "\u00A7", "\u00B6", "\u2605").map { mch(it) })
            rows.add(
                listOf(special(KeyType.SYMBOL_PAGE, "2/2", 1.5f)) +
                    listOf("\u20B9", "\u00A3", "\u20AC", "\u00A5", "\u00A2", "\u00B0", "%").map { mch(it) } +
                    special(KeyType.BACKSPACE, "", 1.5f, Icon.BACKSPACE, true)
            )
        }
        rows.add(mobileBottom("ABC", spaceLabel, multiLang, false))
        return rows
    }

    private fun hrow(spec: List<Triple<String, String, String>>) = spec.map { (k, b, s) ->
        val code = when (k) {
            "[" -> KE.KEYCODE_LEFT_BRACKET
            "]" -> KE.KEYCODE_RIGHT_BRACKET
            ";" -> KE.KEYCODE_SEMICOLON
            "'" -> KE.KEYCODE_APOSTROPHE
            "/" -> KE.KEYCODE_SLASH
            "\\" -> KE.KEYCODE_BACKSLASH
            else -> KE.KEYCODE_A + (k[0] - 'a')
        }
        hch(b, s, code)
    }

    /** Hindi InScript layout (Devanagari). */
    fun hindi(toolbar: Boolean, spaceLabel: String, multiLang: Boolean): List<List<Key>> {
        val rows = ArrayList<List<Key>>()
        if (toolbar) rows.add(mobileToolbar())
        val dig = "\u0967\u0968\u0969\u096A\u096B\u096C\u096D\u096E\u096F\u0966"
        val digShift = listOf("\u090D", "\u0945", "\u094D\u0930", "\u0930\u094D", "\u091C\u094D\u091E", "\u0924\u094D\u0930", "\u0915\u094D\u0937", "\u0936\u094D\u0930", "(", ")")
        rows.add(
            dig.mapIndexed { i, d -> hch(d.toString(), digShift[i], KE.KEYCODE_0 + ((i + 1) % 10)) } +
                hch("-", "\u0903", KE.KEYCODE_MINUS) + hch("\u0943", "\u090B", KE.KEYCODE_EQUALS)
        )
        rows.add(hrow(listOf(
            Triple("q", "\u094C", "\u0914"), Triple("w", "\u0948", "\u0910"), Triple("e", "\u093E", "\u0906"),
            Triple("r", "\u0940", "\u0908"), Triple("t", "\u0942", "\u090A"), Triple("y", "\u092C", "\u092D"),
            Triple("u", "\u0939", "\u0919"), Triple("i", "\u0917", "\u0918"), Triple("o", "\u0926", "\u0927"),
            Triple("p", "\u091C", "\u091D"), Triple("[", "\u0921", "\u0922"), Triple("]", "\u093C", "\u091E"),
        )))
        rows.add(
            listOf(spacer(0.5f)) + hrow(listOf(
                Triple("a", "\u094B", "\u0913"), Triple("s", "\u0947", "\u090F"), Triple("d", "\u094D", "\u0905"),
                Triple("f", "\u093F", "\u0907"), Triple("g", "\u0941", "\u0909"), Triple("h", "\u092A", "\u092B"),
                Triple("j", "\u0930", "\u0931"), Triple("k", "\u0915", "\u0916"), Triple("l", "\u0924", "\u0925"),
                Triple(";", "\u091A", "\u091B"), Triple("'", "\u091F", "\u0920"),
            )) + spacer(0.5f)
        )
        rows.add(
            listOf(special(KeyType.SHIFT, "", 1.5f, Icon.SHIFT)) + hrow(listOf(
                Triple("z", "\u0946", "\u090E"), Triple("x", "\u0902", "\u0901"), Triple("c", "\u092E", "\u0923"),
                Triple("v", "\u0928", "\u0929"), Triple("b", "\u0935", "\u0934"), Triple("n", "\u0932", "\u0933"),
                Triple("m", "\u0938", "\u0936"), Triple("/", "\u092F", "\u092F\u093C"), Triple("\\", "\u0949", "\u0911"),
            )) + special(KeyType.BACKSPACE, "", 1.5f, Icon.BACKSPACE, true)
        )
        rows.add(mobileBottom("?123", spaceLabel, multiLang, true))
        return rows
    }

    // ---- PC ---------------------------------------------------------------------------------

    private fun pair(t: String, s: String, code: Int, w: Float = 1f) = ch(t, s, code, w)

    private fun fRow() = (1..12).map { code("F$it", KE.KEYCODE_F1 + it - 1) }

    private fun quickBarRow() = listOf(
        tool("Undo", Tool.UNDO),
        tool("Redo", Tool.REDO),
        tool("Cut", Tool.CUT),
        tool("Copy", Tool.COPY),
        tool("Paste", Tool.PASTE),
        tool("Sel All", Tool.SELECT_ALL),
    )

    private fun navRow() = listOf(
        code("Esc", KE.KEYCODE_ESCAPE),
        code("Ins", KE.KEYCODE_INSERT),
        code("Del", KE.KEYCODE_FORWARD_DEL, repeat = true),
        code("Home", KE.KEYCODE_MOVE_HOME),
        code("End", KE.KEYCODE_MOVE_END),
        code("PgUp", KE.KEYCODE_PAGE_UP, repeat = true),
        code("PgDn", KE.KEYCODE_PAGE_DOWN, repeat = true),
        code("PrtSc", KE.KEYCODE_SYSRQ),
    )

    private fun pcNumberRow(): List<Key> {
        val shifted = "!@#\$%^&*()"
        return listOf(pair("`", "~", KE.KEYCODE_GRAVE)) +
            "1234567890".mapIndexed { i, d -> pair(d.toString(), shifted[i].toString(), KE.KEYCODE_0 + (d - '0')) } +
            pair("-", "_", KE.KEYCODE_MINUS) +
            pair("=", "+", KE.KEYCODE_EQUALS) +
            special(KeyType.BACKSPACE, "", 2f, Icon.BACKSPACE, true)
    }

    private fun pcQRow() = listOf(code("Tab", KE.KEYCODE_TAB, 1.5f)) + letters("qwertyuiop") +
        pair("[", "{", KE.KEYCODE_LEFT_BRACKET) +
        pair("]", "}", KE.KEYCODE_RIGHT_BRACKET) +
        pair("\\", "|", KE.KEYCODE_BACKSLASH, 1.5f)

    private fun pcARow() = listOf(special(KeyType.CAPS, "Caps", 1.8f)) + letters("asdfghjkl") +
        pair(";", ":", KE.KEYCODE_SEMICOLON) +
        pair("'", "\"", KE.KEYCODE_APOSTROPHE) +
        special(KeyType.ENTER, "Enter", 2.2f)

    // One Shift (left). Ten keys of 1.25 + Shift 2.5 = 15, flush with the other rows.
    private fun pcZRow() = listOf(special(KeyType.SHIFT, "Shift", 2.5f)) + letters("zxcvbnm", w = 1.25f) +
        pair(",", "<", KE.KEYCODE_COMMA, 1.25f) +
        pair(".", ">", KE.KEYCODE_PERIOD, 1.25f) +
        pair("/", "?", KE.KEYCODE_SLASH, 1.25f)

    // 1.3 + 1.4 + 1.0 + 1.1 + 1.1 + 4.3 + 4 x 1.2 = 15
    private fun bottomCompact() = listOf(
        special(KeyType.MODE, "ABC", 1.3f),
        special(KeyType.CTRL, "Ctrl", 1.4f),
        special(KeyType.FN, "Fn", 1.0f),
        special(KeyType.META, "Win", 1.1f),
        special(KeyType.ALT, "Alt", 1.1f),
        space(4.3f),
        code("\u2190", KE.KEYCODE_DPAD_LEFT, 1.2f, true),
        code("\u2193", KE.KEYCODE_DPAD_DOWN, 1.2f, true),
        code("\u2191", KE.KEYCODE_DPAD_UP, 1.2f, true),
        code("\u2192", KE.KEYCODE_DPAD_RIGHT, 1.2f, true),
    )

    // 1.5 + 1.5 + 1.3 + 1.3 + 1.3 + 6.8 + 1.3 = 15
    private fun bottomFull() = listOf(
        special(KeyType.MODE, "ABC", 1.5f),
        special(KeyType.CTRL, "Ctrl", 1.5f),
        special(KeyType.FN, "Fn", 1.3f),
        special(KeyType.META, "Win", 1.3f),
        special(KeyType.ALT, "Alt", 1.3f),
        space(6.8f),
        special(KeyType.ALT, "Alt", 1.3f),
    )

    private fun cluster() = listOf(
        listOf(code("PrtSc", KE.KEYCODE_SYSRQ), spacer(1f), spacer(1f)),
        listOf(code("Ins", KE.KEYCODE_INSERT), code("Home", KE.KEYCODE_MOVE_HOME), code("PgUp", KE.KEYCODE_PAGE_UP, repeat = true)),
        listOf(code("Del", KE.KEYCODE_FORWARD_DEL, repeat = true), code("End", KE.KEYCODE_MOVE_END), code("PgDn", KE.KEYCODE_PAGE_DOWN, repeat = true)),
        listOf(spacer(3f)),
        listOf(spacer(1f), code("\u2191", KE.KEYCODE_DPAD_UP, repeat = true), spacer(1f)),
        listOf(
            code("\u2190", KE.KEYCODE_DPAD_LEFT, repeat = true),
            code("\u2193", KE.KEYCODE_DPAD_DOWN, repeat = true),
            code("\u2192", KE.KEYCODE_DPAD_RIGHT, repeat = true),
        ),
    )

    private fun numpadRows(): List<List<Key>> {
        fun n(t: String, kc: Int, w: Float = 1f) = ch(t, null, kc, w)
        fun d(c: Char) = n(c.toString(), KE.KEYCODE_NUMPAD_0 + (c - '0'))
        return listOf(
            listOf(spacer(4f)),
            listOf(n("/", KE.KEYCODE_NUMPAD_DIVIDE), n("*", KE.KEYCODE_NUMPAD_MULTIPLY), n("-", KE.KEYCODE_NUMPAD_SUBTRACT), n("+", KE.KEYCODE_NUMPAD_ADD)),
            listOf(d('7'), d('8'), d('9'), special(KeyType.BACKSPACE, "", 1f, Icon.BACKSPACE, true)),
            listOf(d('4'), d('5'), d('6'), n("=", KE.KEYCODE_NUMPAD_EQUALS)),
            listOf(d('1'), d('2'), d('3'), n(",", KE.KEYCODE_NUMPAD_COMMA)),
            listOf(n("0", KE.KEYCODE_NUMPAD_0, 2f), n(".", KE.KEYCODE_NUMPAD_DOT), special(KeyType.ENTER, "", 1f, Icon.ENTER)),
        )
    }

    /**
     * PC layout.
     * compact (portrait): optional quick-action bar, optional F1-F12 row, Esc/nav row, main block, bottom row with arrows.
     * full (landscape): optional quick-action bar, Esc+F row, main block, navigation cluster (+ optional numeric keypad).
     */
    fun pc(fnRow: Boolean, full: Boolean, numpad: Boolean, quickBar: Boolean): List<List<Key>> {
        val rows = ArrayList<List<Key>>()
        if (quickBar) rows.add(quickBarRow())
        if (!full) {
            if (fnRow) rows.add(fRow())
            rows.add(navRow())
            rows.add(pcNumberRow())
            rows.add(pcQRow())
            rows.add(pcARow())
            rows.add(pcZRow())
            rows.add(bottomCompact())
            return rows
        }
        val top = listOf(code("Esc", KE.KEYCODE_ESCAPE)) +
            (if (fnRow) fRow() else listOf(spacer(12f))) + spacer(2f)
        val main = listOf(top, pcNumberRow(), pcQRow(), pcARow(), pcZRow(), bottomFull())
        val cl = cluster()
        val pad = numpadRows()
        for (i in main.indices) {
            var row = main[i] + spacer(0.5f) + cl[i]
            if (numpad) row = row + spacer(0.5f) + pad[i]
            rows.add(row)
        }
        return rows
    }
}
