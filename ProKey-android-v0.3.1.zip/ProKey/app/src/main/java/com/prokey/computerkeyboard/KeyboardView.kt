package com.prokey.computerkeyboard

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Path
import android.graphics.Rect
import android.graphics.RectF
import android.graphics.Shader
import android.os.Handler
import android.os.Looper
import android.util.SparseArray
import android.view.MotionEvent
import android.view.View
import androidx.core.graphics.ColorUtils
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min

/**
 * Canvas-drawn keyboard. Supports multi-touch (fast two-thumb typing), key repeat, slide-to-correct,
 * spacebar-swipe cursor control, backspace-swipe word delete, long-press popups and key preview.
 * All typing logic lives in [Listener].
 */
class KeyboardView(context: Context) : View(context) {

    interface Listener {
        fun onPress(key: Key)
        fun onKey(key: Key)
        fun onAlt(key: Key, text: String)
        fun onSpaceSwipe(steps: Int)
        fun onWordDelete()
        fun onLongTool(key: Key)
    }

    data class Look(val rowHeightDp: Float, val gapDp: Float, val radiusDp: Float, val preview: Boolean)

    var listener: Listener? = null
    var state = KbState()

    private var rows: List<List<Key>> = emptyList()
    private var rowTop = FloatArray(0)
    private var rowHt = FloatArray(0)
    private var theme: KbTheme = Themes.byId(Prefs.DEFAULT_THEME)
    private var look = Look(46f, 3f, 8f, true)
    private var accentFg = Color.WHITE
    private var bgShader: Shader? = null

    private val dp = resources.displayMetrics.density
    private val uiHandler = Handler(Looper.getMainLooper())
    private val fillPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val strokePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = dp
    }
    private val textPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { textAlign = Paint.Align.CENTER }
    private val iconPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        strokeWidth = 2f * dp
        strokeJoin = Paint.Join.ROUND
        strokeCap = Paint.Cap.ROUND
    }
    private val tmp = RectF()
    private val srcRect = Rect()
    private val dstRect = Rect()
    private var bgBitmap: Bitmap? = null
    private var bgBitmapPath: String? = null
    private val tmp2 = RectF()
    private val path = Path()

    // touch tracking
    private val pressed = SparseArray<Key>()
    private var repeatPointer = -1
    private var repeatKey: Key? = null
    private var repeatFired = false
    private var spacePointer = -1
    private var spaceStartX = 0f
    private var spaceSteppedX = 0f
    private var swiping = false
    private var backPointer = -1
    private var backStartX = 0f
    private var backSteppedX = 0f
    private var backSwiping = false

    // long-press popup
    private var lpPointer = -1
    private var lpKey: Key? = null
    private var popupKey: Key? = null
    private var popupPointer = -1
    private var popupAlts: List<String> = emptyList()
    private var popupLeft = 0f
    private var popupTop = 0f
    private var popupCell = 0f
    private var popupSel = -1
    private var longDonePointer = -1

    private val repeatRunnable = object : Runnable {
        override fun run() {
            val k = repeatKey ?: return
            repeatFired = true
            listener?.onKey(k)
            uiHandler.postDelayed(this, REPEAT_INTERVAL_MS)
        }
    }
    private val longPressRunnable = Runnable { showPopup() }

    fun setup(rows: List<List<Key>>, theme: KbTheme, look: Look) {
        stopAll()
        this.rows = rows
        rowTop = FloatArray(rows.size)
        rowHt = FloatArray(rows.size)
        this.theme = theme
        this.look = look
        accentFg = if (ColorUtils.calculateLuminance(theme.accent) > 0.35) Color.BLACK else Color.WHITE
        val path = theme.bgImage
        if (path != bgBitmapPath) {
            bgBitmap?.recycle()
            bgBitmap = if (path == null) null else try { BitmapFactory.decodeFile(path) } catch (e: Exception) { null }
            bgBitmapPath = path
        }
        bgShader = null
        requestLayout()
        if (width > 0) layoutKeys()
        invalidate()
    }

    // ---- layout -----------------------------------------------------------------------------

    private fun topPad() = 4f * dp
    private fun baseRow() = look.rowHeightDp * dp

    /** Rows that contain only tool buttons (toolbar / quick-action bar) are slimmer. */
    private fun factor(row: List<Key>) =
        if (row.isNotEmpty() && row.all { it.type == KeyType.TOOL }) 0.7f else 1f

    override fun onMeasure(widthMeasureSpec: Int, heightMeasureSpec: Int) {
        var h = 2 * topPad()
        for (r in rows) h += baseRow() * factor(r)
        setMeasuredDimension(MeasureSpec.getSize(widthMeasureSpec), h.toInt())
    }

    override fun onSizeChanged(w: Int, h: Int, oldw: Int, oldh: Int) {
        super.onSizeChanged(w, h, oldw, oldh)
        bgShader = null
        layoutKeys()
    }

    private fun layoutKeys() {
        val padX = 2f * dp
        val usable = width - 2 * padX
        var y = topPad()
        for ((ri, row) in rows.withIndex()) {
            val rh = baseRow() * factor(row)
            rowTop[ri] = y
            rowHt[ri] = rh
            var total = 0f
            for (k in row) total += k.weight
            var x = padX
            for (k in row) {
                val kw = usable * k.weight / total
                k.rect.set(x, y, x + kw, y + rh)
                x += kw
            }
            y += rh
        }
    }

    // ---- drawing ----------------------------------------------------------------------------

    override fun onDraw(canvas: Canvas) {
        val end = theme.bgEnd
        if (end != null) {
            val sh = bgShader ?: LinearGradient(
                0f, 0f, width.toFloat(), height.toFloat(), theme.bg, end, Shader.TileMode.CLAMP
            ).also { bgShader = it }
            fillPaint.shader = sh
            canvas.drawRect(0f, 0f, width.toFloat(), height.toFloat(), fillPaint)
            fillPaint.shader = null
        } else {
            canvas.drawColor(theme.bg)
        }
        val bm = bgBitmap
        if (bm != null && width > 0 && height > 0) {
            val scale = max(width.toFloat() / bm.width, height.toFloat() / bm.height)
            val sw = width / scale
            val sh = height / scale
            srcRect.set(((bm.width - sw) / 2f).toInt(), ((bm.height - sh) / 2f).toInt(), ((bm.width + sw) / 2f).toInt(), ((bm.height + sh) / 2f).toInt())
            dstRect.set(0, 0, width, height)
            canvas.drawBitmap(bm, srcRect, dstRect, null)
            fillPaint.color = ColorUtils.setAlphaComponent(theme.bg, theme.imageDim * 255 / 100)
            canvas.drawRect(0f, 0f, width.toFloat(), height.toFloat(), fillPaint)
        }
        val inset = look.gapDp * dp / 2f
        val radius = look.radiusDp * dp
        for (row in rows) for (k in row) {
            if (k.type == KeyType.SPACER) continue
            tmp.set(k.rect)
            tmp.inset(inset, inset)
            drawKey(canvas, k, tmp, radius)
        }
        if (popupKey != null) {
            drawPopup(canvas, radius)
        } else if (look.preview) {
            for (i in 0 until pressed.size()) {
                val k = pressed.valueAt(i)
                if (k.type == KeyType.CHAR) drawPreview(canvas, k, radius)
            }
        }
    }

    private fun isHeld(k: Key): Boolean {
        for (i in 0 until pressed.size()) if (pressed.valueAt(i) === k) return true
        return false
    }

    private fun modOf(k: Key): ModKey? = when (k.type) {
        KeyType.SHIFT -> state.shift
        KeyType.CTRL -> state.ctrl
        KeyType.ALT -> state.alt
        KeyType.META -> state.meta
        else -> null
    }

    private fun isActive(k: Key): Boolean {
        val m = modOf(k)
        if (m != null) return m.on
        return when (k.type) {
            KeyType.CAPS -> state.caps
            KeyType.FN -> state.fnRow
            else -> false
        }
    }

    private fun labelFor(k: Key): String {
        if (k.type != KeyType.CHAR) return k.label
        val st = k.shiftText ?: return k.label
        val upper = if (k.isLetter) state.shift.on != state.caps else state.shift.on
        return if (upper) (k.shiftLabel ?: st) else k.label
    }

    private fun drawKey(c: Canvas, k: Key, r: RectF, radius: Float) {
        val held = isHeld(k)
        val accented = isActive(k) || k.type == KeyType.ENTER
        val fill = when {
            held -> theme.keyPressed
            accented -> theme.accent
            k.type == KeyType.CHAR || k.type == KeyType.SPACE -> theme.key
            else -> theme.keySpecial
        }
        fillPaint.color = if (theme.keyAlpha < 100) ColorUtils.setAlphaComponent(fill, Color.alpha(fill) * theme.keyAlpha / 100) else fill
        c.drawRoundRect(r, radius, radius, fillPaint)
        if (theme.border != 0) {
            strokePaint.color = theme.border
            c.drawRoundRect(r, radius, radius, strokePaint)
        }
        val fg = if (accented && !held) accentFg else theme.text
        if (k.icon != Icon.NONE) {
            drawIcon(c, k, r.centerX(), r.centerY(), min(r.height(), r.width()) * 0.22f, fg)
        } else if (k.hasHint) {
            // Dual-label key: main symbol centred, the Shift symbol as a small corner hint.
            val sh = k.shiftLabel ?: k.shiftText ?: ""
            val shiftOn = state.shift.on
            drawLabel(c, if (shiftOn) sh else k.label, r, fg, r.height() * 0.08f, 0.42f)
            drawHint(c, if (shiftOn) k.label else sh, r, fg)
        } else {
            val text = labelFor(k)
            val single = text.codePointCount(0, text.length) == 1
            val f = when {
                k.type == KeyType.TOOL -> if (single) 0.56f else 0.42f
                single -> 0.42f
                else -> 0.34f
            }
            drawLabel(c, text, r, fg, 0f, f)
        }
        // Locked modifiers (double-tap) get a small bar under the label.
        if (modOf(k)?.state == Mod.LOCKED) {
            tmp2.set(r.centerX() - r.width() * 0.2f, r.bottom - 5f * dp, r.centerX() + r.width() * 0.2f, r.bottom - 2.5f * dp)
            fillPaint.color = fg
            c.drawRoundRect(tmp2, 2f * dp, 2f * dp, fillPaint)
        }
    }

    private fun drawLabel(c: Canvas, text: String, r: RectF, color: Int, yOff: Float, sizeFactor: Float) {
        if (text.isEmpty()) return
        val base = r.height() * sizeFactor
        textPaint.textSize = base
        val maxW = r.width() * 0.88f
        val tw = textPaint.measureText(text)
        if (tw > maxW) textPaint.textSize = base * maxW / tw
        textPaint.color = color
        val fm = textPaint.fontMetrics
        c.drawText(text, r.centerX(), r.centerY() + yOff - (fm.ascent + fm.descent) / 2f, textPaint)
    }

    private fun drawHint(c: Canvas, text: String, r: RectF, color: Int) {
        textPaint.textSize = r.height() * 0.27f
        textPaint.color = color
        textPaint.alpha = 170
        textPaint.textAlign = Paint.Align.RIGHT
        c.drawText(text, r.right - r.width() * 0.12f, r.top + r.height() * 0.34f, textPaint)
        textPaint.textAlign = Paint.Align.CENTER
    }

    private fun drawIcon(c: Canvas, k: Key, cx: Float, cy: Float, s: Float, color: Int) {
        iconPaint.color = color
        iconPaint.style = Paint.Style.STROKE
        val p = path
        p.reset()
        when (k.icon) {
            Icon.SHIFT -> {
                p.moveTo(cx, cy - s); p.lineTo(cx + s, cy); p.lineTo(cx + s * 0.4f, cy)
                p.lineTo(cx + s * 0.4f, cy + s); p.lineTo(cx - s * 0.4f, cy + s)
                p.lineTo(cx - s * 0.4f, cy); p.lineTo(cx - s, cy); p.close()
                if (state.shift.state == Mod.LOCKED) iconPaint.style = Paint.Style.FILL_AND_STROKE
            }
            Icon.BACKSPACE -> {
                p.moveTo(cx - s * 1.3f, cy); p.lineTo(cx - s * 0.5f, cy - s * 0.9f)
                p.lineTo(cx + s * 1.2f, cy - s * 0.9f); p.lineTo(cx + s * 1.2f, cy + s * 0.9f)
                p.lineTo(cx - s * 0.5f, cy + s * 0.9f); p.close()
                p.moveTo(cx - s * 0.1f, cy - s * 0.4f); p.lineTo(cx + s * 0.7f, cy + s * 0.4f)
                p.moveTo(cx + s * 0.7f, cy - s * 0.4f); p.lineTo(cx - s * 0.1f, cy + s * 0.4f)
            }
            Icon.ENTER -> {
                p.moveTo(cx + s, cy - s * 0.8f); p.lineTo(cx + s, cy + s * 0.2f); p.lineTo(cx - s, cy + s * 0.2f)
                p.moveTo(cx - s * 0.35f, cy - s * 0.4f); p.lineTo(cx - s, cy + s * 0.2f); p.lineTo(cx - s * 0.35f, cy + s * 0.8f)
            }
            Icon.NONE -> return
        }
        c.drawPath(p, iconPaint)
    }

    /** Key preview: a bubble above the pressed key with a gold (theme accent) border. */
    private fun drawPreview(c: Canvas, k: Key, radius: Float) {
        val label = labelFor(k)
        val bw = max(k.rect.width() * 1.4f, 44f * dp)
        val bh = baseRow() * 1.1f
        var left = k.rect.centerX() - bw / 2f
        left = left.coerceIn(2f * dp, max(2f * dp, width - 2f * dp - bw))
        val top = max(0f, k.rect.top - bh - 2f * dp)
        tmp.set(left, top, left + bw, top + bh)
        fillPaint.color = theme.bg
        c.drawRoundRect(tmp, radius * 1.3f, radius * 1.3f, fillPaint)
        fillPaint.color = theme.key
        c.drawRoundRect(tmp, radius * 1.3f, radius * 1.3f, fillPaint)
        val old = strokePaint.strokeWidth
        strokePaint.strokeWidth = 2f * dp
        strokePaint.color = theme.accent
        c.drawRoundRect(tmp, radius * 1.3f, radius * 1.3f, strokePaint)
        strokePaint.strokeWidth = old
        drawLabel(c, label, tmp, theme.text, 0f, 0.55f)
    }

    private fun drawPopup(c: Canvas, radius: Float) {
        val k = popupKey ?: return
        val n = popupAlts.size
        val h = baseRow() * 1.05f
        tmp.set(popupLeft, popupTop, popupLeft + popupCell * n, popupTop + h)
        fillPaint.color = theme.bg
        c.drawRoundRect(tmp, radius * 1.3f, radius * 1.3f, fillPaint)
        fillPaint.color = theme.key
        c.drawRoundRect(tmp, radius * 1.3f, radius * 1.3f, fillPaint)
        val old = strokePaint.strokeWidth
        strokePaint.strokeWidth = 2f * dp
        strokePaint.color = theme.accent
        c.drawRoundRect(tmp, radius * 1.3f, radius * 1.3f, strokePaint)
        strokePaint.strokeWidth = old
        for (i in 0 until n) {
            tmp2.set(popupLeft + i * popupCell, popupTop, popupLeft + (i + 1) * popupCell, popupTop + h)
            tmp2.inset(2f * dp, 2f * dp)
            val sel = i == popupSel
            if (sel) {
                fillPaint.color = theme.accent
                c.drawRoundRect(tmp2, radius, radius, fillPaint)
            }
            drawLabel(c, Alts.cased(k, popupAlts[i], state.shift.on), tmp2, if (sel) accentFg else theme.text, 0f, 0.5f)
        }
    }

    // ---- touch ------------------------------------------------------------------------------

    private fun keyAt(x: Float, y: Float): Key? {
        if (rows.isEmpty() || rowTop.size != rows.size) return null
        var idx = rows.lastIndex
        for (i in rows.indices) {
            if (y < rowTop[i] + rowHt[i]) { idx = i; break }
        }
        val row = rows[idx]
        if (row.isEmpty()) return null
        val xx = x.coerceIn(row.first().rect.left, row.last().rect.right - 0.01f)
        var i = row.indexOfFirst { xx < it.rect.right }
        if (i < 0) i = row.lastIndex
        val k = row[i]
        if (k.type != KeyType.SPACER) return k
        // Small edge spacers snap to the nearest real key; larger gaps are dead space.
        if (k.weight > 0.6f) return null
        return when (i) {
            0 -> row.getOrNull(1)
            row.lastIndex -> row.getOrNull(i - 1)
            else -> null
        }?.takeIf { it.type != KeyType.SPACER }
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN, MotionEvent.ACTION_POINTER_DOWN -> {
                val i = e.actionIndex
                down(e.getPointerId(i), e.getX(i), e.getY(i))
            }
            MotionEvent.ACTION_MOVE -> {
                for (i in 0 until e.pointerCount) move(e.getPointerId(i), e.getX(i), e.getY(i))
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_POINTER_UP -> up(e.getPointerId(e.actionIndex))
            MotionEvent.ACTION_CANCEL -> stopAll()
        }
        return true
    }

    private fun down(id: Int, x: Float, y: Float) {
        val k = keyAt(x, y) ?: return
        pressed.put(id, k)
        listener?.onPress(k)
        when (k.type) {
            KeyType.SPACE -> {
                spacePointer = id; spaceStartX = x; spaceSteppedX = x; swiping = false
            }
            KeyType.BACKSPACE -> {
                backPointer = id; backStartX = x; backSteppedX = x; backSwiping = false
            }
            else -> Unit
        }
        if (k.repeat) startRepeat(k, id)
        if ((k.alts != null || k.longTool != null) && lpPointer == -1 && popupKey == null) startLongPress(k, id)
        invalidate()
    }

    private fun move(id: Int, x: Float, y: Float) {
        val k = pressed.get(id) ?: return
        if (popupKey != null && id == popupPointer) {
            val total = popupCell * popupAlts.size
            val sel = if (x >= popupLeft && x < popupLeft + total) ((x - popupLeft) / popupCell).toInt() else -1
            if (sel != popupSel) { popupSel = sel; invalidate() }
            return
        }
        if (id == spacePointer) {
            val step = SPACE_STEP_DP * dp
            if (!swiping && abs(x - spaceStartX) > step) swiping = true
            if (swiping) {
                val n = ((x - spaceSteppedX) / step).toInt()
                if (n != 0) {
                    listener?.onSpaceSwipe(n)
                    spaceSteppedX += n * step
                }
            }
            return
        }
        if (id == backPointer) {
            if (!backSwiping && backStartX - x > BACK_SWIPE_START_DP * dp) {
                backSwiping = true
                if (id == repeatPointer) stopRepeat()
                listener?.onWordDelete()
                backSteppedX = x
            } else if (backSwiping) {
                if (x > backSteppedX) backSteppedX = x
                val step = BACK_SWIPE_STEP_DP * dp
                val n = ((backSteppedX - x) / step).toInt()
                if (n > 0) {
                    repeat(n) { listener?.onWordDelete() }
                    backSteppedX -= n * step
                }
            }
            return
        }
        val nk = keyAt(x, y)
        if (nk != null && nk !== k) {
            if (id == lpPointer) cancelLongPress()
            if (id == repeatPointer) stopRepeat()
            pressed.put(id, nk)
            listener?.onPress(nk)
            if (nk.repeat) startRepeat(nk, id)
            if ((nk.alts != null || nk.longTool != null) && lpPointer == -1 && popupKey == null) startLongPress(nk, id)
            invalidate()
        }
    }

    private fun up(id: Int) {
        val k = pressed.get(id) ?: return
        pressed.remove(id)
        if (id == longDonePointer) {
            longDonePointer = -1
            invalidate()
            return
        }
        if (popupKey != null && id == popupPointer) {
            val sel = popupSel
            val alts = popupAlts
            closePopup()
            if (sel in alts.indices) listener?.onAlt(k, alts[sel])
            invalidate()
            return
        }
        if (id == lpPointer) cancelLongPress()
        when {
            id == backPointer -> {
                val swiped = backSwiping
                val fired = id == repeatPointer && repeatFired
                backPointer = -1
                backSwiping = false
                if (id == repeatPointer) stopRepeat()
                if (!swiped && !fired) listener?.onKey(k)
            }
            id == repeatPointer -> {
                val fired = repeatFired
                stopRepeat()
                if (!fired) listener?.onKey(k)
            }
            id == spacePointer -> {
                val wasSwiping = swiping
                spacePointer = -1
                swiping = false
                if (!wasSwiping) listener?.onKey(k)
            }
            else -> listener?.onKey(k)
        }
        invalidate()
    }

    // ---- long-press popup -------------------------------------------------------------------

    private fun startLongPress(k: Key, id: Int) {
        cancelLongPress()
        lpKey = k
        lpPointer = id
        uiHandler.postDelayed(longPressRunnable, LONG_PRESS_MS)
    }

    private fun cancelLongPress() {
        uiHandler.removeCallbacks(longPressRunnable)
        lpKey = null
        lpPointer = -1
    }

    private fun showPopup() {
        val k = lpKey ?: return
        if (lpPointer < 0) return
        val alts = k.alts
        if (alts == null) {
            // Key with a long-press action instead of popup characters.
            longDonePointer = lpPointer
            lpKey = null
            lpPointer = -1
            listener?.onLongTool(k)
            return
        }
        val n = alts.size
        var cell = max(k.rect.width(), 40f * dp)
        if (cell * n > width - 4f * dp) cell = (width - 4f * dp) / n
        var left = k.rect.centerX() - cell / 2f
        if (left + cell * n > width - 2f * dp) left = width - 2f * dp - cell * n
        if (left < 2f * dp) left = 2f * dp
        val h = baseRow() * 1.05f
        var top = k.rect.top - h - 2f * dp
        if (top < 0f) top = k.rect.top // top row: the popup overlays the key's own row
        popupKey = k
        popupPointer = lpPointer
        popupAlts = alts
        popupLeft = left
        popupTop = top
        popupCell = cell
        popupSel = 0
        lpKey = null
        lpPointer = -1
        invalidate()
    }

    private fun closePopup() {
        popupKey = null
        popupPointer = -1
        popupSel = -1
        cancelLongPress()
    }

    // ---- repeat / reset ---------------------------------------------------------------------

    private fun startRepeat(k: Key, id: Int) {
        stopRepeat()
        repeatKey = k
        repeatPointer = id
        repeatFired = false
        uiHandler.postDelayed(repeatRunnable, REPEAT_DELAY_MS)
    }

    private fun stopRepeat() {
        uiHandler.removeCallbacks(repeatRunnable)
        repeatKey = null
        repeatPointer = -1
        repeatFired = false
    }

    private fun stopAll() {
        pressed.clear()
        stopRepeat()
        closePopup()
        spacePointer = -1
        swiping = false
        backPointer = -1
        backSwiping = false
        longDonePointer = -1
        invalidate()
    }

    override fun onDetachedFromWindow() {
        stopAll()
        super.onDetachedFromWindow()
    }

    override fun onWindowVisibilityChanged(visibility: Int) {
        super.onWindowVisibilityChanged(visibility)
        if (visibility != VISIBLE) stopAll()
    }

    private companion object {
        const val REPEAT_DELAY_MS = 400L
        const val REPEAT_INTERVAL_MS = 50L
        const val LONG_PRESS_MS = 380L
        const val SPACE_STEP_DP = 14f
        const val BACK_SWIPE_START_DP = 24f
        const val BACK_SWIPE_STEP_DP = 32f
    }
}
