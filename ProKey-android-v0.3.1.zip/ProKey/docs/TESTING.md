# Manual test checklist (core build)

Run on at least one OPPO/ColorOS phone, one other brand, and one emulator. Tick each when verified.

Activation
- [ ] Enable ProKey in Android keyboard list; select it from the picker
- [ ] Main screen status text updates (not enabled / not selected / ready)
- [ ] Globe key switches to the next keyboard; settings key opens ProKey settings

Mobile mode (try Notes, a browser address bar, a chat app, a multi-line field)
- [ ] Every letter a-z and A-Z; every digit; every symbol on both `?123` pages
- [ ] Shift one-shot, double-tap caps lock, auto-capitalization at sentence start
- [ ] Backspace (tap and hold), Enter (newline vs Go/Search/Send), Space, double-space period
- [ ] Spacebar swipe moves the cursor; fast two-thumb typing drops no keys
- [ ] Number/phone fields open on the symbols page; password fields type correctly

PC mode
- [ ] Every key in compact (portrait) and full (landscape) layouts, with and without function row and numpad
- [ ] Ctrl+A/C/X/V, Ctrl+Z, Shift+arrows selection, Alt/Win flags in a terminal-type app
- [ ] F1-F12, Esc, Tab, Home, End, PgUp, PgDn, Ins, Del, arrows (note which apps react)
- [ ] Caps Lock, Fn toggle, ABC/PC switch

Settings and look
- [ ] All 15 themes readable (text vs key contrast), in portrait and landscape
- [ ] Height, spacing, radius sliders update the open keyboard live
- [ ] Key sound (with system touch sounds on), volume, vibration on/off and intensity
- [ ] Rotation while the keyboard is open

Release
- [ ] Install over an older build (upgrade), signature verifies, no INTERNET permission in the APK manifest

## v0.2.0 additions

Symbols and popups
- [ ] Symbols page 2/2 shows ₹ £ € ¥ ¢ ° % in the bottom row; math, punctuation and legal rows insert correctly
- [ ] Long-press `$ - . 0 = * /` `'` `"` and accented letters: popup appears, slide to choose, release inserts; release outside cancels; popups follow Shift
- [ ] Popup on top-row keys (number row off, toolbar off) is visible and usable

Toolbar, panels, voice
- [ ] Emoji panel: tabs, insert, recents, ABC back, backspace hold-repeat; flags and newer emojis render on your phone
- [ ] Clipboard: off by default; turn on, copy text in another app, it appears; tap to paste, pin, delete, Clear (keeps pinned); nothing saved from a password field
- [ ] Undo/Redo in a notes app and in a browser text box (editor action or Ctrl+Z/Y fallback)
- [ ] Mic: speech screen opens, text is typed after it closes; behaves on a phone without Google speech services

Typing feel
- [ ] Backspace swipe left deletes words (and a selection); normal backspace tap/hold still works
- [ ] Key preview shows with gold border; toggle it off in settings
- [ ] Spacebar swipe, auto-cap, double-space period unchanged

PC mode
- [ ] Corner hints on number/punctuation keys; they swap when Shift is active
- [ ] Tap Ctrl then C copies (gold highlight, resets after); double-tap Shift/Ctrl locks (bar shown), tap again unlocks
- [ ] Right Ctrl before the arrows works; quick-action bar buttons (turn it on in settings) work or fall back as documented

## v0.3.0 additions

Suggestions and autocorrect (use a normal text field, e.g. Notes)
- [ ] Suggestion bar appears after the word list loads; hidden in password, number, URL and e-mail fields
- [ ] Typing "teh " becomes "the "; backspace right after restores "teh" and it is not corrected again
- [ ] "dont", "im", "i" are fixed to "don't", "I'm", "I"; names and ALL-CAPS words are left alone
- [ ] Tapping a suggestion replaces the current word and adds a space; the next-word bar appears after a space
- [ ] Learn: type a made-up word twice, it stops being corrected and shows in Personal dictionary; delete it there; "Clear everything" works
- [ ] Nothing is learned in a password field or with Learn new words off
- [ ] Low-end phone: no typing lag while the word list loads or while suggestions refresh

Hindi
- [ ] Enable Hindi languages in settings; globe tap switches, long-press opens the keyboard picker; spacebar shows the language name
- [ ] Hinglish: kya, hindi, namaste, dhanyavad, mera, bharat give sensible options; space converts; backspace reverts
- [ ] InScript: check every key against a reference InScript chart; Shift symbols match the corner hints; matras and conjuncts (क्ष, ज्ञ, त्र) render
- [ ] Autocapitalization does not fire in InScript mode

Emoji search and theme editor
- [ ] Emoji search: type "love", "fire", "pizza"; results insert; close returns to the emoji panel
- [ ] Theme editor: color pickers, gradient, border, opacity, background image (large photo, portrait and landscape), Apply, Save as, Delete, Reset; keyboard updates immediately after Apply
- [ ] Saved/custom theme survives restarting the phone

## v0.3.1 PC layout

- [ ] Quick-action bar shows exactly Undo, Redo, Cut, Copy, Paste, Sel All (no Find)
- [ ] Nav row shows Esc, Ins, Del, Home, End, PgUp, PgDn, PrtSc (no Menu), in portrait; landscape bottom row has no Menu
- [ ] Only one Ctrl and one Shift anywhere; Shift on the left of the Z row, Ctrl on the left of the bottom row
- [ ] Every row ends flush at the right edge; no gaps; keys line up in portrait and landscape, with and without the F row, quick bar and numpad
- [ ] Tap Ctrl then C copies; double-tap Shift or Ctrl locks (gold with a bar)
