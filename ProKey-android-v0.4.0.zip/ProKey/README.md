# ProKey – Computer Keyboard (v0.4.0)

Native Android keyboard (InputMethodService, Kotlin). Package: `com.prokey.computerkeyboard` (keep it permanent after first release). Default look: Black & Gold.

**Status: source only. This project has NOT been compiled or run yet.** It was written without the Android SDK, Gradle or a device. Expect a few compile errors on first build, then test on real phones before trusting it. No APK exists until you build one.

## Get an APK

**Option A, GitHub (no local setup):** create a GitHub repo, push this folder, open the Actions tab. `.github/workflows/build.yml` builds the debug APK on every push and uploads it as the artifact `ProKey-debug-apk`. If the build fails, open the log and send the first errors.

**Option B, Android Studio:** open this folder, let Gradle sync, then Build > Build APK(s), or `./gradlew assembleDebug` (run `gradle wrapper` once if `gradlew` is missing). Output: `app/build/outputs/apk/debug/app-debug.apk`. If Studio offers to upgrade AGP/Gradle/Kotlin, accept; versions here are conservative (AGP 8.7.3, Kotlin 2.0.21, Gradle 8.9, compileSdk 35).

Install with `adb install -r app-debug.apk` or copy the APK to the phone. Activate: ProKey > "1. Enable ProKey" > "2. Select ProKey". ProKey never switches itself to default. No native code, so one APK runs on 32-bit and 64-bit phones.

## Release signing

```
keytool -genkeypair -v -keystore prokey-release.jks -alias prokey -keyalg RSA -keysize 2048 -validity 10000
cp keystore.properties.example keystore.properties   # then edit with your values
./gradlew assembleRelease     # app/build/outputs/apk/release/app-release.apk
./gradlew bundleRelease       # AAB, for stores that take bundles
apksigner verify --print-certs app/build/outputs/apk/release/app-release.apk
```

`keystore.properties` and `*.jks` are git-ignored. Never commit them. Back up the keystore: losing it means you cannot update the app. Without `keystore.properties` the release build is unsigned and will not install.

## v0.4.0: one-handed, split, floating

- **One-handed mode** (Settings > Layout > One-handed mode: Off / Left hand / Right hand, width 60-90%): in portrait the keys use only part of the width, on the side you choose. The free strip has two buttons: a swap arrow (left/right) and Full (back to full width). Shortcut: long-press the gear key to turn one-handed mode on (right hand) or off.
- **Split keyboard** (Settings > Layout > Split keyboard, landscape only): letters, symbols and Hindi layouts become two halves with a gap in the middle; the spacebar is split in two. The toolbar row stays whole. PC mode is not split.
- **Floating keyboard (experimental)** (Settings > Layout > Floating keyboard, width 50-90%): the keyboard becomes a smaller window you drag by the handle on top; touches outside it go to the app, and the app is not pushed up. Tap Dock on the handle to return. It uses Android's input-method insets API and has not been tested on any device. If it misbehaves, open the ProKey app > Keyboard settings and turn Floating off. It is ignored in PC mode.
- One-handed mode is ignored in landscape and while floating.

## v0.3.3

See docs/KEY_STATUS.md for which keys work where. New: Symbols panel (Omega button in the toolbar), Tab in the toolbar, long-press the clipboard button for Select all / Copy / Cut / Paste, working Ins (overwrite mode), key font size slider. The toolbar is now Emoji, Clipboard, Undo, Redo, Symbols, Tab, Mic.

## Bottom row (v0.3.2)

The Emoji key (😀) now sits where the Globe key was. Tap it for the emoji panel; long-press it to switch to another keyboard (the Android keyboard switcher). The toolbar still has its own Emoji button when it is showing.

## PC layout (v0.3.1)

PC mode has one Ctrl and one Shift (both on the left, no duplicates), and no Find or Menu keys. The quick-action bar is Undo, Redo, Cut, Copy, Paste, Sel All. Rows are balanced to the same total width: the bottom Z row is Shift plus ten wider keys, the bottom row is ABC, Ctrl, Fn, Win, Alt, Spacebar and the arrow keys (landscape: Alt on both sides of the Spacebar).

## What is in v0.3.0

Suggestions and autocorrect (English)
- Suggestions appear in the toolbar row, not in a separate bar (no extra height): while you type, three suggestion buttons replace the toolbar buttons; they show completions, corrections, the word as typed, and next-word predictions after a space. The toolbar comes back after about 2.5 seconds of no typing, when the field is empty, or when there is nothing to suggest. They need the Top toolbar setting on. Plain text fields only (off in password, number, URL and e-mail fields, and where the app disables suggestions).
- Autocorrect on space/punctuation. Backspace right after a correction puts back what you typed (and stops it correcting that word again). Fixes "i" to "I" and missing apostrophes (dont, im, cant...).
- Personal dictionary: words you type twice (or pick as typed from the suggestions) are learned, plus word pairs for next-word prediction. Stored only on the phone, never in password fields or fields that ask for incognito. View, add, delete and clear in Settings > Personal dictionary. Toggle "Learn new words" off to stop learning.

Hindi
- Languages (Settings > Typing languages): English, Hindi transliteration, Hindi InScript. With more than one enabled, long-press the spacebar to switch language; the spacebar shows the language name.
- Hindi transliteration (Hinglish): type Roman letters on the normal keyboard; the suggestions show Devanagari options (kya -> क्या); space converts to the first option; backspace right after reverts to what you typed. Common words come from a bundled list of about 300 Hinglish words, everything else from spelling rules, so expect to pick another option sometimes.
- Hindi InScript layout: standard InScript letters with the Shift symbol shown in each key's corner. No suggestions in InScript mode.

Emoji search: tap the magnifier in the emoji panel, type on the keyboard, tap a result. Covers 268 common emojis by keyword (the panel itself has 428).

Custom theme editor (Settings > Custom theme editor): live preview; background, optional gradient, keys, special keys, pressed key, text, accent, optional border, key opacity, background image (copied and downscaled on the phone, with dimming). Apply, Save as (named themes show in the theme list), Start from built-in, Reset, Delete saved.

## Earlier features (v0.2.0 and v0.1.0)

Mobile mode: QWERTY, number row, Shift with caps lock, `?123` with two symbol pages (₹ £ € ¥ ¢, math, legal), long-press popups ($ - . 0 = * / quotes, accented letters), top toolbar (emoji, clipboard, undo, redo, mic), emoji panel, optional clipboard history, mic through the phone's speech screen, spacebar swipe cursor, backspace swipe deletes words, auto-capitalization, double-space period, key preview with themed border.
PC mode: compact portrait and full landscape layouts, F-keys, nav keys, arrows, numpad, corner Shift hints, sticky/locking modifiers (gold), right Ctrl before the arrows, optional quick-action bar.
Also: 15 themes (default Gold Premium), size/spacing/corner sliders, sound and vibration controls, settings with a live "try it" field.

## Android limits and how keys behave

| Key | What happens |
|---|---|
| Letters, digits, punctuation, Space, Enter, Backspace | Handled through InputConnection. Works everywhere. |
| Arrows, Home, End, Del, Tab, Esc, Ins, PgUp/PgDn | Sent as KeyEvents. Work where the app handles them. |
| F1-F12 | Sent as KeyEvents. Most Android apps ignore them; useful in terminals, remote desktop, some web apps. |
| Ctrl+A/C/X/V | Executed directly on the focused editor. |
| Undo / Redo / Cut / Copy / Paste / Select All buttons | Use the editor's own action; if the app does not support it, ProKey sends Ctrl+Z / Ctrl+Y / Ctrl+X / Ctrl+C / Ctrl+V / Ctrl+A. |
| Other Ctrl/Alt/Shift combos | Sent as a KeyEvent with modifier flags; app must support the shortcut. |
| Win (Meta) | Adds the Meta flag to key events. No system-level effect. |
| Print Screen | A keyboard cannot take screenshots. Sends the event and shows a hint to use the phone shortcut. |
| Fn | Shows/hides the F1-F12 row. |
| Mic | Needs a speech-recognition app (normally Google). Audio is processed by that app, not ProKey. |

## Quality limits you should know about

- English dictionary: 133,649 words from the system en_US Hunspell/SCOWL list (see docs/THIRD_PARTY_NOTICES.md; keep that notice if you publish). Only the first 852 words are ranked by real commonness (hand-written list); the rest are ordered by length, so completions for less common words are weak. There is no key-proximity model, so corrections use edit distance. Autocorrect only targets common words, or a single close match for longer words. For better results replace `app/src/main/assets/en_words.txt` with a frequency-ordered list (first line = number of "common" words, then one word per line, most common first).
- Next-word prediction: about 60 bundled seeds plus what you type.
- Hinglish rules are approximate (for example schwa and n/m handling); variants are offered, learning is not.
- InScript layout: the standard letter positions except the `` ` `` key (ॊ) is omitted; the digits row is always shown in Devanagari digits.
- No suggestions in InScript mode; no downloadable language packs.
- Emoji set is curated, not complete; search covers part of it.

## Not in this build yet

One-handed / floating / split / left-right layouts, emoji suggestions while typing, 512x512 PNG icon, store screenshots, OPPO submission package.

## Other notes

- `targetSdk` is 34 on purpose. Android 15 edge-to-edge changes affect IME windows; raise to 35 after testing on a device.
- Key sound uses Android touch sounds. If Touch sounds is off in system settings you will hear nothing.
- Key preview for keys in the very top row overlays that row (there is no window above the keyboard to draw into).
- Clipboard history and the personal dictionary, when used, are stored unencrypted in the app's private storage.
- The first time the keyboard starts, the word list loads in the background (a moment); suggestions appear once it is ready. Memory use with the full word list is not measured; test on a low-end phone.
- ColorOS / Realme UI / One UI / HyperOS compatibility, battery and RAM behaviour are untested. See docs/TESTING.md.
