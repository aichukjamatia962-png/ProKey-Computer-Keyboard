package com.prokey.computerkeyboard

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

/**
 * Optional clipboard history. Stored only in this app's private storage (unencrypted),
 * and only while the user has turned clipboard history on.
 */
class ClipStore(context: Context) {

    data class Item(val text: String, val pinned: Boolean)

    private val sp = context.applicationContext.getSharedPreferences("clipboard", Context.MODE_PRIVATE)

    private fun load(): MutableList<Item> {
        val raw = sp.getString("items", null) ?: return mutableListOf()
        val out: MutableList<Item> = ArrayList()
        try {
            val arr = JSONArray(raw)
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                out.add(Item(o.getString("t"), o.optBoolean("p", false)))
            }
        } catch (e: Exception) {
            out.clear()
        }
        return out
    }

    private fun save(list: List<Item>) {
        val arr = JSONArray()
        for (it in list) arr.put(JSONObject().put("t", it.text).put("p", it.pinned))
        sp.edit().putString("items", arr.toString()).apply()
    }

    /** Pinned entries first, then newest first. */
    fun items(): List<Item> = load().sortedByDescending { it.pinned }

    fun add(text: String, max: Int) {
        val list = load()
        val existing = list.indexOfFirst { it.text == text }
        val pinned = if (existing >= 0) list.removeAt(existing).pinned else false
        list.add(0, Item(text, pinned))
        var unpinned = list.count { !it.pinned }
        while (unpinned > max) {
            val idx = list.indexOfLast { !it.pinned }
            if (idx < 0) break
            list.removeAt(idx)
            unpinned--
        }
        save(list)
    }

    fun setPinned(text: String, pinned: Boolean) {
        save(load().map { if (it.text == text) it.copy(pinned = pinned) else it })
    }

    fun remove(text: String) {
        save(load().filter { it.text != text })
    }

    fun clearUnpinned() {
        save(load().filter { it.pinned })
    }

    fun clearAll() {
        sp.edit().clear().apply()
    }
}
