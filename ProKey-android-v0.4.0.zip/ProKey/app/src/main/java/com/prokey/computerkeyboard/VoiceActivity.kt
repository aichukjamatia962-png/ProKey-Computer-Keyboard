package com.prokey.computerkeyboard

import android.content.ActivityNotFoundException
import android.content.Intent
import android.os.Bundle
import android.os.SystemClock
import android.speech.RecognizerIntent
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.result.contract.ActivityResultContracts

/**
 * Transparent hop-off for the mic key. It opens the phone's own speech-recognition screen
 * (RecognizerIntent), so ProKey never touches the microphone and needs no audio permission.
 * The recognised text is handed back through [VoiceBridge] and typed when the keyboard returns.
 */
class VoiceActivity : ComponentActivity() {

    private val launcher = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { r ->
        if (r.resultCode == RESULT_OK) {
            val text = r.data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)?.firstOrNull()
            if (!text.isNullOrBlank()) VoiceBridge.put(text)
        }
        finish()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (savedInstanceState != null) return // already launched; wait for the result
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
            .putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
        try {
            launcher.launch(intent)
        } catch (e: ActivityNotFoundException) {
            Toast.makeText(this, "No speech-recognition app found on this phone", Toast.LENGTH_LONG).show()
            finish()
        }
    }
}

object VoiceBridge {
    @Volatile private var text: String? = null
    @Volatile private var time = 0L

    fun put(t: String) {
        text = t
        time = SystemClock.uptimeMillis()
    }

    /** Returns the pending text once, if it is fresh. */
    fun take(): String? {
        val t = text
        text = null
        return if (t != null && SystemClock.uptimeMillis() - time < 30_000L) t else null
    }
}
