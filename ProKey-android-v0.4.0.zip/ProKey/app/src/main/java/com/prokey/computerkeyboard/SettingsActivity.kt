package com.prokey.computerkeyboard

import android.content.Intent
import android.os.Bundle
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.LinearLayout
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.preference.ListPreference
import androidx.preference.Preference
import androidx.preference.PreferenceFragmentCompat

class SettingsActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val pad = (12 * resources.displayMetrics.density).toInt()
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        // Type here with ProKey selected: the keyboard updates live as you change settings below.
        root.addView(
            EditText(this).apply {
                hint = getString(R.string.try_hint)
                setPadding(pad, pad, pad, pad)
            },
            LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT)
        )
        val container = FrameLayout(this).apply { id = R.id.settings_container }
        root.addView(container, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f))
        setContentView(root)
        if (savedInstanceState == null) {
            supportFragmentManager.beginTransaction()
                .replace(R.id.settings_container, SettingsFragment())
                .commit()
        }
    }

    class SettingsFragment : PreferenceFragmentCompat() {

        override fun onCreatePreferences(savedInstanceState: Bundle?, rootKey: String?) {
            setPreferencesFromResource(R.xml.preferences, rootKey)
            refreshThemeList()
            findPreference<Preference>("personal_dictionary")?.setOnPreferenceClickListener {
                startActivity(Intent(requireContext(), PersonalDictActivity::class.java))
                true
            }
            findPreference<Preference>("custom_theme")?.setOnPreferenceClickListener {
                startActivity(Intent(requireContext(), CustomThemeActivity::class.java))
                true
            }
            findPreference<Preference>("clear_clipboard")?.setOnPreferenceClickListener {
                AlertDialog.Builder(requireContext())
                    .setTitle(R.string.pref_clear_clipboard)
                    .setMessage(R.string.clear_clipboard_confirm)
                    .setPositiveButton(android.R.string.ok) { _, _ ->
                        ClipStore(requireContext()).clearAll()
                        Prefs(requireContext()).clearEmojiRecent()
                    }
                    .setNegativeButton(android.R.string.cancel, null)
                    .show()
                true
            }
            findPreference<Preference>("privacy_info")?.setOnPreferenceClickListener {
                AlertDialog.Builder(requireContext())
                    .setTitle(R.string.privacy_title)
                    .setMessage(R.string.privacy_body)
                    .setPositiveButton(android.R.string.ok, null)
                    .show()
                true
            }
        }

        override fun onResume() {
            super.onResume()
            // The theme editor may have added or applied a theme while this screen was in the background.
            refreshThemeList()
        }

        private fun refreshThemeList() {
            val lp = findPreference<ListPreference>(Prefs.THEME) ?: return
            val ch = ThemeStore(requireContext()).choices()
            lp.entries = Array<CharSequence>(ch.size) { ch[it].second }
            lp.entryValues = Array<CharSequence>(ch.size) { ch[it].first }
            lp.value = Prefs(requireContext()).theme
        }
    }
}
