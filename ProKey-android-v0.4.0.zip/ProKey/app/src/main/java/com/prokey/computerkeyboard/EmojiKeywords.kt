package com.prokey.computerkeyboard

/** Search keywords for a subset of the bundled emojis (common ones). */
object EmojiKeywords {
    private val entries: List<Pair<String, List<String>>> = """
😀 grin smile happy
😃 smile happy joy
😄 smile laugh happy
😁 grin beam teeth
😆 laugh haha lol
😅 sweat nervous relief
😂 laugh lol joy tears funny
🤣 rofl lol laughing funny
😊 blush smile happy shy
😇 angel innocent halo
🙂 smile slight
🙃 upside silly sarcasm
😉 wink flirt
😍 love heart eyes crush
🥰 love adore hearts
😘 kiss love blow
😋 yum tasty delicious
😛 tongue playful
😜 wink tongue crazy
🤑 money rich
🤗 hug thanks
🤭 oops giggle secret
🤔 think hmm wonder
😐 neutral meh blank
🙄 eyeroll annoyed whatever
😬 grimace awkward
😮 wow surprised open
😲 shocked astonished
😳 embarrassed blush flushed
🥺 please pleading puppy cute
😢 sad cry tear
😭 cry sob loud sad
😤 angry frustrated huff
😠 angry mad
😡 angry rage red mad
🤬 swear curse angry
😱 scream scared fear shock
😨 fear scared
😰 anxious nervous worried
😓 sweat tired worry
🤯 mind blown shocked
😴 sleep tired zzz
🤤 drool hungry
😷 mask sick
🤒 sick fever ill
🤕 hurt injured bandage
🤢 nausea sick green
🤮 vomit sick
😎 cool sunglasses
🤓 nerd geek smart
🥳 party celebrate birthday
👋 wave hello hi bye
👌 ok perfect fine
✌️ peace victory
🤞 luck fingers crossed hope
🤙 call me shaka
👈 left point
👉 right point
👆 up point
👇 down point
👍 thumbs up like yes good ok
👎 thumbs down dislike no bad
✊ fist power
👊 punch fist bump
👏 clap applause congrats
🙌 hooray celebrate praise
🤝 handshake deal agree
🙏 pray thanks please namaste
💪 strong muscle strength gym
🧠 brain smart think
👀 eyes look watching
👅 tongue
👶 baby
👨 man
👩 woman
🙋 raise hand question
🤷 shrug dunno
🤦 facepalm
🐶 dog puppy pet
🐱 cat kitten pet
🐭 mouse
🐰 rabbit bunny
🦊 fox
🐻 bear
🐼 panda
🐯 tiger
🦁 lion
🐮 cow
🐷 pig
🐸 frog
🐵 monkey
🙈 monkey see no evil shy
🐔 chicken
🐧 penguin
🐦 bird
🦅 eagle
🦉 owl night
🐴 horse
🦄 unicorn magic
🐝 bee honey
🦋 butterfly
🐢 turtle slow
🐍 snake
🐙 octopus
🐬 dolphin
🐳 whale
🐘 elephant
🌵 cactus desert
🌲 tree pine
🌸 flower blossom cherry
🌹 rose flower love
🌻 sunflower flower
🍎 apple fruit red
🍌 banana fruit
🍉 watermelon fruit summer
🍇 grapes fruit
🍓 strawberry fruit
🍒 cherry fruit
🥭 mango fruit
🍍 pineapple fruit
🍅 tomato
🍆 eggplant brinjal
🥕 carrot
🌽 corn
🍞 bread
🧀 cheese
🍗 chicken leg food
🍔 burger hamburger food
🍟 fries food
🍕 pizza food
🌭 hotdog food
🌮 taco food
🍜 noodles ramen soup
🍛 curry rice food
🍣 sushi
🍚 rice food
🍦 icecream dessert
🍰 cake dessert
🎂 birthday cake celebrate
🍩 donut dessert
🍪 cookie biscuit
🍫 chocolate
🍬 candy sweet
☕ coffee tea hot drink
🍵 tea green drink
🍺 beer drink
🍷 wine drink
🥤 drink soda cup
🚗 car drive vehicle
🚕 taxi cab
🚌 bus
🚓 police car
🚑 ambulance
🚒 fire truck
🚚 truck delivery
🛵 scooter
🚲 bicycle bike
🚂 train
✈️ plane flight travel airport
🚀 rocket launch space
🚢 ship boat
⚓ anchor
🏠 home house
🏢 office building
🏥 hospital
🏦 bank
🕌 mosque
⛪ church
🌅 sunrise morning
🌃 night city
🌈 rainbow
⚽ football soccer ball
🏀 basketball
🏈 american football
⚾ baseball
🎾 tennis
🏏 cricket
⛳ golf
🏆 trophy winner champion
🥇 gold medal first winner
🥈 silver medal second
🥉 bronze medal third
🎯 target dart goal
🎮 game controller gaming
🎲 dice game
💡 idea bulb light
📱 phone mobile cell
💻 laptop computer
⌨️ keyboard typing
📷 camera photo
🎥 video movie camera
📞 phone call
📺 tv television
⏰ alarm clock time
⌚ watch time
🔋 battery charge
🔌 plug power
💰 money bag cash
💵 dollar money cash
💳 card credit payment
💎 diamond gem
🔧 wrench tool fix
🔨 hammer tool
⚙️ gear settings
🔑 key lock
🔒 lock secure private
🔓 unlock
📌 pin location
📎 paperclip attach
✂️ scissors cut
📝 note memo write
📚 books study read
📖 book read
✏️ pencil write
📅 calendar date
📊 chart graph stats
📈 chart up growth
📉 chart down decline
🛒 cart shopping
🎁 gift present
🎈 balloon party
🎉 party celebrate congrats tada
🎊 confetti celebrate
🔔 bell notification
🔍 search find magnifier
📦 package box delivery
❤️ love heart red
🧡 orange heart
💛 yellow heart
💚 green heart
💙 blue heart
💜 purple heart
🖤 black heart
🤍 white heart
💔 broken heart sad
💕 love hearts two
💖 sparkling heart love
💘 cupid arrow love
💋 kiss lips
💯 hundred perfect score
✨ sparkles shine magic new
⭐ star favorite
🌟 star glow shine
💫 dizzy star
🔥 fire hot lit
💥 boom explosion
✔️ check tick done
✅ check done yes
❌ cross no wrong
❓ question
❗ exclamation important
⚡ lightning bolt fast power
☀️ sun sunny weather
🌙 moon night
🇮🇳 india flag
🇺🇸 usa america flag
🇬🇧 uk britain flag
🇨🇦 canada flag
🇦🇺 australia flag
🇩🇪 germany flag
🇫🇷 france flag
🇯🇵 japan flag
🇨🇳 china flag
🇧🇷 brazil flag
🇵🇰 pakistan flag
🇧🇩 bangladesh flag
🏁 finish race flag
🚩 red flag warning
""".trim().lines().mapNotNull { line ->
        val parts = line.trim().split(" ").filter { it.isNotEmpty() }
        if (parts.size < 2) null else parts[0] to parts.drop(1)
    }

    /** Emojis whose keywords start with (or contain) every word of [query]. Best matches first. */
    fun search(query: String, limit: Int = 40): List<String> {
        val words = query.lowercase().trim().split(" ").filter { it.isNotEmpty() }
        if (words.isEmpty()) return emptyList()
        val scored = ArrayList<Pair<Int, String>>()
        for ((emoji, kws) in entries) {
            var score = 0
            var ok = true
            for (q in words) {
                score += when {
                    kws.any { it == q } -> 3
                    kws.any { it.startsWith(q) } -> 2
                    kws.any { it.contains(q) } -> 1
                    else -> { ok = false; 0 }
                }
            }
            if (ok) scored.add(score to emoji)
        }
        return scored.sortedByDescending { it.first }.take(limit).map { EmojiData.fix(it.second) }
    }
}
