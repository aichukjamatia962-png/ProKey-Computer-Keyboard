package com.prokey.computerkeyboard

import android.content.Context
import org.json.JSONObject

/** User-made themes: one working "custom" theme plus named saved themes (ids "u:<name>"). Local only. */
class ThemeStore(context: Context) {
    private val sp = context.applicationContext.getSharedPreferences("themes", Context.MODE_PRIVATE)

    private fun toJson(t: KbTheme): JSONObject = JSONObject()
        .put("bg", t.bg).put("key", t.key).put("keySpecial", t.keySpecial).put("keyPressed", t.keyPressed)
        .put("text", t.text).put("accent", t.accent).put("border", t.border)
        .put("bgEnd", t.bgEnd ?: JSONObject.NULL)
        .put("bgImage", t.bgImage ?: JSONObject.NULL)
        .put("imageDim", t.imageDim).put("keyAlpha", t.keyAlpha)

    private fun fromJson(id: String, name: String, o: JSONObject) = KbTheme(
        id = id, name = name,
        bg = o.getInt("bg"),
        bgEnd = if (o.isNull("bgEnd")) null else o.getInt("bgEnd"),
        key = o.getInt("key"), keySpecial = o.getInt("keySpecial"), keyPressed = o.getInt("keyPressed"),
        text = o.getInt("text"), accent = o.getInt("accent"), border = o.optInt("border", 0),
        bgImage = if (o.isNull("bgImage")) null else o.getString("bgImage"),
        imageDim = o.optInt("imageDim", 45), keyAlpha = o.optInt("keyAlpha", 100),
    )

    private fun savedJson(): JSONObject =
        try { JSONObject(sp.getString("saved", "{}") ?: "{}") } catch (e: Exception) { JSONObject() }

    fun custom(): KbTheme? {
        val raw = sp.getString("custom", null) ?: return null
        return try { fromJson("custom", "Custom", JSONObject(raw)) } catch (e: Exception) { null }
    }

    fun saveCustom(t: KbTheme) {
        sp.edit().putString("custom", toJson(t).toString()).apply()
    }

    fun savedNames(): List<String> = savedJson().keys().asSequence().toList().sorted()

    fun save(name: String, t: KbTheme) {
        val all = savedJson()
        all.put(name, toJson(t))
        sp.edit().putString("saved", all.toString()).apply()
    }

    fun delete(name: String) {
        val all = savedJson()
        all.remove(name)
        sp.edit().putString("saved", all.toString()).apply()
    }

    fun get(id: String): KbTheme? {
        if (id == "custom") return custom()
        if (!id.startsWith("u:")) return null
        val name = id.removePrefix("u:")
        val o = savedJson().optJSONObject(name) ?: return null
        return try { fromJson(id, name, o) } catch (e: Exception) { null }
    }

    /** Built-in, custom or saved theme by id; falls back to the default theme. */
    fun resolve(id: String): KbTheme =
        Themes.all.firstOrNull { it.id == id } ?: get(id) ?: Themes.byId(Prefs.DEFAULT_THEME)

    /** (id, display name) for every selectable theme. */
    fun choices(): List<Pair<String, String>> {
        val out = ArrayList<Pair<String, String>>()
        for (t in Themes.all) out.add(t.id to t.name)
        if (custom() != null) out.add("custom" to "Custom (edited)")
        for (n in savedNames()) out.add("u:$n" to "My theme: $n")
        return out
    }
}
