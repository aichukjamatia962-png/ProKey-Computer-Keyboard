package com.prokey.computerkeyboard

/** Symbols panel content: currency, math, fractions, super/subscripts, Greek, arrows, special characters. */
object SymbolData {
    private fun list(s: String) = s.trim().split(" ").filter { it.isNotEmpty() }

    val categories: List<Pair<String, List<String>>> = listOf(
        "₹" to list("₹ $ € £ ¥ ¢ ₿ ₩ ₽ ₺ ₫ ₪ ฿ ₦ ₱ ₴ ₵ ₡ ¤"),
        "∑" to list("+ − × ÷ = ≠ ≈ ≤ ≥ ± ∓ √ ∛ ∞ ∑ ∏ ∫ ∂ ∆ ∇ ∈ ∉ ⊂ ⊃ ∪ ∩ ∀ ∃ ∴ ∵ ∅ π ° % ‰ ¬ ∧ ∨ ∝ ∥ ⊥ ∠"),
        "½" to list("½ ⅓ ⅔ ¼ ¾ ⅕ ⅖ ⅗ ⅘ ⅙ ⅚ ⅛ ⅜ ⅝ ⅞ ⅐ ⅑ ⅒"),
        "x²" to list("⁰ ¹ ² ³ ⁴ ⁵ ⁶ ⁷ ⁸ ⁹ ⁺ ⁻ ⁼ ⁽ ⁾ ⁿ ⁱ ₀ ₁ ₂ ₃ ₄ ₅ ₆ ₇ ₈ ₉ ₊ ₋ ₌ ₍ ₎"),
        "αβ" to list("α β γ δ ε ζ η θ ι κ λ μ ν ξ ο π ρ σ τ υ φ χ ψ ω Α Β Γ Δ Ε Ζ Η Θ Ι Κ Λ Μ Ν Ξ Ο Π Ρ Σ Τ Υ Φ Χ Ψ Ω"),
        "→" to list("← ↑ → ↓ ↔ ↕ ↖ ↗ ↘ ↙ ⇐ ⇑ ⇒ ⇓ ⇔ ↺ ↻ ➔ ➜ ➤ ▶ ◀ ▲ ▼"),
        "★" to list("• … † ‡ § ¶ © ® ™ № ★ ☆ ✓ ✗ ♠ ♣ ♪ ♫ ♀ ♂ ℃ ℉ ‹ › « » “ ” ‘ ’ „ ‰ ·"),
    )
}
