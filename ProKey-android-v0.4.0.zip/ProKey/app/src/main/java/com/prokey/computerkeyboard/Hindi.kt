package com.prokey.computerkeyboard

import android.content.Context

/**
 * Rule-based Roman -> Devanagari transliteration (Hinglish typing). It is approximate:
 * common words come from the bundled dictionary, everything else is produced by these rules,
 * and several spelling variants are offered.
 */
object Translit {
    private const val HALANT = "\u094D"

    private val CONS = listOf(
        "cch" to "च्छ", "chh" to "छ", "ksh" to "क्ष", "kh" to "ख", "gh" to "घ", "ch" to "च", "jh" to "झ",
        "th" to "थ", "dh" to "ध", "ph" to "फ", "bh" to "भ", "sh" to "श", "gy" to "ज्ञ",
        "k" to "क", "g" to "ग", "c" to "क", "j" to "ज", "t" to "त", "d" to "द", "n" to "न", "p" to "प",
        "f" to "फ", "b" to "ब", "m" to "म", "y" to "य", "r" to "र", "l" to "ल", "v" to "व", "w" to "व",
        "s" to "स", "h" to "ह", "z" to "ज", "q" to "क", "x" to "क्स",
    )
    private val RETRO = mapOf("t" to "ट", "th" to "ठ", "d" to "ड", "dh" to "ढ")
    private val VOW2 = setOf("aa", "ai", "au", "ee", "ii", "oo", "uu")
    private val INDEP = mapOf(
        "a" to "अ", "aa" to "आ", "i" to "इ", "ii" to "ई", "ee" to "ई", "u" to "उ", "oo" to "ऊ", "uu" to "ऊ",
        "e" to "ए", "ai" to "ऐ", "o" to "ओ", "au" to "औ",
    )
    private val MATRA = mapOf(
        "aa" to "ा", "i" to "ि", "ii" to "ी", "ee" to "ी", "u" to "ु", "oo" to "ू", "uu" to "ू",
        "e" to "े", "ai" to "ै", "o" to "ो", "au" to "ौ",
    )
    private val VARGA = setOf("k", "kh", "g", "gh", "ch", "chh", "cch", "j", "jh", "t", "th", "d", "dh", "p", "ph", "b", "bh", "c")

    private class Tok(val vowel: Boolean, val roman: String, val dev: String = "")

    private fun tokenize(w: String): MutableList<Tok> {
        val toks = ArrayList<Tok>()
        var i = 0
        while (i < w.length) {
            val ch = w[i]
            if (ch in "aeiou") {
                val two = if (i + 1 < w.length) w.substring(i, i + 2) else ""
                if (two in VOW2) {
                    toks.add(Tok(true, two)); i += 2
                } else {
                    toks.add(Tok(true, ch.toString())); i += 1
                }
            } else if (ch in 'a'..'z') {
                var matched = false
                for ((r, d) in CONS) {
                    if (w.startsWith(r, i)) {
                        var dev = d
                        if (r == "c" && i + 1 < w.length && w[i + 1] in "eiy") dev = "स"
                        toks.add(Tok(false, r, dev))
                        i += r.length
                        matched = true
                        break
                    }
                }
                if (!matched) i++
            } else {
                i++
            }
        }
        return toks
    }

    /** [longA]: 0 none, 1 make the last medial 'a' long, 2 make the first medial 'a' long. [noAnusvara]: always use halant for n/m. */
    private fun build(w: String, retro: Boolean, noAnusvara: Boolean, longA: Int): String? {
        val toks = tokenize(w)
        val n = toks.size
        if (n == 0) return null
        if (n >= 2 && toks[n - 1].vowel && !toks[n - 2].vowel) {
            if (toks[n - 1].roman == "a") toks[n - 1] = Tok(true, "aa")
            else if (toks[n - 1].roman == "i") toks[n - 1] = Tok(true, "ee")
        }
        if (longA != 0) {
            val range = if (longA == 1) (n - 2 downTo 1) else (1..n - 2)
            var done = false
            for (k in range) {
                if (toks[k].vowel && toks[k].roman == "a" && !toks[k - 1].vowel) {
                    toks[k] = Tok(true, "aa")
                    done = true
                    break
                }
            }
            if (!done) return null
        }
        val out = StringBuilder()
        var pending = false
        for (k in 0 until n) {
            val t = toks[k]
            if (!t.vowel) {
                var d = t.dev
                if (retro) RETRO[t.roman]?.let { d = it }
                val nxt = if (k + 1 < n) toks[k + 1] else null
                if ((t.roman == "n" || t.roman == "m") && nxt != null && !nxt.vowel) {
                    if (!noAnusvara && nxt.roman in VARGA) {
                        out.append("ं")
                        pending = false
                        continue
                    }
                }
                if (pending) out.append(HALANT)
                out.append(d)
                pending = true
            } else {
                if (pending) {
                    if (t.roman != "a") out.append(MATRA[t.roman] ?: "")
                    pending = false
                } else {
                    out.append(INDEP[t.roman] ?: "")
                }
            }
        }
        return out.toString()
    }

    fun variants(word: String): List<String> {
        val w = word.lowercase()
        val res = LinkedHashSet<String>()
        build(w, false, false, 0)?.let { res.add(it) }
        if (w.length <= 10) {
            build(w, false, false, 1)?.let { res.add(it) }
            build(w, false, false, 2)?.let { res.add(it) }
        }
        if (w.any { it == 't' || it == 'd' }) build(w, true, false, 0)?.let { res.add(it) }
        build(w, false, true, 0)?.let { res.add(it) }
        return res.toList()
    }
}

/** Bundled Hinglish word list (assets/hi_words.txt: roman<TAB>devanagari). */
class HindiDict {
    private val map = HashMap<String, String>()

    @Volatile
    var ready = false
        private set

    fun load(ctx: Context) {
        ctx.assets.open("hi_words.txt").bufferedReader().useLines { lines ->
            for (line in lines) {
                val t = line.indexOf('\t')
                if (t > 0) map[line.substring(0, t)] = line.substring(t + 1).trim()
            }
        }
        ready = true
    }

    /** Devanagari candidates for a Roman prefix, best first (at most 3). */
    fun candidates(prefix: String): List<String> {
        val lower = prefix.lowercase()
        val out = LinkedHashSet<String>()
        map[lower]?.let { out.add(it) }
        val variants = Translit.variants(lower)
        variants.firstOrNull()?.let { out.add(it) }
        if (lower.length >= 2) {
            var best: String? = null
            for ((k, v) in map) {
                if (k.length > lower.length && k.startsWith(lower) && (best == null || k.length < best.length)) best = k
            }
            best?.let { out.add(map[it] ?: "") }
        }
        for (v in variants.drop(1)) out.add(v)
        out.remove("")
        return out.take(3)
    }
}
