package com.prokey.computerkeyboard

import android.app.AlertDialog
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Bundle
import android.text.Editable
import android.text.InputFilter
import android.text.InputType
import android.text.TextWatcher
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.Switch
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import java.io.File
import java.io.FileOutputStream
import kotlin.math.max

/** Edit colors, gradient, border, key opacity and a background image with a live keyboard preview. */
class CustomThemeActivity : AppCompatActivity() {

    private lateinit var store: ThemeStore
    private lateinit var prefs: Prefs
    private lateinit var preview: KeyboardView
    private lateinit var controls: LinearLayout
    private lateinit var baseTheme: KbTheme
    private lateinit var draft: KbTheme
    private var dp = 1f

    private val pickImage = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) importImage(uri)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        title = "Custom theme"
        dp = resources.displayMetrics.density
        store = ThemeStore(this)
        prefs = Prefs(this)
        baseTheme = store.resolve(prefs.theme)
        draft = baseTheme.copy(id = "custom", name = "Custom")

        preview = KeyboardView(this)
        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.addView(preview, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        controls = LinearLayout(this)
        controls.orientation = LinearLayout.VERTICAL
        val pad = (14 * dp).toInt()
        controls.setPadding(pad, pad, pad, pad)
        val scroll = ScrollView(this)
        scroll.addView(controls)
        root.addView(scroll, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))
        setContentView(root)
        buildControls()
        refresh()
    }

    private fun refresh() {
        val h = 46f * prefs.heightPct / 100f
        preview.setup(Layouts.mobile(false, false, "", false), draft, KeyboardView.Look(h, prefs.gap.toFloat(), prefs.radius.toFloat(), true))
    }

    // ---- controls ---------------------------------------------------------------------------

    private fun buildControls() {
        controls.removeAllViews()
        addColor("Background", { draft.bg }) { draft = draft.copy(bg = it) }
        addSwitch("Gradient background", draft.bgEnd != null) { on ->
            draft = draft.copy(bgEnd = if (on) (draft.bgEnd ?: draft.accent) else null)
            buildControls()
        }
        draft.bgEnd?.let { addColor("Gradient end color", { draft.bgEnd ?: draft.bg }) { c -> draft = draft.copy(bgEnd = c) } }
        addColor("Keys", { draft.key }) { draft = draft.copy(key = it) }
        addColor("Special keys (Shift, Enter, Ctrl...)", { draft.keySpecial }) { draft = draft.copy(keySpecial = it) }
        addColor("Pressed key", { draft.keyPressed }) { draft = draft.copy(keyPressed = it) }
        addColor("Text", { draft.text }) { draft = draft.copy(text = it) }
        addColor("Accent (active keys, popups)", { draft.accent }) { draft = draft.copy(accent = it) }
        addSwitch("Key border", draft.border != 0) { on ->
            draft = draft.copy(border = if (on) (if (draft.border != 0) draft.border else draft.accent) else 0)
            buildControls()
        }
        if (draft.border != 0) addColor("Border color", { draft.border }) { draft = draft.copy(border = it) }
        addSeek("Key opacity (%)", 10, 100, draft.keyAlpha) { draft = draft.copy(keyAlpha = it) }

        addButton("Choose background image") { pickImage.launch(arrayOf("image/*")) }
        if (draft.bgImage != null) {
            addSeek("Image dimming (%)", 0, 90, draft.imageDim) { draft = draft.copy(imageDim = it) }
            addButton("Remove background image") { draft = draft.copy(bgImage = null); buildControls(); refresh() }
        }

        addButton("Start from a built-in theme") { chooseBase() }
        addButton("Reset") { draft = baseTheme.copy(id = "custom", name = "Custom"); buildControls(); refresh() }
        addButton("Apply to my keyboard") { apply() }
        addButton("Save as...") { saveAs() }
        addButton("Delete a saved theme...") { deleteSaved() }
    }

    private fun rowOf(label: String, right: View): View {
        val row = LinearLayout(this)
        row.orientation = LinearLayout.HORIZONTAL
        row.gravity = Gravity.CENTER_VERTICAL
        row.setPadding(0, (8 * dp).toInt(), 0, (8 * dp).toInt())
        val tv = TextView(this)
        tv.text = label
        tv.textSize = 16f
        row.addView(tv, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        row.addView(right)
        return row
    }

    private fun swatchDrawable(color: Int) = GradientDrawable().apply {
        cornerRadius = 6f * dp
        setColor(color or 0xFF000000.toInt())
        setStroke(dp.toInt().coerceAtLeast(1), 0x66888888)
    }

    private fun addColor(label: String, get: () -> Int, set: (Int) -> Unit) {
        val sw = View(this)
        sw.background = swatchDrawable(get())
        sw.setOnClickListener {
            pickColor(get()) { c ->
                set(c)
                sw.background = swatchDrawable(c)
                refresh()
            }
        }
        controls.addView(rowOf(label, sw.also { it.layoutParams = LinearLayout.LayoutParams((48 * dp).toInt(), (30 * dp).toInt()) }))
    }

    private fun addSwitch(label: String, checked: Boolean, onChange: (Boolean) -> Unit) {
        val sw = Switch(this)
        sw.isChecked = checked
        sw.setOnCheckedChangeListener { _, on -> onChange(on); refresh() }
        controls.addView(rowOf(label, sw))
    }

    private fun addSeek(label: String, min: Int, maxV: Int, value: Int, onChange: (Int) -> Unit) {
        val tv = TextView(this)
        tv.text = "$label: $value"
        tv.textSize = 16f
        tv.setPadding(0, (8 * dp).toInt(), 0, 0)
        controls.addView(tv)
        val bar = SeekBar(this)
        bar.max = maxV - min
        bar.progress = value - min
        bar.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar?, p: Int, fromUser: Boolean) {
                tv.text = "$label: ${p + min}"
                if (fromUser) {
                    onChange(p + min)
                    refresh()
                }
            }
            override fun onStartTrackingTouch(s: SeekBar?) {}
            override fun onStopTrackingTouch(s: SeekBar?) {}
        })
        controls.addView(bar)
    }

    private fun addButton(text: String, onClick: () -> Unit) {
        val b = Button(this)
        b.text = text
        b.isAllCaps = false
        b.setOnClickListener { onClick() }
        controls.addView(b)
    }

    // ---- color picker -----------------------------------------------------------------------

    private fun hexOf(rgb: IntArray) = String.format("#%02X%02X%02X", rgb[0], rgb[1], rgb[2])

    private fun pickColor(initial: Int, onDone: (Int) -> Unit) {
        val rgb = intArrayOf(Color.red(initial), Color.green(initial), Color.blue(initial))
        val box = LinearLayout(this)
        box.orientation = LinearLayout.VERTICAL
        val pad = (18 * dp).toInt()
        box.setPadding(pad, pad, pad, pad)
        val swatch = View(this)
        swatch.setBackgroundColor(Color.rgb(rgb[0], rgb[1], rgb[2]))
        box.addView(swatch, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, (48 * dp).toInt()))
        val hex = EditText(this)
        hex.setText(hexOf(rgb))
        hex.inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS
        hex.filters = arrayOf(InputFilter.LengthFilter(7))
        box.addView(hex)
        val bars = ArrayList<SeekBar>()
        var updating = false
        fun sync() {
            swatch.setBackgroundColor(Color.rgb(rgb[0], rgb[1], rgb[2]))
            updating = true
            hex.setText(hexOf(rgb))
            updating = false
        }
        for (i in 0..2) {
            val bar = SeekBar(this)
            bar.max = 255
            bar.progress = rgb[i]
            bar.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(s: SeekBar?, p: Int, fromUser: Boolean) {
                    if (fromUser) {
                        rgb[i] = p
                        sync()
                    }
                }
                override fun onStartTrackingTouch(s: SeekBar?) {}
                override fun onStopTrackingTouch(s: SeekBar?) {}
            })
            bars.add(bar)
            val l = TextView(this)
            l.text = listOf("Red", "Green", "Blue")[i]
            box.addView(l)
            box.addView(bar)
        }
        hex.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, st: Int, c: Int, a: Int) {}
            override fun onTextChanged(s: CharSequence?, st: Int, b: Int, c: Int) {}
            override fun afterTextChanged(e: Editable?) {
                if (updating) return
                try {
                    val c = Color.parseColor(e.toString())
                    rgb[0] = Color.red(c); rgb[1] = Color.green(c); rgb[2] = Color.blue(c)
                    swatch.setBackgroundColor(Color.rgb(rgb[0], rgb[1], rgb[2]))
                    for (i in 0..2) bars[i].progress = rgb[i]
                } catch (ex: IllegalArgumentException) {
                    // incomplete or invalid hex: ignore until it parses
                }
            }
        })
        AlertDialog.Builder(this)
            .setTitle("Pick a color")
            .setView(box)
            .setPositiveButton(android.R.string.ok) { _, _ -> onDone(Color.rgb(rgb[0], rgb[1], rgb[2])) }
            .setNegativeButton(android.R.string.cancel, null)
            .show()
    }

    // ---- actions ----------------------------------------------------------------------------

    private fun chooseBase() {
        val names = Themes.all.map { it.name }.toTypedArray()
        AlertDialog.Builder(this)
            .setTitle("Start from")
            .setItems(names) { _, i ->
                draft = Themes.all[i].copy(id = "custom", name = "Custom")
                buildControls()
                refresh()
            }
            .show()
    }

    private fun apply() {
        store.saveCustom(draft.copy(id = "custom", name = "Custom"))
        prefs.sp.edit().putString(Prefs.THEME, "custom").apply()
        prefs.bumpThemeRev()
        Toast.makeText(this, "Applied", Toast.LENGTH_SHORT).show()
    }

    private fun saveAs() {
        val input = EditText(this)
        input.hint = "Theme name"
        input.setSingleLine()
        AlertDialog.Builder(this)
            .setTitle("Save theme as")
            .setView(input)
            .setPositiveButton(android.R.string.ok) { _, _ ->
                val name = input.text.toString().trim().take(24)
                if (name.isEmpty()) {
                    Toast.makeText(this, "Enter a name", Toast.LENGTH_SHORT).show()
                } else {
                    store.save(name, draft.copy(id = "u:$name", name = name))
                    prefs.sp.edit().putString(Prefs.THEME, "u:$name").apply()
                    prefs.bumpThemeRev()
                    Toast.makeText(this, "Saved and applied", Toast.LENGTH_SHORT).show()
                }
            }
            .setNegativeButton(android.R.string.cancel, null)
            .show()
    }

    private fun deleteSaved() {
        val names = store.savedNames()
        if (names.isEmpty()) {
            Toast.makeText(this, "No saved themes", Toast.LENGTH_SHORT).show()
            return
        }
        AlertDialog.Builder(this)
            .setTitle("Delete which theme?")
            .setItems(names.toTypedArray()) { _, i ->
                store.delete(names[i])
                prefs.bumpThemeRev()
            }
            .show()
    }

    private fun importImage(uri: Uri) {
        try {
            val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
            contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, bounds) }
            var sample = 1
            while (max(bounds.outWidth, bounds.outHeight) / sample > 1400) sample *= 2
            val opts = BitmapFactory.Options().apply { inSampleSize = sample }
            val bmp = contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, opts) }
                ?: throw IllegalStateException("decode failed")
            val f = File(filesDir, "kb_bg_${System.currentTimeMillis()}.jpg")
            FileOutputStream(f).use { bmp.compress(Bitmap.CompressFormat.JPEG, 85, it) }
            bmp.recycle()
            draft = draft.copy(bgImage = f.absolutePath)
            buildControls()
            refresh()
        } catch (e: Exception) {
            Toast.makeText(this, "Could not load that image", Toast.LENGTH_LONG).show()
        }
    }
}
