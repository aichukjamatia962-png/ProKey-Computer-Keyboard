package com.prokey.computerkeyboard

/** Builds suggestions, next-word predictions and autocorrect choices. Pure logic, no Android UI. */
class Suggester(
    private val dict: WordDict,
    private val personal: PersonalDict,
    private val next: NextWords,
    private val hindi: HindiDict,
) {
    class Result(val items: List<String>, val auto: String?)

    private val contractions = mapOf(
        "i" to "I", "im" to "I'm", "ive" to "I've", "dont" to "don't", "cant" to "can't", "wont" to "won't",
        "didnt" to "didn't", "isnt" to "isn't", "wasnt" to "wasn't", "doesnt" to "doesn't",
        "couldnt" to "couldn't", "wouldnt" to "wouldn't", "shouldnt" to "shouldn't", "havent" to "haven't",
        "hasnt" to "hasn't", "arent" to "aren't", "werent" to "weren't", "youre" to "you're",
        "theyre" to "they're", "thats" to "that's", "whats" to "what's",
    )

    /** Match the capitalization the user typed. */
    private fun recase(prefix: String, s: String): String = when {
        prefix.length >= 2 && prefix.any { it.isLetter() } && prefix.all { !it.isLetter() || it.isUpperCase() } -> s.uppercase()
        prefix.isNotEmpty() && prefix[0].isUpperCase() -> s.replaceFirstChar { it.uppercase() }
        else -> s
    }

    private fun autoEligible(prefix: String, sentenceStart: Boolean): Boolean {
        if (prefix.length < 3 || prefix.any { !it.isLetter() || it.code > 127 }) return false
        if (prefix.drop(1).any { it.isUpperCase() }) return false
        return prefix[0].isLowerCase() || sentenceStart
    }

    fun nextWords(prev: String?, sentenceStart: Boolean, personalOn: Boolean): List<String> {
        val out = ArrayList<String>()
        if (prev != null) {
            val p = prev.lowercase()
            if (personalOn) personal.next(p, 3).forEach { if (it !in out) out.add(it) }
            next.get(p).forEach { if (it !in out) out.add(it) }
        }
        if (out.isEmpty()) out.addAll(if (sentenceStart || prev == null) listOf("I", "The", "It") else listOf("the", "to", "and"))
        val shown = out.take(3)
        return if (sentenceStart) shown.map { it.replaceFirstChar { c -> c.uppercase() } } else shown
    }

    fun suggestEn(prefix: String, prev: String?, sentenceStart: Boolean, autoOn: Boolean, personalOn: Boolean, nextOn: Boolean): Result {
        if (!dict.ready) return Result(emptyList(), null)
        if (prefix.isEmpty()) return if (nextOn) Result(nextWords(prev, sentenceStart, personalOn), null) else Result(emptyList(), null)
        if (prefix.any { it.isDigit() }) return Result(emptyList(), null)
        val lower = prefix.lowercase()
        val out = ArrayList<String>()
        var auto: String? = null

        val contraction = contractions[lower]
        val known = dict.isKnown(lower) || (personalOn && personal.known(lower))
        if (contraction != null && prefix.all { it.code < 128 }) {
            auto = if (contraction[0] == 'I') contraction else recase(prefix, contraction)
        } else if (!known && autoOn && autoEligible(prefix, sentenceStart)) {
            val head = dict.corrections(lower, if (lower.length >= 7) 2 else 1, true, 1).firstOrNull()
            if (head != null && (head.first.length == lower.length || lower.length >= 4)) {
                auto = recase(prefix, head.first)
            } else if (lower.length >= 6) {
                val any = dict.corrections(lower, 1, false, 2)
                if (any.size == 1) auto = recase(prefix, any[0].first)
            }
        }
        if (auto != null) out.add(auto)
        if (!known && prefix != auto) out.add(prefix)
        if (!known && lower.length >= 2) {
            for ((c, _) in dict.corrections(lower, if (lower.length >= 4) 2 else 1, false, 3)) {
                val s = recase(prefix, c)
                if (out.size < 3 && s !in out) out.add(s)
            }
        }
        if (personalOn) personal.complete(lower, 2).forEach { val s = recase(prefix, it); if (out.size < 3 && s !in out && s != prefix) out.add(s) }
        for (c in dict.complete(lower, 4)) {
            val s = recase(prefix, c)
            if (out.size < 3 && s !in out && s != prefix) out.add(s)
        }
        return Result(out.take(3), auto)
    }

    fun suggestHi(prefix: String): Result {
        if (prefix.isEmpty() || !prefix.all { it.code < 128 }) return Result(emptyList(), null)
        val cands = hindi.candidates(prefix)
        if (cands.isEmpty()) return Result(listOf(prefix), null)
        return Result(cands + prefix, cands.first())
    }
}
