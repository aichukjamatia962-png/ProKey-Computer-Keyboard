package com.prokey.computerkeyboard

import android.os.Bundle
import android.text.InputType
import android.view.ViewGroup
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ListView
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity

/** View, add and delete personal dictionary words; clear everything including learned word pairs. */
class PersonalDictActivity : AppCompatActivity() {

    private lateinit var pd: PersonalDict
    private lateinit var prefs: Prefs
    private lateinit var adapter: ArrayAdapter<String>
    private val items = ArrayList<String>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        title = "Personal dictionary"
        pd = PersonalDict(this)
        pd.load()
        prefs = Prefs(this)
        val dp = resources.displayMetrics.density
        val pad = (12 * dp).toInt()

        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.setPadding(pad, pad, pad, pad)

        root.addView(TextView(this).apply {
            text = "Words ProKey has learned or you added. Stored only on this phone. Tap a word to delete it."
            textSize = 14f
        })

        val addRow = LinearLayout(this)
        addRow.orientation = LinearLayout.HORIZONTAL
        val input = EditText(this).apply {
            hint = "Add a word"
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS
            setSingleLine()
        }
        addRow.addView(input, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        addRow.addView(Button(this).apply {
            text = "Add"
            setOnClickListener {
                val w = input.text.toString().trim().lowercase()
                if (w.length < 2 || w.length > 24 || !w.all { it.isLetter() || it == '\'' }) {
                    Toast.makeText(this@PersonalDictActivity, "Enter 2 to 24 letters", Toast.LENGTH_SHORT).show()
                } else {
                    pd.addExplicit(w)
                    input.setText("")
                    changed()
                }
            }
        })
        root.addView(addRow)

        adapter = ArrayAdapter(this, android.R.layout.simple_list_item_1, items)
        val list = ListView(this)
        list.adapter = adapter
        list.setOnItemClickListener { _, _, pos, _ ->
            val w = items[pos]
            AlertDialog.Builder(this)
                .setTitle("Delete \"$w\"?")
                .setPositiveButton(android.R.string.ok) { _, _ -> pd.remove(w); changed() }
                .setNegativeButton(android.R.string.cancel, null)
                .show()
        }
        root.addView(list, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))

        root.addView(Button(this).apply {
            text = "Clear everything (words and word pairs)"
            setOnClickListener {
                AlertDialog.Builder(this@PersonalDictActivity)
                    .setTitle("Clear personal dictionary?")
                    .setMessage("This deletes all learned and added words and all learned word pairs.")
                    .setPositiveButton(android.R.string.ok) { _, _ ->
                        pd.clearAll()
                        prefs.bumpDictRev()
                        refresh()
                    }
                    .setNegativeButton(android.R.string.cancel, null)
                    .show()
            }
        })
        setContentView(root)
        refresh()
    }

    private fun refresh() {
        items.clear()
        items.addAll(pd.allWords())
        adapter.notifyDataSetChanged()
    }

    private fun changed() {
        pd.flush()
        prefs.bumpDictRev()
        refresh()
    }
}
