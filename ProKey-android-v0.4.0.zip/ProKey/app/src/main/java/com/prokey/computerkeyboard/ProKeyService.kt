package com.prokey.computerkeyboard

import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.annotation.SuppressLint
import android.content.res.Configuration
import android.graphics.drawable.GradientDrawable
import android.view.Gravity
import android.view.MotionEvent
import android.widget.TextView
import android.inputmethodservice.InputMethodService
import android.media.AudioManager
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager
import android.text.InputType
import android.view.KeyCharacterMap
import android.view.KeyEvent
import android.view.View
import android.view.ViewGroup
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputConnection
import android.view.inputmethod.InputMethodManager
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.Toast
import androidx.preference.PreferenceManager
import kotlin.math.abs
import kotlin.math.max

/**
 * The real Android keyboard (InputMethodService). All text goes through InputConnection.
 * Suggestions, autocorrect and learning happen on this device only.
 */
class ProKeyService : InputMethodService(), KeyboardView.Listener,
    SharedPreferences.OnSharedPreferenceChangeListener {

    private enum class PanelKind { EMOJI, CLIPBOARD, SYMBOLS }

    private class WordCtx(val prefix: String, val prev: String?, val sentenceStart: Boolean)
    private class AutoFix(val original: String, val replaced: String, val trigger: String)

    private lateinit var prefs: Prefs
    private lateinit var audio: AudioManager
    private lateinit var clipStore: ClipStore
    private lateinit var themeStore: ThemeStore
    private lateinit var dict: WordDict
    private lateinit var nextWords: NextWords
    private lateinit var hindiDict: HindiDict
    private lateinit var personal: PersonalDict
    private lateinit var suggester: Suggester
    private var vibrator: Vibrator? = null
    private var clipManager: ClipboardManager? = null
    private val handler = Handler(Looper.getMainLooper())

    private val state = KbState()
    private var outerView: FrameLayout? = null
    private var rootView: LinearLayout? = null
    private var handleRow: LinearLayout? = null
    private var dockButton: TextView? = null
    private var floatingActive = false
    private var dragStartX = 0f
    private var dragStartY = 0f
    private var dragBaseLeft = 0
    private var dragBaseBottom = 0
    private var panelHost: FrameLayout? = null
    private var keyboard: KeyboardView? = null
    private var panel: View? = null
    private var searchPanel: SearchPanel? = null
    private var lastKbHeight = 0
    private var editorInfo: EditorInfo? = null
    private var sensitive = false
    private var assistAllowed = false
    private var noLearning = false
    private var hasSelection = false
    private var symbols = false
    private var symbolPage = 0
    private var lastSpaceTime = 0L
    private var curLang = "en"

    // suggestions / autocorrect
    private var curItems: List<String> = emptyList()
    private var lastAuto: AutoFix? = null
    private var suppressAutoFor: String? = null

    // emoji search
    private var searchMode = false
    private val searchQuery = StringBuilder()

    // cached feedback / typing prefs (read on every key press)
    private var soundOn = false
    private var soundVol = 0.5f
    private var vibOn = true
    private var vibLevel = 50
    private var autoCap = true
    private var doubleSpace = true

    private val clipListener = ClipboardManager.OnPrimaryClipChangedListener { captureClip() }
    private val suggestRunnable = Runnable { refreshSuggestions() }
    private val flushRunnable = Runnable { personal.flush() }
    private val idleRunnable = Runnable { clearSuggestions() }

    // ---- lifecycle --------------------------------------------------------------------------

    override fun onCreate() {
        super.onCreate()
        PreferenceManager.setDefaultValues(this, R.xml.preferences, false)
        prefs = Prefs(this)
        clipStore = ClipStore(this)
        themeStore = ThemeStore(this)
        dict = WordDict()
        nextWords = NextWords()
        hindiDict = HindiDict()
        personal = PersonalDict(this)
        suggester = Suggester(dict, personal, nextWords, hindiDict)
        audio = getSystemService(Context.AUDIO_SERVICE) as AudioManager
        vibrator = findVibrator()
        loadCachedPrefs()
        prefs.sp.registerOnSharedPreferenceChangeListener(this)
        clipManager = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        clipManager?.addPrimaryClipChangedListener(clipListener)
        // Load the word lists off the main thread; suggestions start working once they are ready.
        Thread {
            try {
                nextWords.load(this)
                hindiDict.load(this)
                personal.load()
                dict.load(this)
            } catch (e: Exception) {
                // no suggestions if the assets cannot be read
            }
            handler.post { refreshSuggestions() }
        }.start()
    }

    override fun onDestroy() {
        handler.removeCallbacksAndMessages(null)
        personal.flush()
        clipManager?.removePrimaryClipChangedListener(clipListener)
        prefs.sp.unregisterOnSharedPreferenceChangeListener(this)
        super.onDestroy()
    }

    @Suppress("DEPRECATION")
    private fun findVibrator(): Vibrator? =
        if (Build.VERSION.SDK_INT >= 31) {
            (getSystemService(Context.VIBRATOR_MANAGER_SERVICE) as VibratorManager).defaultVibrator
        } else {
            getSystemService(Context.VIBRATOR_SERVICE) as Vibrator
        }

    private fun loadCachedPrefs() {
        soundOn = prefs.soundOn
        soundVol = prefs.soundVolume / 100f
        vibOn = prefs.vibrateOn
        vibLevel = prefs.vibrateLevel
        autoCap = prefs.autoCap
        doubleSpace = prefs.doubleSpace
    }

    override fun onSharedPreferenceChanged(sp: SharedPreferences?, key: String?) {
        loadCachedPrefs()
        if (key == Prefs.DICT_REV) Thread { personal.load() }.start()
        rebuild()
        scheduleSuggest()
    }

    override fun onEvaluateFullscreenMode(): Boolean = false

    override fun onCreateInputView(): View {
        val dp = resources.displayMetrics.density
        val outer = FrameLayout(this)
        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        val handle = buildHandle()
        handle.visibility = View.GONE
        val host = FrameLayout(this)
        host.visibility = View.GONE
        val kb = KeyboardView(this)
        kb.listener = this
        kb.state = state
        root.addView(handle, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, (26 * dp).toInt()))
        root.addView(host, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        root.addView(kb, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        outer.addView(root, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.BOTTOM))
        outerView = outer
        rootView = root
        handleRow = handle
        panelHost = host
        keyboard = kb
        panel = null
        searchPanel = null
        searchMode = false
        rebuild()
        return outer
    }

    /** Drag bar shown on top of the floating keyboard: drag to move, Dock to go back to the normal keyboard. */
    @SuppressLint("ClickableViewAccessibility")
    private fun buildHandle(): LinearLayout {
        val dp = resources.displayMetrics.density
        val row = LinearLayout(this)
        row.orientation = LinearLayout.HORIZONTAL
        row.gravity = Gravity.CENTER_VERTICAL
        val bar = View(this)
        bar.background = GradientDrawable().apply {
            cornerRadius = 3f * dp
            setColor(0x99888888.toInt())
        }
        val dock = TextView(this)
        dock.text = "Dock \u2193"
        dock.textSize = 13f
        dock.gravity = Gravity.END or Gravity.CENTER_VERTICAL
        dock.setPadding(0, 0, (10 * dp).toInt(), 0)
        dock.setOnClickListener { prefs.floating = false }
        row.addView(View(this), LinearLayout.LayoutParams(0, 1, 1f))
        row.addView(bar, LinearLayout.LayoutParams((56 * dp).toInt(), (5 * dp).toInt()))
        row.addView(dock, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, 1f))
        dockButton = dock
        row.setOnTouchListener { _, e -> dragFloating(e) }
        return row
    }

    private fun dragFloating(e: MotionEvent): Boolean {
        val root = rootView ?: return false
        val outer = outerView ?: return false
        val lp = root.layoutParams as? FrameLayout.LayoutParams ?: return false
        val dm = resources.displayMetrics
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                dragStartX = e.rawX
                dragStartY = e.rawY
                dragBaseLeft = lp.leftMargin
                dragBaseBottom = lp.bottomMargin
            }
            MotionEvent.ACTION_MOVE -> {
                lp.leftMargin = (dragBaseLeft + (e.rawX - dragStartX)).toInt().coerceIn(0, max(0, dm.widthPixels - root.width))
                lp.bottomMargin = (dragBaseBottom - (e.rawY - dragStartY)).toInt().coerceIn(0, max(0, outer.height - root.height))
                root.layoutParams = lp
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> prefs.saveFloatPos(lp.leftMargin, lp.bottomMargin)
        }
        return true
    }

    /** Floating mode (experimental): a narrower keyboard you can move; touches outside it go to the app. */
    private fun applyFloating(theme: KbTheme) {
        val outer = outerView ?: return
        val root = rootView ?: return
        val handle = handleRow ?: return
        val lp = root.layoutParams as? FrameLayout.LayoutParams ?: return
        val dm = resources.displayMetrics
        val dp = dm.density
        val on = prefs.floating && !prefs.pc
        floatingActive = on
        if (on) {
            val w = (dm.widthPixels * prefs.floatWidth / 100f).toInt()
            val pos = prefs.floatPos()
            lp.width = w
            lp.gravity = Gravity.BOTTOM or Gravity.START
            lp.leftMargin = (pos?.first ?: ((dm.widthPixels - w) / 2)).coerceIn(0, max(0, dm.widthPixels - w))
            lp.bottomMargin = (pos?.second ?: (24 * dp).toInt()).coerceAtLeast(0)
            outer.minimumHeight = (dm.heightPixels * 0.6f).toInt()
            handle.setBackgroundColor(theme.bg or 0xFF000000.toInt())
            dockButton?.setTextColor(theme.text)
            handle.visibility = View.VISIBLE
        } else {
            lp.width = ViewGroup.LayoutParams.MATCH_PARENT
            lp.gravity = Gravity.BOTTOM
            lp.leftMargin = 0
            lp.bottomMargin = 0
            outer.minimumHeight = 0
            handle.visibility = View.GONE
        }
        root.layoutParams = lp
    }

    /** While floating, only the keyboard itself takes touches and the app is not resized. */
    override fun onComputeInsets(outInsets: InputMethodService.Insets) {
        super.onComputeInsets(outInsets)
        val root = rootView ?: return
        val outer = outerView ?: return
        if (!floatingActive) return
        val loc = IntArray(2)
        root.getLocationInWindow(loc)
        outInsets.contentTopInsets = outer.height
        outInsets.visibleTopInsets = outer.height
        outInsets.touchableInsets = InputMethodService.Insets.TOUCHABLE_INSETS_REGION
        outInsets.touchableRegion.set(loc[0], loc[1], loc[0] + root.width, loc[1] + root.height)
    }

    override fun onConfigurationChanged(newConfig: Configuration) {
        super.onConfigurationChanged(newConfig)
        rebuild()
    }

    override fun onStartInputView(info: EditorInfo, restarting: Boolean) {
        super.onStartInputView(info, restarting)
        editorInfo = info
        sensitive = isSensitive(info)
        assistAllowed = fieldAllowsSuggestions(info)
        noLearning = (info.imeOptions and EditorInfo.IME_FLAG_NO_PERSONALIZED_LEARNING) != 0
        if (!restarting) {
            hidePanel()
            state.resetAll()
            val cls = info.inputType and InputType.TYPE_MASK_CLASS
            symbols = !prefs.pc &&
                (cls == InputType.TYPE_CLASS_NUMBER || cls == InputType.TYPE_CLASS_PHONE)
            symbolPage = 0
            lastSpaceTime = 0L
            lastAuto = null
            suppressAutoFor = null
        }
        rebuild()
        updateAutoCap()
        keyboard?.invalidate()
        scheduleSuggest()
        // Text from the mic key arrives while the speech screen is open; type it now.
        VoiceBridge.take()?.let { currentInputConnection?.commitText("$it ", 1) }
    }

    override fun onFinishInput() {
        super.onFinishInput()
        handler.removeCallbacks(suggestRunnable)
        clearSuggestions()
        personal.flush()
    }

    override fun onUpdateSelection(
        oldSelStart: Int, oldSelEnd: Int, newSelStart: Int, newSelEnd: Int,
        candidatesStart: Int, candidatesEnd: Int
    ) {
        super.onUpdateSelection(oldSelStart, oldSelEnd, newSelStart, newSelEnd, candidatesStart, candidatesEnd)
        hasSelection = newSelStart != newSelEnd
        updateAutoCap()
        keyboard?.invalidate()
        scheduleSuggest()
    }

    private fun isSensitive(info: EditorInfo): Boolean {
        val cls = info.inputType and InputType.TYPE_MASK_CLASS
        val variation = info.inputType and InputType.TYPE_MASK_VARIATION
        return when (cls) {
            InputType.TYPE_CLASS_TEXT ->
                variation == InputType.TYPE_TEXT_VARIATION_PASSWORD ||
                    variation == InputType.TYPE_TEXT_VARIATION_VISIBLE_PASSWORD ||
                    variation == InputType.TYPE_TEXT_VARIATION_WEB_PASSWORD
            InputType.TYPE_CLASS_NUMBER -> variation == InputType.TYPE_NUMBER_VARIATION_PASSWORD
            else -> false
        }
    }

    /** Plain text fields only: no numbers, URLs, e-mail addresses, passwords, or fields that opt out. */
    private fun fieldAllowsSuggestions(info: EditorInfo): Boolean {
        val cls = info.inputType and InputType.TYPE_MASK_CLASS
        if (cls != InputType.TYPE_CLASS_TEXT) return false
        if ((info.inputType and InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS) != 0) return false
        val v = info.inputType and InputType.TYPE_MASK_VARIATION
        return v != InputType.TYPE_TEXT_VARIATION_URI &&
            v != InputType.TYPE_TEXT_VARIATION_EMAIL_ADDRESS &&
            v != InputType.TYPE_TEXT_VARIATION_WEB_EMAIL_ADDRESS &&
            v != InputType.TYPE_TEXT_VARIATION_PASSWORD &&
            v != InputType.TYPE_TEXT_VARIATION_VISIBLE_PASSWORD &&
            v != InputType.TYPE_TEXT_VARIATION_WEB_PASSWORD &&
            v != InputType.TYPE_TEXT_VARIATION_FILTER
    }

    private fun langName(l: String) = when (l) {
        "hi_tr" -> "हिन्दी (Hinglish)"
        "hi_in" -> "हिन्दी"
        else -> "English"
    }

    private fun rebuild() {
        val v = keyboard ?: return
        val landscape = resources.configuration.orientation == Configuration.ORIENTATION_LANDSCAPE
        val pc = prefs.pc && !searchMode
        curLang = prefs.activeLang()
        val multi = prefs.enabledLangs().size > 1
        val spaceLabel = if (multi) langName(curLang) else ""
        val tb = prefs.toolbar
        state.fnRow = prefs.functionRow
        if (!pc) state.caps = false
        var rows = when {
            searchMode -> Layouts.mobile(false, false, "", false)
            pc -> Layouts.pc(state.fnRow, landscape, landscape && prefs.numpad, prefs.pcQuickbar)
            symbols -> Layouts.symbols(symbolPage, tb, spaceLabel, multi)
            curLang == "hi_in" -> Layouts.hindi(tb, spaceLabel, multi)
            else -> Layouts.mobile(prefs.numberRow, tb, spaceLabel, multi)
        }
        if (landscape && prefs.splitLandscape && !pc && !searchMode) rows = Layouts.split(rows)
        val side = if (landscape || prefs.floating || searchMode) 0 else when (prefs.oneHanded) {
            "left" -> 1
            "right" -> 2
            else -> 0
        }
        val baseDp = if (pc) (if (landscape) 34f else 40f) else (if (landscape) 38f else 46f)
        val theme = themeStore.resolve(prefs.theme)
        applyFloating(theme)
        v.setup(
            rows,
            theme,
            KeyboardView.Look(baseDp * prefs.heightPct / 100f, prefs.gap.toFloat(), prefs.radius.toFloat(), prefs.keyPreview, prefs.fontPct / 100f, side, prefs.oneHandWidth / 100f)
        )
    }

    private fun updateAutoCap() {
        if (prefs.pc || !autoCap || curLang == "hi_in" || searchMode || state.shift.state != Mod.OFF) return
        val ei = editorInfo ?: return
        val ic = currentInputConnection ?: return
        if (ic.getCursorCapsMode(ei.inputType) != 0) state.shift.state = Mod.ONCE
    }

    // ---- suggestions, autocorrect, learning -------------------------------------------------

    private fun typingAssistActive() = assistAllowed && !sensitive && !prefs.pc && !searchMode && curLang != "hi_in"

    private fun canLearn() = prefs.learnWords && !noLearning && personal.ready

    private fun scheduleSuggest() {
        handler.removeCallbacks(suggestRunnable)
        handler.postDelayed(suggestRunnable, 30L)
    }

    private fun wordChar(c: Char, ascii: Boolean): Boolean =
        if (ascii) (c in 'a'..'z' || c in 'A'..'Z' || c == '\'' || c == '\u2019')
        else (c.isLetterOrDigit() && c.code < 0x250) || c == '\'' || c == '\u2019'

    private fun wordContext(before: String, ascii: Boolean): WordCtx {
        var i = before.length
        while (i > 0 && wordChar(before[i - 1], ascii)) i--
        while (i < before.length && (before[i] == '\'' || before[i] == '\u2019')) i++
        val prefix = before.substring(i)
        var j = i
        while (j > 0 && before[j - 1].isWhitespace()) j--
        var prev: String? = null
        if (j < i) {
            var k = j
            while (k > 0 && wordChar(before[k - 1], ascii)) k--
            if (k < j) prev = before.substring(k, j)
        }
        val rawHead = before.substring(0, i)
        val trimmed = rawHead.trimEnd()
        val start = trimmed.isEmpty() || trimmed.last() in ".!?" || rawHead.endsWith("\n")
        return WordCtx(prefix, prev, start)
    }

    /** Back to the plain toolbar (nothing being typed, empty field, or suggestions unavailable). */
    private fun clearSuggestions() {
        handler.removeCallbacks(idleRunnable)
        curItems = emptyList()
        keyboard?.showSuggestions(null, -1)
    }

    /**
     * While typing, the toolbar row shows three suggestions in place of its buttons. They need the top
     * toolbar to be on (that row is the only place they are drawn). The toolbar returns when typing stops
     * for a moment, when the field is empty, or when there is nothing to suggest.
     */
    private fun refreshSuggestions() {
        val kb = keyboard ?: return
        if (panel != null || searchMode || !prefs.suggestWords || !prefs.toolbar || !typingAssistActive() || hasSelection) {
            clearSuggestions()
            return
        }
        val ic = currentInputConnection ?: return
        val before = ic.getTextBeforeCursor(48, 0)?.toString() ?: ""
        if (before.isEmpty()) {
            clearSuggestions()
            return
        }
        val c = wordContext(before, curLang == "hi_tr")
        val res = if (curLang == "hi_tr") {
            suggester.suggestHi(c.prefix)
        } else {
            suggester.suggestEn(c.prefix, c.prev, c.sentenceStart, prefs.autoCorrect, personal.ready, prefs.nextWord)
        }
        if (res.items.isEmpty()) {
            clearSuggestions()
            return
        }
        curItems = res.items
        kb.showSuggestions(res.items, res.auto?.let { res.items.indexOf(it) } ?: -1)
        handler.removeCallbacks(idleRunnable)
        handler.postDelayed(idleRunnable, IDLE_MS)
    }

    private fun pickSuggestion(index: Int) {
        val text = curItems.getOrNull(index) ?: return
        val ic = currentInputConnection ?: return
        val before = ic.getTextBeforeCursor(48, 0)?.toString() ?: ""
        val c = wordContext(before, curLang == "hi_tr")
        ic.beginBatchEdit()
        if (c.prefix.isNotEmpty()) ic.deleteSurroundingText(c.prefix.length, 0)
        ic.commitText("$text ", 1)
        ic.endBatchEdit()
        // Choosing the word exactly as typed teaches it to the personal dictionary.
        if (curLang == "en" && canLearn() && c.prefix.isNotEmpty() && text == c.prefix) {
            val lower = text.lowercase()
            if (!dict.isKnown(lower)) personal.addExplicit(lower)
            scheduleFlush()
        }
        lastAuto = null
        scheduleSuggest()
    }

    /** Called before a space or punctuation is typed: converts (Hinglish), autocorrects, or learns the word. */
    private fun finishWord(trigger: String) {
        if (!typingAssistActive()) return
        val ic = currentInputConnection ?: return
        val before = ic.getTextBeforeCursor(48, 0)?.toString() ?: return
        val c = wordContext(before, curLang == "hi_tr")
        if (c.prefix.isEmpty()) return
        val suppressed = suppressAutoFor
        suppressAutoFor = null
        if (suppressed != null && suppressed == c.prefix) return
        var replacement: String? = null
        if (curLang == "hi_tr") {
            replacement = suggester.suggestHi(c.prefix).auto
        } else if (curLang == "en" && prefs.autoCorrect) {
            replacement = suggester.suggestEn(c.prefix, c.prev, c.sentenceStart, true, personal.ready, false).auto
        }
        if (replacement != null && replacement != c.prefix) {
            ic.beginBatchEdit()
            ic.deleteSurroundingText(c.prefix.length, 0)
            ic.commitText(replacement, 1)
            ic.endBatchEdit()
            lastAuto = AutoFix(c.prefix, replacement, trigger)
        } else if (curLang == "en" && canLearn()) {
            val lower = c.prefix.lowercase()
            if (lower.all { it.isLetter() || it == '\'' }) {
                personal.observe(lower, c.prev?.lowercase(), dict.isKnown(lower), prefs.nextWord)
                scheduleFlush()
            }
        }
    }

    /** Backspace right after an autocorrect/conversion puts back what the user typed. */
    private fun revertAuto(fix: AutoFix): Boolean {
        val ic = currentInputConnection ?: return false
        val tail = fix.replaced + fix.trigger
        val before = ic.getTextBeforeCursor(tail.length, 0)?.toString() ?: return false
        if (before != tail) return false
        ic.beginBatchEdit()
        ic.deleteSurroundingText(tail.length, 0)
        ic.commitText(fix.original, 1)
        ic.endBatchEdit()
        suppressAutoFor = fix.original
        if (curLang == "en" && canLearn()) {
            val lower = fix.original.lowercase()
            if (lower.all { it.isLetter() || it == '\'' }) personal.observe(lower, null, dict.isKnown(lower), false)
        }
        return true
    }

    private fun scheduleFlush() {
        handler.removeCallbacks(flushRunnable)
        handler.postDelayed(flushRunnable, 20_000L)
    }

    // ---- panels (emoji / clipboard / emoji search) ------------------------------------------

    private fun showPanel(kind: PanelKind) {
        val host = panelHost ?: return
        val kb = keyboard ?: return
        val minH = (220 * resources.displayMetrics.density).toInt()
        if (kb.visibility == View.VISIBLE && kb.height > 0) lastKbHeight = kb.height
        val h = max(lastKbHeight, minH)
        hidePanel()
        val theme = themeStore.resolve(prefs.theme)
        val p: View = when (kind) {
            PanelKind.EMOJI -> EmojiPanel(this, theme, prefs, ::commitEmoji, ::hidePanel, ::panelBackspace, ::startEmojiSearch)
            PanelKind.CLIPBOARD -> ClipboardPanel(this, theme, prefs, clipStore, ::pasteClip, ::hidePanel)
            PanelKind.SYMBOLS -> GlyphPanel(this, theme, SymbolData.categories, ::pasteClip, ::hidePanel, ::panelBackspace)
        }
        kb.visibility = View.GONE
        host.layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, h)
        host.removeAllViews()
        host.addView(p, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        host.visibility = View.VISIBLE
        panel = p
    }

    private fun hidePanel() {
        val wasSearch = searchMode
        searchMode = false
        searchPanel = null
        searchQuery.setLength(0)
        panelHost?.removeAllViews()
        panelHost?.visibility = View.GONE
        panel = null
        keyboard?.visibility = View.VISIBLE
        if (wasSearch) rebuild()
        scheduleSuggest()
    }

    private fun startEmojiSearch() {
        val host = panelHost ?: return
        searchMode = true
        searchQuery.setLength(0)
        host.removeAllViews()
        val sp = SearchPanel(this, themeStore.resolve(prefs.theme), ::commitEmoji, ::closeSearch)
        searchPanel = sp
        panel = sp
        host.layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        host.addView(sp, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        host.visibility = View.VISIBLE
        keyboard?.visibility = View.VISIBLE
        rebuild()
    }

    private fun closeSearch() {
        searchMode = false
        searchPanel = null
        searchQuery.setLength(0)
        rebuild()
        showPanel(PanelKind.EMOJI)
    }

    private fun handleSearchKey(key: Key) {
        when (key.type) {
            KeyType.CHAR -> { searchQuery.append(key.text.lowercase()); state.shift.consume() }
            KeyType.SPACE -> searchQuery.append(' ')
            KeyType.BACKSPACE -> if (searchQuery.isNotEmpty()) searchQuery.deleteCharAt(searchQuery.length - 1)
            KeyType.ENTER -> { closeSearch(); return }
            KeyType.SHIFT -> state.shift.tap()
            else -> Unit
        }
        val q = searchQuery.toString()
        searchPanel?.setQuery(q, EmojiKeywords.search(q))
        keyboard?.invalidate()
    }

    private fun commitEmoji(e: String) {
        currentInputConnection?.commitText(e, 1)
        if (!sensitive) prefs.addEmojiRecent(e)
    }

    private fun pasteClip(text: String) {
        currentInputConnection?.commitText(text, 1)
    }

    private fun panelBackspace() {
        sendCode(KeyEvent.KEYCODE_DEL, false)
    }

    /** Records copied text only while clipboard history is on, never in password fields or flagged-sensitive clips. */
    private fun captureClip() {
        if (!prefs.clipEnabled || sensitive) return
        val clip = clipManager?.primaryClip ?: return
        if (clip.itemCount == 0) return
        if (clip.description.extras?.getBoolean("android.content.extra.IS_SENSITIVE", false) == true) return
        val text = clip.getItemAt(0).coerceToText(this)?.toString()?.trim() ?: return
        if (text.isEmpty() || text.length > 5000) return
        clipStore.add(text, prefs.clipMax)
    }

    // ---- feedback ---------------------------------------------------------------------------

    override fun onPress(key: Key) {
        if (vibOn) vibrate()
        if (soundOn && soundVol > 0f) {
            val fx = when (key.type) {
                KeyType.SPACE -> AudioManager.FX_KEYPRESS_SPACEBAR
                KeyType.BACKSPACE -> AudioManager.FX_KEYPRESS_DELETE
                KeyType.ENTER -> AudioManager.FX_KEYPRESS_RETURN
                else -> AudioManager.FX_KEYPRESS_STANDARD
            }
            audio.playSoundEffect(fx, soundVol)
        }
    }

    private fun vibrate() {
        val v = vibrator ?: return
        if (!v.hasVibrator()) return
        val effect = if (v.hasAmplitudeControl()) {
            VibrationEffect.createOneShot(14L, (vibLevel * 255 / 100).coerceIn(1, 255))
        } else {
            VibrationEffect.createOneShot((6 + vibLevel / 3).toLong(), VibrationEffect.DEFAULT_AMPLITUDE)
        }
        v.vibrate(effect)
    }

    // ---- key handling -----------------------------------------------------------------------

    override fun onKey(key: Key) {
        val fix = lastAuto
        if (key.type != KeyType.BACKSPACE) lastAuto = null
        if (searchMode) {
            handleSearchKey(key)
            return
        }
        when (key.type) {
            KeyType.CHAR -> typeChar(key)
            KeyType.SPACE -> typeSpace()
            KeyType.ENTER -> typeEnter()
            KeyType.BACKSPACE -> {
                lastAuto = null
                if (prefs.pc || fix == null || !revertAuto(fix)) sendCode(KeyEvent.KEYCODE_DEL, prefs.pc)
            }
            KeyType.CODE -> {
                if (key.keyCode == KeyEvent.KEYCODE_SYSRQ) {
                    Toast.makeText(this, "Print Screen: use your phone screenshot shortcut", Toast.LENGTH_SHORT).show()
                }
                sendCode(key.keyCode, true)
            }
            KeyType.SHIFT -> state.shift.tap()
            KeyType.CAPS -> state.caps = !state.caps
            KeyType.CTRL -> state.ctrl.tap()
            KeyType.ALT -> state.alt.tap()
            KeyType.META -> state.meta.tap()
            KeyType.FN -> prefs.functionRow = !prefs.functionRow
            KeyType.SYMBOLS -> { symbols = !symbols; symbolPage = 0; rebuild() }
            KeyType.SYMBOL_PAGE -> { symbolPage = 1 - symbolPage; rebuild() }
            KeyType.MODE -> { symbols = false; prefs.layoutMode = if (prefs.pc) "mobile" else "pc" }
            KeyType.SETTINGS -> openSettings()
            KeyType.TOOL -> key.tool?.let { runTool(it) }
            KeyType.SUGGEST -> pickSuggestion(key.keyCode)
            KeyType.SPACER -> Unit
        }
        keyboard?.invalidate()
    }

    override fun onLongTool(key: Key) {
        when (key.longTool) {
            Tool.NEXT_IME -> switchKeyboard()
            Tool.NEXT_LANG -> nextLanguage()
            Tool.ONE_HAND -> runTool(Tool.ONE_HAND)
            else -> Unit
        }
    }

    private fun nextLanguage() {
        val l = prefs.enabledLangs()
        val i = l.indexOf(curLang)
        prefs.currentLang = l[(i + 1) % l.size]
    }

    override fun onAlt(key: Key, text: String) {
        if (searchMode) return
        lastAuto = null
        if (key.type == KeyType.TOOL) {
            // long-press menu on the clipboard button
            when (text) {
                "All" -> runTool(Tool.SELECT_ALL)
                "Copy" -> runTool(Tool.COPY)
                "Cut" -> runTool(Tool.CUT)
                "Paste" -> runTool(Tool.PASTE)
            }
            keyboard?.invalidate()
            return
        }
        val ic = currentInputConnection ?: return
        ic.commitText(Alts.cased(key, text, state.shift.on), 1)
        state.shift.consume()
        keyboard?.invalidate()
    }

    override fun onSpaceSwipe(steps: Int) {
        if (searchMode) return
        lastAuto = null
        val code = if (steps < 0) KeyEvent.KEYCODE_DPAD_LEFT else KeyEvent.KEYCODE_DPAD_RIGHT
        repeat(abs(steps)) { sendCode(code, false) }
    }

    /** Backspace swipe: delete the selection, or the previous word (plus any spaces after it). */
    override fun onWordDelete() {
        if (searchMode) return
        lastAuto = null
        val ic = currentInputConnection ?: return
        if (!ic.getSelectedText(0).isNullOrEmpty()) {
            ic.commitText("", 1)
            return
        }
        val before = ic.getTextBeforeCursor(120, 0)?.toString() ?: return
        if (before.isEmpty()) return
        var i = before.length
        while (i > 0 && before[i - 1].isWhitespace()) i--
        while (i > 0 && !before[i - 1].isWhitespace()) i--
        val count = before.codePointCount(i, before.length)
        if (count > 0) ic.deleteSurroundingTextInCodePoints(count, 0)
    }

    private fun outputText(k: Key): String {
        val st = k.shiftText ?: return k.text
        val upper = if (k.isLetter) state.shift.on != state.caps else state.shift.on
        return if (upper) st else k.text
    }

    private fun typeChar(key: Key) {
        val ic = currentInputConnection ?: return
        if (prefs.pc && state.anyCtrlAltMeta() && key.keyCode != KeyEvent.KEYCODE_UNKNOWN) {
            val handled = state.ctrl.on && !state.alt.on && !state.meta.on && ctrlShortcut(ic, key.keyCode)
            if (handled) state.consumeMods() else sendCode(key.keyCode, true)
            return
        }
        val out = outputText(key)
        if (!prefs.pc && out.length == 1 && out[0] in ".,!?;:)") finishWord(out)
        overwriteNext(ic)
        ic.commitText(out, 1)
        state.shift.consume()
    }

    /** Ctrl+A/C/X/V go straight to the editor; everything else is sent as a Ctrl key event. */
    private fun ctrlShortcut(ic: InputConnection, code: Int): Boolean = when (code) {
        KeyEvent.KEYCODE_A -> ic.performContextMenuAction(android.R.id.selectAll)
        KeyEvent.KEYCODE_C -> ic.performContextMenuAction(android.R.id.copy)
        KeyEvent.KEYCODE_X -> ic.performContextMenuAction(android.R.id.cut)
        KeyEvent.KEYCODE_V -> ic.performContextMenuAction(android.R.id.paste)
        else -> false
    }

    // ---- toolbar / quick-action bar ---------------------------------------------------------

    private fun runTool(t: Tool) {
        when (t) {
            Tool.EMOJI -> showPanel(PanelKind.EMOJI)
            Tool.CLIPBOARD -> showPanel(PanelKind.CLIPBOARD)
            Tool.MIC -> startVoice()
            Tool.UNDO -> editAction(android.R.id.undo, KeyEvent.KEYCODE_Z)
            Tool.REDO -> editAction(android.R.id.redo, KeyEvent.KEYCODE_Y)
            Tool.CUT -> editAction(android.R.id.cut, KeyEvent.KEYCODE_X)
            Tool.COPY -> editAction(android.R.id.copy, KeyEvent.KEYCODE_C)
            Tool.PASTE -> editAction(android.R.id.paste, KeyEvent.KEYCODE_V)
            Tool.SELECT_ALL -> editAction(android.R.id.selectAll, KeyEvent.KEYCODE_A)
            Tool.NEXT_IME -> switchKeyboard()
            Tool.NEXT_LANG -> nextLanguage()
            Tool.SYMBOLS -> showPanel(PanelKind.SYMBOLS)
            Tool.TAB -> sendCode(KeyEvent.KEYCODE_TAB, false)
            Tool.INSERT -> state.overwrite = !state.overwrite
            Tool.ONE_HAND -> prefs.oneHanded = if (prefs.oneHanded == "off") "right" else "off"
            Tool.ONE_HAND_EXIT -> prefs.oneHanded = "off"
            Tool.ONE_HAND_SWAP -> prefs.oneHanded = if (prefs.oneHanded == "left") "right" else "left"
        }
    }

    /** Runs the editor's own action; if the app does not support it, falls back to the Ctrl+key shortcut. */
    private fun editAction(menuId: Int, fallbackKey: Int) {
        val ic = currentInputConnection ?: return
        if (!ic.performContextMenuAction(menuId)) sendKey(fallbackKey, CTRL_META)
    }

    private fun startVoice() {
        val i = Intent(this, VoiceActivity::class.java)
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_NO_ANIMATION)
        startActivity(i)
    }

    // ---- space / enter / key events ---------------------------------------------------------

    /** Insert key (PC mode): a typed character replaces the one after the cursor. */
    private fun overwriteNext(ic: InputConnection) {
        if (!state.overwrite || !prefs.pc) return
        val next = ic.getTextAfterCursor(1, 0)
        if (!next.isNullOrEmpty() && next[0] != '\n') ic.deleteSurroundingTextInCodePoints(0, 1)
    }

    private fun typeSpace() {
        val ic = currentInputConnection ?: return
        if (prefs.pc && state.anyCtrlAltMeta()) {
            sendCode(KeyEvent.KEYCODE_SPACE, true)
            return
        }
        if (!prefs.pc) finishWord(" ")
        val now = SystemClock.uptimeMillis()
        if (!prefs.pc && doubleSpace && now - lastSpaceTime < 500L) {
            val before = ic.getTextBeforeCursor(2, 0)
            if (before != null && before.length == 2 && before[1] == ' ' && before[0].isLetterOrDigit()) {
                ic.beginBatchEdit()
                ic.deleteSurroundingText(1, 0)
                ic.commitText(". ", 1)
                ic.endBatchEdit()
                lastSpaceTime = 0L
                lastAuto = null
                return
            }
        }
        overwriteNext(ic)
        ic.commitText(" ", 1)
        lastSpaceTime = now
        state.shift.consume()
    }

    private fun typeEnter() {
        val ic = currentInputConnection ?: return
        if (prefs.pc && state.anyCtrlAltMeta()) {
            sendCode(KeyEvent.KEYCODE_ENTER, true)
            return
        }
        if (!prefs.pc) {
            finishWord("\n")
            lastAuto = null
        }
        val opts = editorInfo?.imeOptions ?: 0
        val action = opts and EditorInfo.IME_MASK_ACTION
        val noEnterAction = (opts and EditorInfo.IME_FLAG_NO_ENTER_ACTION) != 0
        if (!noEnterAction && action != EditorInfo.IME_ACTION_NONE && action != EditorInfo.IME_ACTION_UNSPECIFIED) {
            ic.performEditorAction(action)
        } else {
            sendCode(KeyEvent.KEYCODE_ENTER, false)
        }
    }

    /** Sends a down+up KeyEvent with an explicit meta state. */
    private fun sendKey(code: Int, meta: Int) {
        val ic = currentInputConnection ?: return
        val t = SystemClock.uptimeMillis()
        val flags = KeyEvent.FLAG_SOFT_KEYBOARD or KeyEvent.FLAG_KEEP_TOUCH_MODE
        ic.sendKeyEvent(KeyEvent(t, t, KeyEvent.ACTION_DOWN, code, 0, meta, KeyCharacterMap.VIRTUAL_KEYBOARD, 0, flags))
        ic.sendKeyEvent(KeyEvent(t, t, KeyEvent.ACTION_UP, code, 0, meta, KeyCharacterMap.VIRTUAL_KEYBOARD, 0, flags))
    }

    /** With [withMods] the active Shift/Ctrl/Alt/Win state is attached and then consumed. */
    private fun sendCode(code: Int, withMods: Boolean) {
        sendKey(code, if (withMods) state.metaState() else 0)
        if (withMods) state.consumeMods()
    }

    private fun switchKeyboard() {
        val imm = getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager
        @Suppress("DEPRECATION")
        val switched = if (Build.VERSION.SDK_INT >= 28) {
            switchToNextInputMethod(false)
        } else {
            imm.switchToNextInputMethod(window.window?.attributes?.token, false)
        }
        if (!switched) imm.showInputMethodPicker()
    }

    private fun openSettings() {
        val i = Intent(this, SettingsActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        startActivity(i)
        requestHideSelf(0)
    }

    private companion object {
        const val CTRL_META = KeyEvent.META_CTRL_ON or KeyEvent.META_CTRL_LEFT_ON
        const val IDLE_MS = 2500L
    }
}
