# ProKey – Computer Keyboard: Privacy Policy

Last updated: (set date before publishing)

ProKey is a keyboard. What you type stays on your device.

- ProKey does not transmit anything you type. It has no INTERNET permission, no accounts, no advertising and no analytics or tracking SDKs.
- Suggestions, autocorrect and Hindi transliteration run on your phone using word lists bundled in the app.
- Personal dictionary: if "Learn new words" is on (default), ProKey saves words you type that are not in its dictionary, and pairs of consecutive words (used for next-word suggestions), in the app's private storage on your phone. Nothing is learned in password fields or in fields that request incognito typing. You can view, add, delete and clear this data in Settings > Personal dictionary, or turn learning off.
- ProKey also saves on your device: your keyboard settings, custom themes (including a background image you choose, copied into the app's storage), a short list of recently used emojis, and, only if you turn the feature on, a clipboard history (default: off; you can pin, delete or clear entries and set a size limit). Clipboard history is not recorded while a password field is active or for clipboard content that the copying app marks as sensitive. This data is not encrypted.
- Voice typing: the microphone key opens your phone's speech-recognition app (for example Google). ProKey does not access the microphone and has no audio permission. The speech-recognition app may process audio, possibly on its servers, under its own privacy policy. ProKey only receives the resulting text and types it.
- ProKey requests the VIBRATE permission only to vibrate on key presses.
- Uninstalling ProKey removes all of the data above. Settings > "Clear clipboard history and recent emojis" and Personal dictionary > "Clear everything" remove that data at any time.

Contact: (your email / support address)

Hosting: publish this text at a public URL (for example a GitHub Pages page or your own site) and use that URL in store listings.
